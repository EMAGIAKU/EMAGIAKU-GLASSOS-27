// EG PLAY - interfaccia da console (prototipo). Controller (Gamepad API) + tastiera (frecce, Invio, Esc).
"use strict";
(() => {
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const SEZ = ["home", "libreria", "store", "amici", "download", "impostazioni"];
  const S = { sez: "home", giochi: [], filtro: "", stato: {}, scelto: null, fuoco: null, finestra: null, ritorno: null };

  // ------------------------------------------------------------------ servizio locale
  async function api(path, body) {
    const opt = body ? { method: "POST", headers: { "Content-Type": "application/json", "X-EG-Play": "1" }, body: JSON.stringify(body) } : {};
    const r = await fetch(path, opt);
    return r.json();
  }

  // ------------------------------------------------------------------ copertine
  function tinta(nome) { let h = 0; for (const ch of nome) h = (h * 31 + ch.charCodeAt(0)) % 360; return h; }
  function colore(g) { const h = tinta(g.nome); return `linear-gradient(150deg, hsl(${h} 70% 45%), hsl(${(h + 50) % 360} 65% 22%))`; }
  function immagine(g, tipo) { return g.immagine ? `url("/api/immagine?id=${encodeURIComponent(g.id)}&tipo=${tipo}")` : null; }

  function tessera(g) {
    const b = document.createElement("button");
    b.className = "gioco f";
    b.dataset.id = g.id;
    const img = immagine(g, "cover");
    b.style.background = img ? `${img} center/cover, ${colore(g)}` : colore(g);
    if (img) b.classList.add("con-img");
    b.innerHTML = `<span class="lettera"></span>${g.demo ? '<span class="etich">DEMO</span>' : (g.pronto ? "" : '<span class="etich">IN DOWNLOAD</span>')}<span class="nome"></span>`;
    b.querySelector(".lettera").textContent = g.nome.trim().charAt(0).toUpperCase();
    b.querySelector(".nome").textContent = g.nome;
    b.addEventListener("click", () => gioca(g));
    b.addEventListener("focus", () => scegli(g));
    return b;
  }

  function quando(ts) {
    if (!ts) return "";
    const g = Math.floor((Date.now() / 1000 - ts) / 86400);
    return g <= 0 ? "Giocato oggi" : g === 1 ? "Giocato ieri" : `Giocato ${g} giorni fa`;
  }
  function peso(b) { return b ? (b / 1024 ** 3).toFixed(1).replace(".", ",") + " GB" : ""; }

  function scegli(g) {
    S.scelto = g;
    $("#h-nome").textContent = g.nome;
    $("#h-fonte").textContent = g.fonte;
    $("#h-info").textContent = [quando(g.ultimo), peso(g.dimensione)].filter(Boolean).join(" · ");
    const img = immagine(g, "hero");
    $("#sfondo").style.background = img ? `${img} center/cover, ${colore(g)}` : `radial-gradient(1200px 700px at 75% 20%, hsl(${tinta(g.nome)} 60% 30%), transparent 65%), #07060c`;
  }

  // ------------------------------------------------------------------ disegno
  function disegna() {
    const rec = $("#recenti");
    rec.textContent = "";
    if (!S.giochi.length) {
      rec.innerHTML = '<div class="vuoto">Nessun gioco trovato. Installa Steam e i giochi dall\'EG Store, oppure Steam: appariranno qui da soli.</div>';
      $("#h-nome").textContent = "Benvenuto in EG PLAY";
      $("#h-info").textContent = "I tuoi giochi installati compariranno qui.";
      $("#b-gioca").classList.add("nascosta");
      $("#b-dettagli").classList.add("nascosta");
    } else {
      S.giochi.slice(0, 12).forEach((g) => rec.appendChild(tessera(g)));
      $("#b-gioca").classList.remove("nascosta");
      $("#b-dettagli").classList.remove("nascosta");
      scegli(S.giochi[0]);
    }
    griglia();
  }

  function griglia() {
    const gr = $("#griglia");
    gr.textContent = "";
    const lista = S.giochi.filter((g) => !S.filtro || g.fonte === S.filtro);
    if (!lista.length) gr.innerHTML = '<div class="vuoto">Nessun gioco in questa categoria.</div>';
    lista.forEach((g) => gr.appendChild(tessera(g)));
    $$("#filtri .chip").forEach((c) => c.classList.toggle("sel", c.dataset.filtro === S.filtro));
  }

  function vaiSez(nome, fuocoTab) {
    if (!SEZ.includes(nome)) return;
    S.sez = nome;
    $$(".sez").forEach((s) => s.classList.toggle("attiva", s.id === "sez-" + nome));
    $$(".tab").forEach((t) => t.classList.toggle("attiva", t.dataset.sez === nome));
    if (fuocoTab) metti($(`.tab[data-sez="${nome}"]`));
    else metti(primo());
  }

  function primo() {
    const sez = $(".sez.attiva");
    return $(".gioco.f", sez) || $(".f:not(.nascosta)", sez) || $(".tab.attiva");
  }

  // ------------------------------------------------------------------ azioni
  let occupato = false;
  async function gioca(g) {
    if (!g || occupato) return;
    if (!S.stato.licenza) return apri("blocco");
    occupato = true;
    avviso(`Avvio di ${g.nome}…`);
    try {
      const r = await api("/api/avvia", { id: g.id });
      avviso(r.ok ? `${r.nome} si sta avviando` : r.errore || "Avvio non riuscito", 4000);
    } catch (e) { avviso("Il servizio EG PLAY non risponde", 4000); }
    occupato = false;
  }

  const MSG = {
    store: "Apertura dell'EG Store…", impostazioni: "Apertura delle Impostazioni…", esci: "Chiusura di EG PLAY…",
    desktop: "Torno alla schermata di accesso…", spegni: "Spegnimento…", riavvia: "Riavvio…",
    installa: "Apertura dell'installazione (serve mouse o tastiera)…",
    prepara: "EG PLAY OS pronto: lo trovi anche come sessione \"EG PLAY\" nella schermata di accesso",
    "avvio-console": "All'accensione entrerai direttamente in EG PLAY", "avvio-desktop": "All'accensione: schermata di accesso normale",
  };
  async function apriCosa(cosa) {
    if (["prepara", "avvio-console", "avvio-desktop"].includes(cosa)) avviso("Serve la password di amministratore…", 6000);
    try {
      const r = await api("/api/apri", { cosa });
      if (!r.ok) avviso(r.errore || "Non riuscito", 4000);
      else avviso(MSG[cosa] || "Fatto", 3500);
      if (r.ok && ["prepara", "avvio-console", "avvio-desktop"].includes(cosa)) aggiornaStato();
    } catch (e) { avviso("Il servizio EG PLAY non risponde", 3000); }
  }

  // ------------------------------------------------------------------ EG PLAY OS (sessione console)
  async function aggiornaStato() {
    try { S.stato = await api("/api/stato"); } catch (e) { return; }
    mostraOS();
  }
  function mostraOS() {
    const st = S.stato;
    $$(".solo-sessione").forEach((e) => e.classList.toggle("nascosta", !st.sessione));
    $$(".solo-desktop").forEach((e) => e.classList.toggle("nascosta", !!st.sessione));
    $("#os-sessione").classList.toggle("nascosta", !st.sessione);
    $("#os-desktop").classList.toggle("nascosta", !!st.sessione);
    $("#b-installa").classList.toggle("nascosta", !st.live);
    if (st.sessione) {
      $("#os-testo").textContent = st.live
        ? "Stai provando EG PLAY OS dalla chiavetta USB. Ti piace? Installalo sul disco: all'accensione partirà direttamente qui."
        : "Sei in EG PLAY OS: niente desktop, solo giochi. Il desktop di EMAGIAKU GLASS OS è sempre a un passo.";
    } else {
      $("#os-testo").textContent = st.pronto
        ? "EG PLAY OS è pronto: nella schermata di accesso scegli la sessione \"EG PLAY\", oppure fallo partire da solo all'accensione."
        : "Trasforma questo PC in una console: si accende direttamente nei giochi, senza desktop. Prepara installa gamescope, Bluetooth e i controller.";
      $("#b-prepara").classList.toggle("nascosta", !!st.pronto);
      const av = $("#b-avvio");
      av.textContent = st.avvio_console ? "All'accensione: torna al desktop" : "All'accensione: entra in EG PLAY";
      av.dataset.cosa = st.avvio_console ? "avvio-desktop" : "avvio-console";
    }
  }
  $("#b-avvio").addEventListener("click", (e) => apriCosa(e.currentTarget.dataset.cosa || "avvio-console"));

  // ------------------------------------------------------------------ controller Bluetooth
  let cercando = false;
  async function cercaBT() {
    if (cercando) return;
    cercando = true;
    const box = $("#bt-lista");
    box.textContent = "Cerco per 10 secondi…";
    try {
      const r = await api("/api/bt/cerca", {});
      box.textContent = "";
      if (!r.ok) { box.textContent = r.errore; return; }
      if (!r.controller.length) { box.textContent = "Nessun controller trovato: mettilo in abbinamento e riprova."; return; }
      r.controller.forEach((c) => {
        const b = document.createElement("button");
        b.className = "pulsante f";
        b.textContent = c.nome + (c.connesso ? " · collegato" : c.associato ? " · associato" : " · associa");
        b.addEventListener("click", async () => {
          avviso("Associo " + c.nome + "…", 30000);
          const x = await api("/api/bt/associa", { mac: c.mac });
          avviso(x.ok ? c.nome + " collegato!" : x.errore, 5000);
          if (x.ok) b.textContent = c.nome + " · collegato";
        });
        box.appendChild(b);
      });
      metti($(".f", box));
    } catch (e) { box.textContent = "Il servizio EG PLAY non risponde"; }
    finally { cercando = false; }
  }
  $("#b-cerca").addEventListener("click", cercaBT);

  function dettagli(g) {
    if (!g) return;
    $("#d-nome").textContent = g.nome;
    const dl = $("#d-info");
    dl.textContent = "";
    [["Fonte", g.fonte], ["Ultima partita", quando(g.ultimo) || "—"], ["Spazio", peso(g.dimensione) || "—"],
     ["Stato", g.demo ? "Gioco di esempio (demo)" : g.pronto ? "Installato" : "Download non finito"]]
      .forEach(([k, v]) => { const dt = document.createElement("dt"); dt.textContent = k; const dd = document.createElement("dd"); dd.textContent = v; dl.append(dt, dd); });
    $("#d-gioca").onclick = () => { chiudi(); gioca(g); };
    apri("dettagli");
  }

  function apri(id) {
    if (S.finestra) chiudi();
    S.ritorno = S.fuoco;
    S.finestra = id;
    $("#" + id).classList.remove("nascosta");
    metti($(`#${id} .f`));
  }
  function chiudi() {
    if (!S.finestra) return;
    $("#" + S.finestra).classList.add("nascosta");
    S.finestra = null;
    metti(S.ritorno && document.contains(S.ritorno) ? S.ritorno : primo());
  }

  let tAvviso;
  function avviso(t, ms = 2500) {
    const a = $("#avviso");
    a.textContent = t;
    a.classList.remove("nascosta");
    clearTimeout(tAvviso);
    tAvviso = setTimeout(() => a.classList.add("nascosta"), ms);
  }

  // ------------------------------------------------------------------ fuoco e navigazione "spaziale"
  function metti(el) {
    if (!el) return;
    if (S.fuoco) S.fuoco.classList.remove("sel-f");
    S.fuoco = el;
    el.classList.add("sel-f");
    el.focus({ preventScroll: true });
    el.scrollIntoView({ block: "nearest", inline: "nearest", behavior: "smooth" });
  }

  function visibili() {
    const radice = S.finestra ? $("#" + S.finestra) : document;
    return $$(".f", radice).filter((e) => !e.closest(".nascosta") && e.offsetParent !== null && !e.classList.contains("nascosta"));
  }

  function muovi(dir) {
    const cur = S.fuoco && document.contains(S.fuoco) ? S.fuoco : null;
    if (!cur) return metti(primo());
    const a = cur.getBoundingClientRect();
    const ax = a.left + a.width / 2, ay = a.top + a.height / 2;
    let best = null, bestD = Infinity;
    for (const el of visibili()) {
      if (el === cur) continue;
      const b = el.getBoundingClientRect();
      const bx = b.left + b.width / 2, by = b.top + b.height / 2;
      const dx = bx - ax, dy = by - ay;
      let main, side;
      if (dir === "dx") { if (b.left < a.right - 4 && dx <= 4) continue; main = dx; side = Math.abs(dy); }
      else if (dir === "sx") { if (b.right > a.left + 4 && dx >= -4) continue; main = -dx; side = Math.abs(dy); }
      else if (dir === "giu") { if (b.top < a.bottom - 4 && dy <= 4) continue; main = dy; side = Math.abs(dx); }
      else { if (b.bottom > a.top + 4 && dy >= -4) continue; main = -dy; side = Math.abs(dx); }
      if (main <= 0) continue;
      const d = main + side * 2.5;
      if (d < bestD) { bestD = d; best = el; }
    }
    if (best) {
      metti(best);
      // entrando nella barra in alto non cambio sezione; ci si sposta tra le tab con sx/dx e si apre con A
    }
  }

  function conferma() {
    const el = S.fuoco;
    if (!el) return;
    if (el.classList.contains("tab")) return vaiSez(el.dataset.sez);
    el.click();
  }

  function indietro() {
    if (S.finestra) return chiudi();
    if (S.fuoco && S.fuoco.classList.contains("tab")) return vaiSez("home");
    metti($(`.tab[data-sez="${S.sez}"]`));
  }

  function sezVicina(passo) {
    const i = (SEZ.indexOf(S.sez) + passo + SEZ.length) % SEZ.length;
    if (S.finestra) chiudi();
    vaiSez(SEZ[i], true);
  }

  // ------------------------------------------------------------------ tastiera
  document.addEventListener("keydown", (e) => {
    const k = e.key;
    const map = { ArrowRight: "dx", ArrowLeft: "sx", ArrowDown: "giu", ArrowUp: "su" };
    if (map[k]) { e.preventDefault(); return muovi(map[k]); }
    if (k === "Enter" || k === " ") { e.preventDefault(); return conferma(); }
    if (k === "Escape" || k === "Backspace") { e.preventDefault(); return indietro(); }
    if (k === "y" || k === "Y" || k === "i") return dettagli(S.scelto);
    if (k === "m" || k === "M" || k === "ContextMenu") return S.finestra === "menu" ? chiudi() : apri("menu");
    if (k === "q" || k === "PageUp") return sezVicina(-1);
    if (k === "e" || k === "PageDown") return sezVicina(1);
    if (k === "Tab") { e.preventDefault(); return sezVicina(e.shiftKey ? -1 : 1); }
  });
  // il mouse funziona comunque: il fuoco segue il puntatore
  document.addEventListener("mouseover", (e) => { const f = e.target.closest(".f"); if (f && f !== S.fuoco && (!S.finestra || f.closest("#" + S.finestra))) metti(f); });

  // ------------------------------------------------------------------ controller PlayStation / Xbox / Nintendo
  // Layout "standard" della Gamepad API (per posizione): 0 sotto · 1 destra · 2 sinistra · 3 sopra ·
  // 4 L1/LB/L · 5 R1/RB/R · 8 Select · 9 Start/Options/+ · 12-15 croce direzionale.
  // Nintendo: A (a destra) conferma e B (sotto) torna indietro, come su Switch.
  function famiglia(p) {
    const id = (p.id || "").toLowerCase();
    if (/054c|sony|playstation|dualsense|dualshock|wireless controller/.test(id)) return "ps";
    if (/057e|nintendo|pro controller|joy-con/.test(id)) return "nintendo";
    if (/045e|xbox|x-box|microsoft/.test(id)) return "xbox";
    return "generico";
  }
  const GLIFI = {
    ps: { ok: ["✕", "ps-x"], no: ["○", "ps-o"], info: ["△", "ps-t"], menu: "Options", l: "L1", r: "R1", nome: "PlayStation" },
    xbox: { ok: ["A", "a"], no: ["B", "b"], info: ["Y", "y"], menu: "☰", l: "LB", r: "RB", nome: "Xbox" },
    nintendo: { ok: ["A", "n-a"], no: ["B", "n-b"], info: ["X", "n-x"], menu: "+", l: "L", r: "R", nome: "Nintendo" },
    generico: { ok: ["A", "a"], no: ["B", "b"], info: ["Y", "y"], menu: "☰", l: "LB", r: "RB", nome: "Controller" },
  };
  let ultimaFam = null;
  function glifi(fam) {
    if (fam === ultimaFam) return;
    ultimaFam = fam;
    const g = GLIFI[fam];
    const set = (id, [t, cls]) => { const e = $(id); e.textContent = t; e.className = "tasto " + cls; };
    set("#t-ok", g.ok); set("#t-no", g.no); set("#t-info", g.info);
    $("#t-menu").textContent = g.menu; $("#t-l").textContent = g.l; $("#t-r").textContent = g.r;
  }
  function tasti(p, fam) {
    if (p.mapping === "standard") {
      return fam === "nintendo" ? { ok: 1, no: 0, info: 3 } : { ok: 0, no: 1, info: 3 };
    }
    // controller non riconosciuto dal browser: ordine dei tasti di Linux (sud, est, nord, ovest)
    return { ok: 0, no: 1, info: 2 };
  }
  const prima = {};
  const ripeti = { dir: null, da: 0, prossimo: 0 };
  function premuto(p, i) { const b = p.buttons[i]; return !!b && (b.pressed || b.value > 0.5); }
  function giro() {
    setTimeout(giro, 16);
    const pads = navigator.getGamepads ? [...navigator.getGamepads()].filter(Boolean) : [];
    const ora = performance.now();
    let dir = null;
    // mentre giochi EG PLAY resta aperto dietro: i tasti premuti nel gioco NON devono arrivare qui
    if (!document.hasFocus()) {
      pads.forEach((p) => p.buttons.forEach((_, i) => { prima[p.index + ":" + i] = premuto(p, i); }));
      ripeti.dir = "fermo";
      return;
    }
    for (const p of pads) {
      const fam = famiglia(p), k = tasti(p, fam);
      const giu = (i) => premuto(p, i) && !prima[p.index + ":" + i];
      let usato = false;
      if (giu(k.ok)) { conferma(); usato = true; }
      if (giu(k.no)) { indietro(); usato = true; }
      if (giu(k.info)) { dettagli(S.scelto); usato = true; }
      if (giu(9) || giu(8)) { S.finestra === "menu" ? chiudi() : apri("menu"); usato = true; }
      if (giu(4)) { sezVicina(-1); usato = true; }
      if (giu(5)) { sezVicina(1); usato = true; }
      const ax = p.axes[0] || 0, ay = p.axes[1] || 0;
      // croce direzionale come "hat" (controller non standard): di solito gli ultimi due assi
      const hx = p.mapping === "standard" ? 0 : (p.axes.length >= 8 ? p.axes[6] : 0);
      const hy = p.mapping === "standard" ? 0 : (p.axes.length >= 8 ? p.axes[7] : 0);
      if (premuto(p, 15) || ax > 0.55 || hx > 0.5) dir = "dx";
      else if (premuto(p, 14) || ax < -0.55 || hx < -0.5) dir = "sx";
      else if (premuto(p, 13) || ay > 0.55 || hy > 0.5) dir = "giu";
      else if (premuto(p, 12) || ay < -0.55 || hy < -0.5) dir = "su";
      if (usato || dir) glifi(fam);
      p.buttons.forEach((_, i) => { prima[p.index + ":" + i] = premuto(p, i); });
    }
    // direzione tenuta premuta: un passo subito, poi ripete
    if (dir && dir !== ripeti.dir) { muovi(dir); ripeti.dir = dir; ripeti.prossimo = ora + 380; }
    else if (dir && ora >= ripeti.prossimo) { muovi(dir); ripeti.prossimo = ora + 120; }
    else if (!dir) ripeti.dir = null;
  }
  function aggiornaPad() {
    const pads = navigator.getGamepads ? [...navigator.getGamepads()].filter(Boolean) : [];
    const el = $("#pad");
    el.textContent = pads.length ? "🎮 " + GLIFI[famiglia(pads[0])].nome : "⌨ Tastiera";
    el.classList.toggle("on", pads.length > 0);
    const ul = $("#pad-lista");
    ul.textContent = "";
    pads.forEach((p) => {
      const li = document.createElement("li");
      li.textContent = `🎮 ${GLIFI[famiglia(p)].nome}: ${nomePad(p)}`;
      ul.appendChild(li);
    });
    if (pads.length) glifi(famiglia(pads[0]));
  }
  // Firefox: "054c-0ce6-Sony ... Controller"; Chrome: "Nome (STANDARD GAMEPAD Vendor: ...)"
  function nomePad(p) { return p.id.replace(/^[0-9a-f]{1,4}-[0-9a-f]{1,4}-/i, "").split("(")[0].trim() || "controller"; }
  window.addEventListener("gamepadconnected", (e) => { aggiornaPad(); avviso(GLIFI[famiglia(e.gamepad)].nome + " collegato: " + nomePad(e.gamepad), 3000); });
  window.addEventListener("gamepaddisconnected", aggiornaPad);

  // ------------------------------------------------------------------ pulsanti
  $$(".tab").forEach((t) => t.addEventListener("click", () => vaiSez(t.dataset.sez, true)));
  $$("#filtri .chip").forEach((c) => c.addEventListener("click", () => { S.filtro = c.dataset.filtro; griglia(); metti(c); }));
  $$("[data-apri]").forEach((b) => b.addEventListener("click", () => { if (S.finestra) chiudi(); apriCosa(b.dataset.apri); }));
  $$("[data-vai]").forEach((b) => b.addEventListener("click", () => { chiudi(); vaiSez(b.dataset.vai); }));
  $("#b-gioca").addEventListener("click", () => gioca(S.scelto));
  $("#b-dettagli").addEventListener("click", () => dettagli(S.scelto));
  $("#d-chiudi").addEventListener("click", chiudi);
  $("#m-chiudi").addEventListener("click", chiudi);
  $("#bl-chiudi").addEventListener("click", chiudi);

  function orologio() {
    $("#ora").textContent = new Date().toLocaleTimeString("it-IT", { hour: "2-digit", minute: "2-digit" });
  }

  // ------------------------------------------------------------------ avvio
  async function carica() {
    try {
      const [st, giochi] = await Promise.all([api("/api/stato"), api("/api/giochi")]);
      S.stato = st;
      S.giochi = giochi;
    } catch (e) {
      S.stato = { licenza: false };
      S.giochi = [];
      avviso("Il servizio EG PLAY non risponde", 5000);
    }
    $("#utente").textContent = S.stato.utente ? "● " + S.stato.utente : "";
    $("#amici-account").textContent = S.stato.utente ? `Account EMAGIAKU collegato: ${S.stato.utente}` : "Collega l'Account EMAGIAKU dalle Impostazioni.";
    $("#dl-versione").textContent = S.stato.versione ? `EMAGIAKU GLASS OS ${S.stato.versione}` : "";
    if (S.stato.demo) avviso("Modalità demo: i giochi mostrati sono esempi", 4000);
    mostraOS();
    disegna();
    metti(primo());
    if (!S.stato.licenza) apri("blocco");
  }

  orologio();
  setInterval(orologio, 10000);
  aggiornaPad();
  giro();
  carica();
})();
