"""EG UPDATE - aggiornamenti di EMAGIAKU GLASS OS (logica, senza interfaccia).

Gli aggiornamenti sono pubblicati su GitHub (repository EMAGIAKU/EMAGIAKU-GLASSOS-27):
  updates/latest.json   {"version", "notes", "file", "sha256", "size", "packages"}
  updates/latest.sig    firma Ed25519 di latest.json (chiave privata solo sul PC di EMAGIAKU.TEAM)
  updates/<file>.tar.gz i file aggiornati
La firma di latest.json copre anche lo sha256 del pacchetto: se qualcuno cambia anche un solo byte,
l'aggiornamento viene rifiutato.
"""
import json
import os
import re
import subprocess
import tempfile
import urllib.error
import urllib.request

BASE_URL = "https://raw.githubusercontent.com/EMAGIAKU/EMAGIAKU-GLASSOS-27/main/updates/"
PUBKEY = "/usr/share/emagiaku/update-key.pem"
VERSION_FILE = "/etc/emagiaku/version"
BASE_VERSION = "27.0"          # versione dell'ISO uscita senza file di versione
UA = {"User-Agent": "EMAGIAKU-GLASS-OS-Update"}


def installed_version():
    try:
        with open(VERSION_FILE, encoding="utf-8") as f:
            v = f.read().strip()
            return v or BASE_VERSION
    except OSError:
        return BASE_VERSION


def vtuple(v):
    return tuple(int(x) for x in re.findall(r"\d+", v)) or (0,)


def is_newer(remote, local):
    return vtuple(remote) > vtuple(local)


def _get(url, timeout=30):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def verify_signature(data, sig, pubkey=PUBKEY):
    """Verifica Ed25519 con openssl. True solo se la firma e' valida."""
    with tempfile.TemporaryDirectory() as d:
        dp, sp = os.path.join(d, "data"), os.path.join(d, "sig")
        with open(dp, "wb") as f:
            f.write(data)
        with open(sp, "wb") as f:
            f.write(sig)
        r = subprocess.run(["openssl", "pkeyutl", "-verify", "-pubin", "-inkey", pubkey, "-rawin",
                            "-in", dp, "-sigfile", sp], capture_output=True)
        return r.returncode == 0


def check(timeout=30):
    """Restituisce (manifest, None) se c'e' un aggiornamento firmato e piu' nuovo,
    (None, None) se il sistema e' aggiornato, (None, errore) se qualcosa non va."""
    try:
        raw = _get(BASE_URL + "latest.json", timeout)
        sig = _get(BASE_URL + "latest.sig", timeout)
    except (urllib.error.URLError, OSError) as e:
        return None, "Nessuna connessione al server degli aggiornamenti (%s)" % getattr(e, "reason", e)
    if not verify_signature(raw, sig):
        return None, "Aggiornamento rifiutato: firma non valida."
    try:
        m = json.loads(raw.decode("utf-8"))
        assert re.match(r"^[0-9][0-9.]{0,15}$", m["version"])
        assert re.match(r"^[A-Za-z0-9._-]{1,80}\.tar\.gz$", m["file"])
        assert re.match(r"^[0-9a-f]{64}$", m["sha256"])
        for p in m.get("packages", []):
            assert re.match(r"^[a-z0-9@._+-]{1,60}$", p)
    except (ValueError, KeyError, AssertionError):
        return None, "Aggiornamento rifiutato: descrizione non valida."
    if not is_newer(m["version"], installed_version()):
        return None, None
    m["_raw"] = raw.decode("utf-8")
    m["_sig"] = sig.hex()
    return m, None


def download(m, dest_dir, progress=None):
    """Scarica il pacchetto e controlla lo sha256. Restituisce il percorso del file."""
    import hashlib
    path = os.path.join(dest_dir, m["file"])
    req = urllib.request.Request(BASE_URL + m["file"], headers=UA)
    h = hashlib.sha256()
    done, total = 0, int(m.get("size") or 0)
    with urllib.request.urlopen(req, timeout=60) as r, open(path, "wb") as f:
        while True:
            chunk = r.read(65536)
            if not chunk:
                break
            f.write(chunk)
            h.update(chunk)
            done += len(chunk)
            if progress and total:
                progress(min(100, done * 100 // total))
    if h.hexdigest() != m["sha256"]:
        os.remove(path)
        raise ValueError("il file scaricato non corrisponde (sha256 diverso)")
    # manifest e firma accanto al pacchetto: l'installatore (root) li ricontrolla da solo
    with open(path + ".json", "w", encoding="utf-8") as f:
        f.write(m["_raw"])
    with open(path + ".sig", "wb") as f:
        f.write(bytes.fromhex(m["_sig"]))
    return path
