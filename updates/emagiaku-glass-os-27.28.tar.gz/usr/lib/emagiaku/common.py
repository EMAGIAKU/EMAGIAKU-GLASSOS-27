#!/usr/bin/env python3
"""EMAGIAKU GLASS OS - funzioni comuni (Glass Engine + Benvenuto).

Tutto quello che e' qui sotto usa strumenti standard di KDE Plasma
(kwriteconfig6, plasma-apply-*, dbus-send). Nessuna funzione e' finta:
se un comando non esiste, run() restituisce False e l'interfaccia lo dice.
"""
import json
import os
import re
import shutil
import subprocess
import sys

HOME = os.path.expanduser("~")
CONF_DIR = os.path.join(HOME, ".config", "emagiaku")
CONF_FILE = os.path.join(CONF_DIR, "glass.json")
WALL_DIR = "/usr/share/wallpapers"

DEFAULTS = {
    "theme": "dark",          # dark | light
    "blur": 8,                # 1..15 (BlurStrength di KWin)
    "motion": "standard",     # off | light | standard | fluid
    "window_buttons": "macos",  # macos | windows | linux
    "layout": "glass",        # glass | windows | macos | linux
    "language": "it",         # it | en
    "origin": "",             # windows | linux | macos (scelta nel benvenuto)
    "app_glass": 30,          # 0 = sfondo pieno ... 100 = sfondo molto trasparente (testo sempre pieno)
    "dock_glass": 45,
    "accent": "",             # "" = quello del tema
    "dock_position": "bottom",  # bottom | left | right | top
    "dock_size": 0,           # 0 = automatica
    "cursor_theme": "",
    "cursor_size": 24,
    "pointer_speed": 0,       # -10 .. 10
    "natural_scroll": False,
    "left_handed": False,
    "night_light": False,
    "night_temp": 4500,
    "light_mode": False,      # modalita' leggera per PC poco potenti
    "wallpaper": "",
    # --- v13: personalizzazione completa
    "icon_theme": "",         # "" = quello del tema
    "font_family": "",        # "" = predefinito (Noto Sans)
    "font_size": 10,
    "topbar_show": True,      # barra in alto (disposizioni Glass/macOS)
    "topbar_height": 28,
    "topbar_floating": False,
    "clock_seconds": False,
    "widgets": [],            # widget sul desktop (chiavi di WIDGETS)
    "slideshow": False,       # sfondo che cambia da solo
    "slideshow_minutes": 15,
    "wobbly": False,          # finestre "gelatina"
    "minimize_anim": "magiclamp",   # magiclamp | squash | none
    "lock_wallpaper": "",     # sfondo della schermata di blocco ("" = quello EMAGIAKU di serie)
}

MOTION_FACTOR = {"off": "0", "light": "0.5", "standard": "1", "fluid": "1.6"}
BUTTONS = {            # (a sinistra, a destra) - X=chiudi I=riduci A=ingrandisci
    "macos": ("XIA", ""),
    "windows": ("", "IAX"),
    "linux": ("", "IAX"),
}

TEXT = {
    "it": {
        "title": "Glass Engine",
        "theme": "Tema",
        "dark": "Scuro",
        "light": "Chiaro",
        "blur": "Intensità del blur",
        "buttons": "Pulsanti finestra",
        "layout": "Disposizione barre",
        "motion": "Movimento",
        "m_off": "Spento",
        "m_light": "Leggero",
        "m_standard": "Standard",
        "m_fluid": "Fluido",
        "wallpaper": "Sfondo",
        "w_welcome": "Benvenuto (scuro)",
        "w_light": "Glass chiaro",
        "w_pick": "Scegli file...",
        "apply": "Applica",
        "applied": "Applicato.",
        "failed": "Non riuscito: ",
        "edition": "Edizione",
        "std": "Edizione: Standard",
        "pro": "Edizione: EGGLASS OS PRO",
        "key": "Chiave PRO",
        "activate": "Attiva chiave",
        "badkey": "Chiave non valida.",
        "w_title": "Benvenuto in EMAGIAKU GLASS OS",
        "w_sub": "Da quale sistema operativo provieni?",
        "w_hint": "Sistemiamo pulsanti e barre in modo che ti sembri di casa. Potrai cambiare tutto dopo in Glass Engine.",
        "lang": "Lingua",
        "lang_note": "La lingua cambia al prossimo accesso.",
        "windows": "Windows",
        "macos": "macOS",
        "linux": "Linux",
        "skip": "Salta",
        "glass": "Glass (consigliato)",
        "dev": "Versione di sviluppo: alcune funzioni del progetto non esistono ancora.",
    },
    "en": {
        "title": "Glass Engine",
        "theme": "Theme",
        "dark": "Dark",
        "light": "Light",
        "blur": "Blur strength",
        "buttons": "Window buttons",
        "layout": "Bar layout",
        "motion": "Motion",
        "m_off": "Off",
        "m_light": "Light",
        "m_standard": "Standard",
        "m_fluid": "Fluid",
        "wallpaper": "Wallpaper",
        "w_welcome": "Welcome (dark)",
        "w_light": "Glass light",
        "w_pick": "Choose file...",
        "apply": "Apply",
        "applied": "Applied.",
        "failed": "Failed: ",
        "edition": "Edition",
        "std": "Edition: Standard",
        "pro": "Edition: EGGLASS OS PRO",
        "key": "PRO key",
        "activate": "Activate key",
        "badkey": "Invalid key.",
        "w_title": "Welcome to EMAGIAKU GLASS OS",
        "w_sub": "Which operating system are you coming from?",
        "w_hint": "We will set buttons and bars so it feels familiar. You can change everything later in Glass Engine.",
        "lang": "Language",
        "lang_note": "Language changes at next login.",
        "windows": "Windows",
        "macos": "macOS",
        "linux": "Linux",
        "skip": "Skip",
        "glass": "Glass (recommended)",
        "dev": "Development build: some planned features do not exist yet.",
    },
}


TEXT_EXTRA = {
    "it": {"screens": "Schermi e TV", "s_single": "Solo questo PC", "s_mirror": "Duplica su secondo schermo / TV",
           "s_extend": "Estendi (secondo schermo a destra)", "s_tv": "Solo secondo schermo / TV",
           "s_apply": "Applica schermi", "cast": "Trasmetti su TV via Wi-Fi", "advanced": "Schermi avanzati",
           "nocast": "EG Cast non e' installato in questa ISO."},
    "en": {"screens": "Screens and TV", "s_single": "This PC only", "s_mirror": "Mirror to second screen / TV",
           "s_extend": "Extend (second screen on the right)", "s_tv": "Second screen / TV only",
           "s_apply": "Apply screens", "cast": "Cast to TV over Wi-Fi", "advanced": "Advanced displays",
           "nocast": "EG Cast is not installed in this ISO."},
}
for _k, _v in TEXT_EXTRA.items():
    TEXT[_k].update(_v)


def load_conf():
    conf = dict(DEFAULTS)
    try:
        with open(CONF_FILE, "r", encoding="utf-8") as f:
            conf.update(json.load(f))
    except (OSError, ValueError):
        pass
    return conf


def save_conf(conf):
    os.makedirs(CONF_DIR, exist_ok=True)
    with open(CONF_FILE, "w", encoding="utf-8") as f:
        json.dump(conf, f, indent=2)


def current_lang():
    conf = load_conf()
    if conf.get("language") in TEXT:
        return conf["language"]
    return "it" if os.environ.get("LANG", "").startswith("it") else "en"


def run(cmd):
    """Esegue un comando; True se riesce."""
    if shutil.which(cmd[0]) is None:
        return False
    try:
        return subprocess.run(cmd, check=False, timeout=60,
                              stdout=subprocess.DEVNULL,
                              stderr=subprocess.DEVNULL).returncode == 0
    except (OSError, subprocess.SubprocessError):
        return False


def kw(file, group, key, value):
    cmd = ["kwriteconfig6", "--file", file]
    for g in group.split("/"):
        cmd += ["--group", g]
    return run(cmd + ["--key", key, str(value)])


def dbus_call(dest, path, method, *args):
    return run(["dbus-send", "--session", "--type=method_call",
                "--dest=" + dest, path, method] + list(args))


def kwin_reconfigure():
    dbus_call("org.kde.KWin", "/KWin", "org.kde.KWin.reconfigure")


def plasma_script(js):
    return dbus_call("org.kde.plasmashell", "/PlasmaShell",
                     "org.kde.PlasmaShell.evaluateScript", "string:" + js)


# ---------------------------------------------------------------- tema
def apply_theme(theme):
    """Applica tema globale + schema colori + tema Plasma, sempre insieme,
    cosi' passare da chiaro a scuro (e viceversa) funziona sempre."""
    dark = theme == "dark"
    scheme = "EmagiakuGlass" if dark else "EmagiakuGlassLight"
    laf = "org.emagiaku.glass." + ("dark" if dark else "light")
    ok = run(["plasma-apply-lookandfeel", "-a", laf])
    ok = run(["plasma-apply-colorscheme", scheme]) or ok
    # scrittura esplicita nel caso gli strumenti sopra non siano presenti
    kw("kdeglobals", "General", "ColorScheme", scheme)
    kw("kdeglobals", "KDE", "LookAndFeelPackage", laf)
    # tema Plasma EMAGIAKU Glass (dock con glass regolabile) al posto di Breeze
    conf = load_conf()
    try:
        apply_dock_glass(theme, 0 if conf.get("light_mode") else conf.get("dock_glass", 45))
    except OSError:
        kw("plasmarc", "Theme", "name", "breeze-dark" if dark else "default")
    # schermata di avvio EMAGIAKU GLASS OS (non quella di Breeze)
    kw("ksplashrc", "KSplash", "Engine", "KSplashQML")
    kw("ksplashrc", "KSplash", "Theme", laf)
    return ok


# --------------------------------------------------------------- sfondo
def apply_wallpaper(path):
    if os.path.isdir(path):
        for name in ("3840x2160.jpg", "3840x2160.png", "1920x1080.png"):
            cand = os.path.join(path, "contents", "images", name)
            if os.path.exists(cand):
                path = cand
                break
    return run(["plasma-apply-wallpaperimage", path])


def image_from(path):
    """Cartella di sfondo EMAGIAKU -> file immagine; file -> se stesso."""
    if os.path.isdir(path):
        for name in ("3840x2160.jpg", "3840x2160.png", "1920x1080.png", "1920x1080.jpg"):
            cand = os.path.join(path, "contents", "images", name)
            if os.path.exists(cand):
                return cand
        return None
    return path if os.path.isfile(path) else None


def apply_lock_wallpaper(path):
    """Sfondo della schermata di blocco (quella che compare quando blocchi o sospendi)."""
    img = image_from(path)
    if not img:
        return False
    url = "file://" + img
    g = "Greeter/Wallpaper/org.kde.image/General"
    kw("kscreenlockerrc", "Greeter", "WallpaperPlugin", "org.kde.image")
    ok = kw("kscreenlockerrc", g, "Image", url)
    kw("kscreenlockerrc", g, "PreviewImage", url)
    conf = load_conf()
    conf["lock_wallpaper"] = img
    save_conf(conf)
    return ok


def apply_login_wallpaper(path):
    """Sfondo anche della schermata di accesso (password all'avvio): vale per tutto il PC,
    quindi passa da un piccolo programma di sistema che chiede la password di amministratore."""
    img = image_from(path)
    if not img:
        return False
    import logic
    try:
        r = subprocess.run(logic.root_prefix() + ["/usr/bin/emagiaku-set-login-bg", img], timeout=180,
                           capture_output=True)
        return r.returncode == 0
    except (OSError, subprocess.SubprocessError):
        return False


def wallpaper_path(key):
    ident = {"welcome": "EmagiakuWelcome", "light": "EmagiakuGlassLight"}[key]
    return os.path.join(WALL_DIR, ident)


# ----------------------------------------------------- blur / movimento
def apply_blur(strength):
    kw("kwinrc", "Plugins", "blurEnabled", "true")
    kw("kwinrc", "Effect-blur", "BlurStrength", int(strength))
    kwin_reconfigure()


def apply_motion(mode):
    kw("kdeglobals", "KDE", "AnimationDurationFactor",
       MOTION_FACTOR.get(mode, "1"))
    kwin_reconfigure()


def apply_buttons(style):
    left, right = BUTTONS.get(style, BUTTONS["macos"])
    kw("kwinrc", "org.kde.kdecoration2", "ButtonsOnLeft", left)
    kw("kwinrc", "org.kde.kdecoration2", "ButtonsOnRight", right)
    kwin_reconfigure()


# --------------------------------------------------------------- barre
def _clock_js(var, seconds):
    """Aggiunge l'orologio; con seconds=True mostra anche i secondi."""
    js = "var ck=%s.addWidget('org.kde.plasma.digitalclock');" % var
    if seconds:
        js += ("ck.currentConfigGroup=['Appearance'];ck.writeConfig('showSeconds','Always');")
    return js


MENU_ICON = "emagiaku-menu-symbolic"   # solo "EG" bianco, senza sfondo
# app fissate nel dock / barra (Glass Engine sempre a portata di mano)
PINNED = ["emagiaku-glass-engine.desktop", "emagiaku-settings.desktop", "emagiaku-files.desktop",
          "firefox.desktop", "emagiaku-store.desktop", "emagiaku-egpt.desktop"]


def _panel_js(layout, pos="bottom", size=None, top=None):
    """Script Plasma delle barre: tasto menu con icona EG e app fissate nel dock."""
    import re as _re
    js = _panel_js_raw(layout, pos, size, top)
    js = _re.sub(r"(\w+)\.addWidget\('org\.kde\.plasma\.kickoff'\);",
                 lambda m: ("var km=%s.addWidget('org.kde.plasma.kickoff');"
                            "km.currentConfigGroup=['General'];km.writeConfig('icon','%s');"
                            % (m.group(1), MENU_ICON)), js)
    pinned = list(PINNED)
    if has_study():   # edizione STUDY: Study Hub fisso nel dock, subito dopo Glass Engine
        pinned.insert(1, "emagiaku-study-hub.desktop")
    launchers = ",".join("applications:" + p for p in pinned)
    js = _re.sub(r"(\w+)\.addWidget\('org\.kde\.plasma\.icontasks'\);",
                 lambda m: ("var tk=%s.addWidget('org.kde.plasma.icontasks');"
                            "tk.currentConfigGroup=['General'];tk.writeConfig('launchers','%s');"
                            % (m.group(1), launchers)), js)
    return js


def _panel_js_raw(layout, pos="bottom", size=None, top=None):
    if pos not in ("bottom", "top", "left", "right"):
        pos = "bottom"
    top = top or {}
    show_top = top.get("show", True)
    th = max(20, min(64, int(top.get("height", 28))))
    tfloat = "true" if top.get("floating") else "false"
    secs = bool(top.get("seconds"))
    head = ("var old=panels();for(var i=0;i<old.length;i++){old[i].remove();}\n")
    if layout in ("glass", "macos"):
        # barra in alto (si puo' nascondere) + dock fluttuante (posizione e dimensione scelte dall'utente)
        n = int(size or 56)
        if pos == "top" and show_top:
            pos = "bottom"      # due barre in alto si sovrapporrebbero
        topjs = ""
        if show_top:
            topjs = ("var t=new Panel();t.location='top';t.height=%d;t.floating=%s;"
                     "t.addWidget('org.kde.plasma.kickoff');"
                     "t.addWidget('org.kde.plasma.panelspacer');"
                     "t.addWidget('org.kde.plasma.systemtray');" % (th, tfloat)) + _clock_js("t", secs) + "\n"
        dock = ("var d=new Panel();d.location='%s';d.height=%d;d.floating=true;"
                "d.alignment='center';d.lengthMode='fit';" % (pos, n))
        if not show_top:   # senza barra in alto, menu/tray/orologio vanno nel dock
            dock += "d.addWidget('org.kde.plasma.kickoff');"
        dock += "d.addWidget('org.kde.plasma.icontasks');"
        if not show_top:
            dock += "d.addWidget('org.kde.plasma.systemtray');" + _clock_js("d", secs)
        return head + topjs + dock + "\n"
    if layout == "windows":
        n = int(size or 44)
        return head + (
            "var p=new Panel();p.location='%s';p.height=%d;p.floating=false;"
            "p.alignment='left';p.lengthMode='fill';"
            "p.addWidget('org.kde.plasma.kickoff');"
            "p.addWidget('org.kde.plasma.icontasks');"
            "p.addWidget('org.kde.plasma.systemtray');"
            "p.addWidget('org.kde.plasma.digitalclock');\n" % (pos, n))
    n = int(size or 40)
    return head + (
        "var p=new Panel();p.location='%s';p.height=%d;p.floating=false;"
        "p.lengthMode='fill';"
        "p.addWidget('org.kde.plasma.kickoff');"
        "p.addWidget('org.kde.plasma.pager');"
        "p.addWidget('org.kde.plasma.icontasks');"
        "p.addWidget('org.kde.plasma.systemtray');"
        "p.addWidget('org.kde.plasma.digitalclock');\n" % (pos, n))


def topbar_opts(conf):
    return {"show": conf.get("topbar_show", True), "height": conf.get("topbar_height", 28),
            "floating": conf.get("topbar_floating", False), "seconds": conf.get("clock_seconds", False)}


def apply_layout(layout, pos="bottom", size=None, top=None):
    if top is None:
        top = topbar_opts(load_conf())
    return plasma_script(_panel_js(layout, pos, size, top))


PRESETS = {  # scelta "provengo da..." -> (layout, pulsanti)
    "windows": ("windows", "windows"),
    "macos": ("macos", "macos"),
    "linux": ("linux", "linux"),
    "glass": ("glass", "macos"),
}


def apply_preset(name):
    layout, buttons = PRESETS[name]
    conf = load_conf()
    apply_buttons(buttons)
    ok = apply_layout(layout, conf.get("dock_position", "bottom"), conf.get("dock_size") or None)
    conf["layout"] = layout
    conf["window_buttons"] = buttons
    conf["origin"] = name
    save_conf(conf)
    return ok


# --------------------------------------------------------------- lingua
def apply_language(lang):
    locale = "it_IT.UTF-8" if lang == "it" else "en_US.UTF-8"
    kw("plasma-localerc", "Formats", "LANG", locale)
    kw("plasma-localerc", "Translations", "LANGUAGE", "it" if lang == "it" else "en_US")
    conf = load_conf()
    conf["language"] = lang
    save_conf(conf)


# ------------------------------------------------------- edizione PRO
# Nell'ISO ci sono solo le impronte SHA-256 delle chiavi, non le chiavi.
# Controllo locale e offline: NON impedisce di usare la stessa chiave su piu' PC.
KEY_SALT = "EMAGIAKU-GLASS-OS-27"
KEY_HASHES = {
    "090f39a9cdae8e50cd3d3640c45bbaa6b39f34dbc8c2a2affd9c6bdd8c594700": "admin",
    "6cfd7678de62b6603678e0a32c9a17aa8ef84b6c779de44b8020e68321560e6d": "pro",
    "a9cc9d7f0a08497502edddbc392f239123e2d27a244eb4e18f5e483cc631a0ed": "pro",
    "3eaa9349a6dbe221d49e92391d6fd5c8eed9f5829d39729df1a932a43e25f41d": "pro",
    "8733047f21a30678549155ea654bdc55f14d10e94e3c070e8bb4b763b6f76e0d": "pro",
    # EMAGIAKU GLASS OS 27 STUDY
    "2d21a227b0592f5b3982ca89387fbfc346720e542295e75b853740cec3c67632": "study",
    "008e2db86fa2f18362918402be46e696bcdde33b430872301bb99f7a42c9caa1": "study",
    "c31c6bfac604e955c6ef9b6279ceb55d7d164a5db94384cb4600da00b1b55f0f": "study",
    "682adf0412ea01c2f37bd39c326294a5f569d4108eff6c404ad49f2122a6e4d9": "study",
    # (la chiave di prova EG12345 e' stata tolta nella versione pubblica)
    # chiave PREMIO YouTube (EGYT-...): PRO + STUDY. Per disattivarla in futuro: togliere questa riga.
    "e8061e0e4139d047c05c1b899f972f34f6a2445b141415021b5cce1eede7813d": "prize",
    # EG PLAY (27.22): solo EG PLAY OS (PRO lo include gia')
    "b4817235a07c8eeac1362ad95d6c967162fed4eca91519af3e5cac59972a0295": "play",
    "b2ceed07dce2c710d7ce9c2d9f3a9a5ed31438a79b732d2e54a37647edbe9016": "play",
    "6eb00047ce73f8c1d206b2fba460c07b909def584de8c259786d314ea850bc8f": "play",
    "26e778de63092fe0635ca57d422067ff12e01f39ed89f7a806dfd724a7a36360": "play",
    # EG PLUS (27.26): abbonamenti Essential / Mega / Max (chiavi EGPLS-..., file a parte: ~/.config/emagiaku/plus)
    "6e4cb57c6d6133053fd169e03b2997f0a16de22fca3c6df0d49cc9dd107b2992": "plus_max_life",
    "5a3c8570dc811c7fbaeddcd4562d4d6e5c4c276f771acdcac150a6cd1ee48214": "plus_essential",
    "bc9c1a4541322ae9062271e39858ab848cbf06a87544eada0063cbe0648e17be": "plus_essential",
    "bb3ac1e99e2d78602dd6a1015e7104f97c965ed1c1c1c54129eba45677e8311a": "plus_essential",
    "3f30fec02a3a50b11c0dd4e1db1d5a7ffc4ba05e18c30e1307cbecd3fdb1e0b6": "plus_essential",
    "8fe89c95dff9f763839792e46a69864ea45ab331849c108980b5f3a74b4ecae4": "plus_mega",
    "d360569405d10e9da208a04d0dc653a52eafc06764be5bda4b673e44afb5031c": "plus_mega",
    "f429af0dbed2cdd0a43b64fa6518619389478b48577dfc43e47724ec13370595": "plus_mega",
    "9d5e2e44535554019940a7a4b48bfa652eafa98783950bb1325b59cd74afe17a": "plus_mega",
    "3050a4f6c5458563ef1634f45c81871b1a649dd67c32a43f179881a664208289": "plus_max",
    "fd03abfd6abf9d8b5524d1578c97bb9fe301d25ef0833de89e8c12c33d9f9e21": "plus_max",
    "ea848de60f411a36e2339c6cd5426b7b8cdbfb9c4b5d75ef7e92a83f91252512": "plus_max",
    "f5c650e2c4b4fbbdf4e885a2ab1c5a0b75cd223e884809ca315808db00fb6698": "plus_max",
}
# acquisto: link PayPal.me di EMAGIAKU (pagamento nel browser; la chiave arriva per email)
# 27.22: PRO 35 euro (include EG PLAY + 2 mesi di EG PLAY CLOUD PRO), EG PLAY da solo 15 euro
BUY_LINKS = {"pro": "https://paypal.me/EMAGIAKU/35EUR", "study": "https://paypal.me/EMAGIAKU/5EUR",
             "play": "https://paypal.me/EMAGIAKU/15EUR"}
BUY_PRICES = {"pro": "35 €", "study": "5 €", "play": "15 €"}

# app dell'edizione STUDY (visibili nel menu solo con STUDY o amministratore)
STUDY_APPS = ["emagiaku-study-hub", "emagiaku-notes", "emagiaku-focus", "emagiaku-calc",
              "emagiaku-library", "emagiaku-ai-study"]
LICENSE_FILE = os.path.join(CONF_DIR, "license")
PRO_FILE = os.path.join(CONF_DIR, "pro.json")
PRO_DEFAULTS = {
    "game_mode": "auto",     # auto (solo se il PC e' datato) | on | off
    "countdown": 10,         # secondi prima di chiudere le app
    "keep": [],              # parole: unita'/app da NON chiudere mai (es. "discord")
    "min_ram_gb": 8,         # sotto questa RAM il PC e' "datato"
    "min_threads": 6,        # sotto questi thread CPU il PC e' "datato"
    "promo_hidden": False,
    "scan": None,
}


def _key_hash(key):
    import hashlib
    return hashlib.sha256((KEY_SALT + key.strip().upper()).encode()).hexdigest()


def key_role(key):
    """'admin', 'pro' oppure None."""
    return KEY_HASHES.get(_key_hash(key))


def check_key(key):
    return key_role(key) is not None


def _license_role():
    """Nel file c'e' la CHIAVE (non l'impronta): copiare un'impronta dal codice non basta."""
    try:
        with open(LICENSE_FILE, encoding="utf-8") as f:
            return key_role(f.read().strip())
    except OSError:
        return None


def license_role():
    """'admin' | 'pro' | 'study' | None"""
    return _license_role()


FULL_ROLES = ("admin", "test", "prize")   # PRO + STUDY insieme


def has_pro():
    return _license_role() in ("pro",) + FULL_ROLES


def has_study():
    return _license_role() in ("study",) + FULL_ROLES


def has_play():
    """EG PLAY OS: incluso in PRO (anche amministratore/prova/premio) oppure chiave EG PLAY separata.
    27.26: anche un abbonamento EG PLUS attivo include EG PLAY."""
    return _license_role() in ("pro", "play") + FULL_ROLES or bool(plus_role())


# ------------------------------------------------------- EG PLUS (27.26)
# Abbonamenti di EG PLAY: chiave EGPLS-... in un file a parte (non sostituisce la licenza PRO / PLAY).
PLUS_FILE = os.path.join(CONF_DIR, "plus")
PLUS_LEVEL = {"plus_essential": 1, "plus_mega": 2, "plus_max": 3, "plus_max_life": 3}


def plus_role():
    """'plus_essential' | 'plus_mega' | 'plus_max' | 'plus_max_life' | None"""
    try:
        with open(PLUS_FILE, encoding="utf-8") as f:
            role = key_role(f.read().strip())
    except OSError:
        return None
    return role if role in PLUS_LEVEL else None


def _write_plus(key):
    os.makedirs(CONF_DIR, exist_ok=True)
    fd = os.open(PLUS_FILE, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        f.write(key.strip().upper() + "\n")


def edition():
    """'pro' (anche amministratore e chiave di prova), 'study' oppure 'standard'."""
    role = _license_role()
    if role in ("pro",) + FULL_ROLES:
        return "pro"
    if role == "study":
        return "study"
    return "standard"


EDITION_NAMES = {"standard": "EMAGIAKU GLASS OS 27 STANDARD", "pro": "EMAGIAKU GLASS OS 27 PRO",
                 "study": "EMAGIAKU GLASS OS 27 STUDY", "admin": "EMAGIAKU GLASS OS 27 PRO + STUDY (amministratore)",
                 "test": "EMAGIAKU GLASS OS 27 PRO + STUDY (chiave di prova)",
                 "prize": "EMAGIAKU GLASS OS 27 PRO + STUDY (premio)",
                 "play": "EMAGIAKU GLASS OS 27 STANDARD + EG PLAY"}


def edition_name():
    return EDITION_NAMES.get(_license_role() or "standard")


def is_admin():
    return _license_role() == "admin"


def set_study_entries(visible):
    """Le app STUDY hanno NoDisplay=true nel sistema: con STUDY attiva le rendiamo visibili
    con una copia utente della voce di menu (senza NoDisplay)."""
    d = os.path.join(HOME, ".local", "share", "applications")
    for app in STUDY_APPS:
        src = "/usr/share/applications/%s.desktop" % app
        dst = os.path.join(d, app + ".desktop")
        try:
            if visible and os.path.exists(src):
                os.makedirs(d, exist_ok=True)
                with open(src, encoding="utf-8") as f:
                    lines = [l for l in f.read().splitlines() if not l.startswith("NoDisplay=")]
                with open(dst, "w", encoding="utf-8") as f:
                    f.write("\n".join(lines) + "\n")
            elif not visible and os.path.exists(dst):
                os.remove(dst)
        except OSError:
            pass
    refresh_menu()


def write_license(key):
    os.makedirs(CONF_DIR, exist_ok=True)
    fd = os.open(LICENSE_FILE, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        f.write(key.strip().upper() + "\n")


def _apply_license(key):
    role = key_role(key)
    if not role:
        return None
    if role in PLUS_LEVEL:            # 27.26: abbonamento EG PLUS, la licenza PRO / PLAY resta com'e'
        _write_plus(key)
        return role
    write_license(key)
    hide_pro_entry()
    set_study_entries(role in ("study",) + FULL_ROLES)
    return role


def activate_key(key):
    """Restituisce il ruolo ('pro'/'study'/'admin'/...) se la chiave e' valida, altrimenti None.
    Se l'Account EMAGIAKU e' collegato la chiave viene salvata anche li' (27.20): sugli altri PC arriva da sola."""
    role = _apply_license(key)
    if role and role not in PLUS_LEVEL:       # la chiave EG PLUS non va al posto della licenza nell'account
        try:
            import egcloud
            egcloud.save_license(key.strip().upper())
        except Exception:
            pass                                  # senza account o senza internet resta solo su questo PC
    return role


def local_license_key():
    try:
        with open(LICENSE_FILE, encoding="utf-8") as f:
            key = f.read().strip()
        return key if key_role(key) else ""
    except OSError:
        return ""


def sync_license_with_account(account_key):
    """Chiamata da egcloud.status() con la chiave salvata nell'account ('' se non c'e').
    Restituisce la chiave che l'account deve avere (None = niente da cambiare)."""
    local = local_license_key()
    account_key = (account_key or "").strip().upper()
    if account_key and key_role(account_key):
        if local != account_key and (not local or _role_rank(key_role(account_key)) >= _role_rank(key_role(local))):
            _apply_license(account_key)           # nuovo PC o reinstallazione: la chiave arriva dall'account
        return None
    if local:
        return local                              # chiave inserita prima del collegamento: la porto nell'account
    return None


def _role_rank(role):
    # EG PLAY vale meno di PRO/STUDY: una chiave PLAY nell'account non sostituisce mai una PRO sul PC
    return {"play": 0.5, "study": 1, "pro": 1, "test": 2, "prize": 2, "admin": 3}.get(role or "", 0)


def sync_entries():
    """All'accesso: voci di menu coerenti con l'edizione attiva."""
    set_study_entries(has_study())
    if _license_role():
        hide_pro_entry()
    else:
        show_pro_entry()


def deactivate():
    """Toglie la chiave da questo PC e anche dall'Account EMAGIAKU (altrimenti tornerebbe da sola)."""
    try:
        os.remove(LICENSE_FILE)
    except OSError:
        pass
    try:
        import egcloud
        egcloud.save_license("")
    except Exception:
        pass
    set_study_entries(False)
    show_pro_entry()


def load_pro():
    conf = dict(PRO_DEFAULTS)
    try:
        with open(PRO_FILE, encoding="utf-8") as f:
            conf.update(json.load(f))
    except (OSError, ValueError):
        pass
    return conf


def save_pro(conf):
    os.makedirs(CONF_DIR, exist_ok=True)
    with open(PRO_FILE, "w", encoding="utf-8") as f:
        json.dump(conf, f, indent=2)


def scan_hardware(conf=None):
    """Legge CPU, RAM e scheda grafica. 'old' = True se il PC e' datato."""
    conf = conf or load_pro()
    cpu = "?"
    try:
        with open("/proc/cpuinfo", encoding="utf-8") as f:
            for line in f:
                if line.startswith("model name"):
                    cpu = line.split(":", 1)[1].strip()
                    break
    except OSError:
        pass
    threads = os.cpu_count() or 1
    ram_gb = 0.0
    try:
        with open("/proc/meminfo", encoding="utf-8") as f:
            for line in f:
                if line.startswith("MemTotal:"):
                    ram_gb = int(line.split()[1]) / 1024 / 1024
                    break
    except OSError:
        pass
    gpus = []
    try:
        out = subprocess.run(["lspci", "-mm"], capture_output=True, text=True, timeout=10).stdout
        for line in out.splitlines():
            if "VGA" in line or "3D controller" in line or "Display controller" in line:
                parts = line.split('"')
                gpus.append((parts[3] + " " + parts[5]).strip() if len(parts) > 5 else line)
    except (OSError, subprocess.SubprocessError):
        pass
    reasons = []
    # 0.5 GB di tolleranza: la RAM "da 8 GB" il kernel la vede come ~7.7 GB
    if ram_gb + 0.5 < float(conf["min_ram_gb"]):
        reasons.append("RAM %.1f GB (meno di %s GB)" % (ram_gb, conf["min_ram_gb"]))
    if threads < int(conf["min_threads"]):
        reasons.append("CPU con %d thread (meno di %s)" % (threads, conf["min_threads"]))
    return {"cpu": cpu, "threads": threads, "ram_gb": round(ram_gb, 1),
            "gpu": gpus or ["?"], "old": bool(reasons), "reasons": reasons}


def game_mode_active(conf=None):
    """La modalita' gioco PRO deve intervenire su questo PC?"""
    conf = conf or load_pro()
    if edition() != "pro" or conf["game_mode"] == "off":
        return False
    if conf["game_mode"] == "on":
        return True
    scan = conf.get("scan") or scan_hardware(conf)
    return bool(scan.get("old"))


PRO_ENTRY_TEMPLATE = "/usr/share/emagiaku/emagiaku-pro.desktop"
PRO_ENTRY_USER = os.path.join(HOME, ".local", "share", "applications", "emagiaku-pro.desktop")


def hide_pro_entry():
    """La voce 'Attiva PRO / STUDY' NON e' nel menu di sistema: esiste solo come voce utente
    finche' non c'e' una chiave. Con la chiave (PRO, STUDY o completa) la cancelliamo."""
    try:
        os.remove(PRO_ENTRY_USER)
    except OSError:
        pass
    refresh_menu()


def show_pro_entry():
    """Dalla 27.7 "Attiva PRO / STUDY" non e' piu' un'app nel menu: e' una voce di EG Impostazioni
    (visibile solo senza chiave). Qui togliamo la vecchia voce di menu se c'e' ancora."""
    if os.path.exists(PRO_ENTRY_USER):
        hide_pro_entry()


def refresh_menu():
    """Ricostruisce subito la cache del menu di KDE (altrimenti la voce resta fino al riavvio)."""
    if shutil.which("kbuildsycoca6"):
        try:
            subprocess.Popen(["kbuildsycoca6"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                             start_new_session=True)
        except OSError:
            pass


# ------------------------------------------------ glass di app e dock
RULE_APPS = "emagiaku-glass-apps"
RULE_DOCK = "emagiaku-glass-dock"
APP_FLOOR = 55    # opacita' minima delle app al massimo glass (resta leggibile)
DOCK_FLOOR = 30   # opacita' minima del dock


def glass_opacity(level, floor):
    """Livello 0..100 -> opacita' % (0 = opaco 100%, 100 = piu' trasparente consentito)."""
    level = max(0, min(100, int(level)))
    return int(round(100 - level * (100 - floor) / 100.0))


def merge_rules(existing, wanted, ours=(RULE_APPS, RULE_DOCK)):
    """Lista di regole KWin: tiene quelle dell'utente, aggiunge/toglie solo le nostre."""
    cur = [r.strip() for r in (existing or "").split(",") if r.strip()]
    cur = [r for r in cur if r not in ours]
    return cur + [r for r in ours if r in wanted]


def kread(file, group, key):
    if shutil.which("kreadconfig6") is None:
        return ""
    try:
        r = subprocess.run(["kreadconfig6", "--file", file, "--group", group, "--key", key],
                           capture_output=True, text=True, timeout=20)
        return r.stdout.strip()
    except (OSError, subprocess.SubprocessError):
        return ""


def remove_old_glass_rules():
    """Fino alla v14 il glass rendeva trasparente TUTTA la finestra (testo compreso) con regole
    KWin: le togliamo. Restano solo le eventuali regole dell'utente."""
    rules = merge_rules(kread("kwinrulesrc", "General", "rules"), [])
    kw("kwinrulesrc", "General", "rules", ",".join(rules))
    kw("kwinrulesrc", "General", "count", len(rules))
    for rid in (RULE_APPS, RULE_DOCK):
        run(["kwriteconfig6", "--file", "kwinrulesrc", "--group", rid, "--key", "opacityactiverule", "--delete"])
        run(["kwriteconfig6", "--file", "kwinrulesrc", "--group", rid, "--key", "opacityinactiverule", "--delete"])


# --- glass del dock: tema Plasma "EMAGIAKU Glass" con lo sfondo dei pannelli regolabile.
# Si cambia SOLO l'opacita' dello sfondo del pannello (opacity:0.85 nel tema Breeze):
# icone e testo del dock restano pieni.
PLASMA_THEMES = "/usr/share/plasma/desktoptheme"
USER_PLASMA_THEMES = os.path.join(HOME, ".local", "share", "plasma", "desktoptheme")


def plasma_theme_name(theme):
    return "emagiaku-glass-" + ("dark" if theme == "dark" else "light")


def dock_opacity(level):
    """0 = sfondo pieno (1.0) ... 100 = molto trasparente (0.15)."""
    level = max(0, min(100, int(level)))
    return round(1.0 - level * 0.0085, 3)


def build_plasma_theme(theme, dock_level):
    """Crea/aggiorna ~/.local/share/plasma/desktoptheme/emagiaku-glass-<dark|light>."""
    import gzip
    import re as _re
    name = plasma_theme_name(theme)
    base = os.path.join(PLASMA_THEMES, "breeze-dark" if theme == "dark" else "breeze-light")
    if not os.path.isdir(base):
        base = os.path.join(PLASMA_THEMES, "default")
    dst = os.path.join(USER_PLASMA_THEMES, name)
    os.makedirs(os.path.join(dst, "translucent", "widgets"), exist_ok=True)
    os.makedirs(os.path.join(dst, "widgets"), exist_ok=True)
    for f in ("colors", "plasmarc"):
        if os.path.exists(os.path.join(base, f)):
            shutil.copyfile(os.path.join(base, f), os.path.join(dst, f))
    meta = {"KPlugin": {"Id": name, "Name": "EMAGIAKU Glass " + ("Scuro" if theme == "dark" else "Chiaro"),
                        "Authors": [{"Name": "EMAGIAKU TEAM"}], "License": "LGPL", "Version": "15"},
            "X-Plasma-API-Minimum-Version": "6.0"}
    try:
        with open(os.path.join(base, "metadata.json"), encoding="utf-8") as f:
            orig = json.load(f)
        for k, v in orig.items():
            if k != "KPlugin":
                meta.setdefault(k, v)
    except (OSError, ValueError):
        pass
    with open(os.path.join(dst, "metadata.json"), "w", encoding="utf-8") as f:
        json.dump(meta, f, indent=1)
    op = dock_opacity(dock_level)
    for sub in ("translucent/widgets", "widgets"):
        src = os.path.join(PLASMA_THEMES, "default", sub, "panel-background.svgz")
        if not os.path.exists(src):
            continue
        with gzip.open(src, "rb") as f:
            svg = f.read().decode("utf-8")
        # 0.85 e' l'opacita' dello sfondo del pannello nel tema Breeze
        svg = _re.sub(r"opacity:0?\.85\b", "opacity:%s" % op, svg)
        with gzip.open(os.path.join(dst, sub, "panel-background.svgz"), "wb") as f:
            f.write(svg.encode("utf-8"))
    # cache di Plasma: senza cancellarla il dock resterebbe com'era
    cache = os.path.join(HOME, ".cache")
    try:
        for f in os.listdir(cache):
            if f.startswith(("plasma_theme_" + name, "plasma-svgelements-" + name, "ksvg-elements")):
                p = os.path.join(cache, f)
                (shutil.rmtree if os.path.isdir(p) else os.remove)(p)
    except OSError:
        pass
    return name


def apply_dock_glass(theme, dock_level):
    name = build_plasma_theme(theme, dock_level)
    kw("plasmarc", "Theme", "name", name)
    if shutil.which("plasma-apply-desktoptheme"):
        # passando da un altro tema Plasma si obbliga a ricaricare le immagini del dock
        run(["plasma-apply-desktoptheme", "breeze-dark" if theme == "dark" else "breeze-light"])
        return run(["plasma-apply-desktoptheme", name])
    return True


# --- glass delle app: Kvantum con sfondo delle finestre trasparente e sfocato.
# Testo, pulsanti, campi e icone restano pieni (non e' piu' l'opacita' della finestra intera).
KV_DIR = os.path.join(HOME, ".config", "Kvantum")
KV_NAME = "EmagiakuGlass"
KV_COLORS = {
    "dark": {"window.color": "#160f24", "base.color": "#1b1230", "alt.base.color": "#21163a",
             "button.color": "#261840", "light.color": "#3a2a60", "mid.light.color": "#2c1f48",
             "dark.color": "#0b0712", "mid.color": "#1d1035", "highlight.color": "#8a4fff",
             "inactive.highlight.color": "#5a3a99", "text.color": "#ebe4fa", "window.text.color": "#ebe4fa",
             "button.text.color": "#ebe4fa", "disabled.text.color": "#7a6c96", "tooltip.text.color": "#ebe4fa",
             "highlight.text.color": "#ffffff", "link.color": "#c9a4ff", "link.visited.color": "#a070ff",
             "progress.indicator.text.color": "#ffffff"},
    "light": {"window.color": "#f4f0fb", "base.color": "#ffffff", "alt.base.color": "#efe9f8",
              "button.color": "#e9e2f5", "light.color": "#ffffff", "mid.light.color": "#ddd3ee",
              "dark.color": "#b9a9d6", "mid.color": "#cfc2e6", "highlight.color": "#8a4fff",
              "inactive.highlight.color": "#b79cf0", "text.color": "#1e1530", "window.text.color": "#1e1530",
              "button.text.color": "#1e1530", "disabled.text.color": "#9a90ad", "tooltip.text.color": "#1e1530",
              "highlight.text.color": "#ffffff", "link.color": "#6a32e0", "link.visited.color": "#4b1fb0",
              "progress.indicator.text.color": "#ffffff"},
}
KV_OPAQUE = ("kaffeine,kmplayer,subtitlecomposer,kdenlive,vlc,smplayer,smplayer2,mpv,haruna,dragon,"
             "obs,obs-studio,digikam,krita,gimp,blender,inkscape,VirtualBox,VirtualBoxVM,QtCreator,steam")


def window_reduce(level):
    """0..100 -> quanto ridurre l'opacita' dello SFONDO delle finestre (Kvantum, 0..70%)."""
    return int(round(max(0, min(100, int(level))) * 0.7))


def _set_ini_keys(text, section, values):
    """Sostituisce/aggiunge chiavi in una sezione di un file .kvconfig mantenendo il resto."""
    lines = text.splitlines()
    out, i, found = [], 0, False
    while i < len(lines):
        line = lines[i]
        out.append(line)
        if line.strip() == "[%s]" % section:
            found = True
            seen = set()
            i += 1
            while i < len(lines) and not lines[i].startswith("["):
                k = lines[i].split("=", 1)[0].strip()
                if k in values:
                    out.append("%s=%s" % (k, values[k]))
                    seen.add(k)
                else:
                    out.append(lines[i])
                i += 1
            for k, v in values.items():
                if k not in seen:
                    out.append("%s=%s" % (k, v))
            continue
        i += 1
    if not found:
        out += ["", "[%s]" % section] + ["%s=%s" % kv for kv in values.items()]
    return "\n".join(out) + "\n"


def build_kvantum_theme(theme, app_level):
    base_name = "KvArcDark" if theme == "dark" else "KvArc"
    base = os.path.join("/usr/share/Kvantum", base_name)
    dst = os.path.join(KV_DIR, KV_NAME)
    if not os.path.isdir(base):
        return False
    os.makedirs(dst, exist_ok=True)
    shutil.copyfile(os.path.join(base, base_name + ".svg"), os.path.join(dst, KV_NAME + ".svg"))
    with open(os.path.join(base, base_name + ".kvconfig"), encoding="utf-8", errors="replace") as f:
        text = f.read()
    red = window_reduce(app_level)
    text = _set_ini_keys(text, "%General", {
        "composite": "true", "translucent_windows": "true" if red > 0 else "false",
        "blurring": "true" if red > 0 else "false", "popup_blurring": "true" if red > 0 else "false",
        "reduce_window_opacity": str(red), "reduce_menu_opacity": str(min(40, red // 2)),
        "opaque": KV_OPAQUE, "comment": "EMAGIAKU Glass (generato da Glass Engine)"})
    text = _set_ini_keys(text, "GeneralColors", KV_COLORS["dark" if theme == "dark" else "light"])
    with open(os.path.join(dst, KV_NAME + ".kvconfig"), "w", encoding="utf-8") as f:
        f.write(text)
    with open(os.path.join(KV_DIR, "kvantum.kvconfig"), "w", encoding="utf-8") as f:
        f.write("[General]\ntheme=%s\n" % KV_NAME)
    return True


def apply_app_glass(theme, app_level):
    if int(app_level) <= 0 or not build_kvantum_theme(theme, app_level):
        kw("kdeglobals", "KDE", "widgetStyle", "Breeze")
        return int(app_level) <= 0   # glass 0 = stile normale; altrimenti Kvantum mancante
    kw("kdeglobals", "KDE", "widgetStyle", "kvantum")
    # avvisa le app aperte che lo stile e' cambiato
    dbus_call("org.kde.KGlobalSettings", "/KGlobalSettings", "org.kde.KGlobalSettings.notifyChange", "int32:2", "int32:0")
    return True


def apply_glass(app_level, dock_level, theme=None):
    """Glass come deve essere: sfondi trasparenti e sfocati, contenuti sempre leggibili."""
    theme = theme or load_conf().get("theme", "dark")
    remove_old_glass_rules()
    ok_dock = apply_dock_glass(theme, dock_level)
    ok_app = apply_app_glass(theme, app_level)
    kw("kwinrc", "Plugins", "blurEnabled", "true")
    kwin_reconfigure()
    return bool(ok_dock and ok_app)


def glass_stylesheet(style):
    """Per le app EMAGIAKU: rende trasparente solo lo sfondo della finestra principale
    (lo sfoca Kvantum); campi, liste e pulsanti restano pieni."""
    level = int(load_conf().get("app_glass", 0))
    if level <= 0 or load_conf().get("light_mode"):
        return style
    alpha = max(90, 255 - int(level * 1.6))
    out = style.replace("QWidget { background: #120c1c;", "QWidget { background: transparent;", 1)
    return out + "\nQWidget#glassroot { background: rgba(18, 12, 28, %d); }\n" % alpha


# ----------------------------------------------------- modalita' leggera
def apply_performance(on, conf):
    """PC poco potenti: niente animazioni, niente blur, niente trasparenze."""
    if on:
        apply_motion("off")
        apply_glass(0, 0, conf.get("theme", "dark"))
        kw("kwinrc", "Plugins", "blurEnabled", "false")
    else:
        apply_motion(conf.get("motion", "standard"))
        apply_glass(conf.get("app_glass", 0), conf.get("dock_glass", 0), conf.get("theme", "dark"))
    kwin_reconfigure()


# ------------------------------------------------------ mouse e cursori
SAFE_NAME = __import__("re").compile(r"^[A-Za-z0-9._ -]{1,64}$")


def list_cursor_themes():
    import glob
    names = set()
    for base in ("/usr/share/icons", os.path.join(HOME, ".local/share/icons"), os.path.join(HOME, ".icons")):
        for d in glob.glob(os.path.join(base, "*", "cursors")):
            names.add(os.path.basename(os.path.dirname(d)))
    return sorted(names)


def apply_cursor(theme, size):
    if not theme or not SAFE_NAME.match(theme):
        return False
    size = max(16, min(128, int(size)))
    ok = run(["plasma-apply-cursortheme", theme])
    kw("kcminputrc", "Mouse", "cursorTheme", theme)
    kw("kcminputrc", "Mouse", "cursorSize", size)
    try:   # anche per le app non-KDE (X11)
        d = os.path.join(HOME, ".icons", "default")
        os.makedirs(d, exist_ok=True)
        with open(os.path.join(d, "index.theme"), "w", encoding="utf-8") as f:
            f.write("[Icon Theme]\nName=Default\nInherits=%s\n" % theme)
    except OSError:
        pass
    return ok


def _is_wayland():
    return os.environ.get("XDG_SESSION_TYPE") == "wayland" or bool(os.environ.get("WAYLAND_DISPLAY"))


def _apply_input_wayland(speed, natural, left):
    """Plasma Wayland (KDE 6.8+): ogni mouse/touchpad e' un oggetto D-Bus di KWin con le sue proprieta'."""
    code, out = _sh_out(["gdbus", "call", "--session", "--dest", "org.kde.KWin", "--object-path",
                         "/org/kde/KWin/InputDevice", "--method", "org.freedesktop.DBus.Properties.Get",
                         "org.kde.KWin.InputDeviceManager", "devicesSysNames"])
    if code != 0:
        return False
    acc = "%.2f" % (max(-10, min(10, int(speed))) / 10.0)
    for dev in re.findall(r"'(event\d+)'", out):
        path = "/org/kde/KWin/InputDevice/" + dev
        c2, o2 = _sh_out(["gdbus", "call", "--session", "--dest", "org.kde.KWin", "--object-path", path,
                          "--method", "org.freedesktop.DBus.Properties.Get", "org.kde.KWin.InputDevice", "pointer"])
        if c2 != 0 or "true" not in o2:
            continue                                  # tastiere e altri dispositivi: niente da fare
        for prop, val in (("pointerAcceleration", "<%s>" % acc), ("naturalScroll", "<%s>" % str(bool(natural)).lower()),
                          ("leftHanded", "<%s>" % str(bool(left)).lower())):
            run(["gdbus", "call", "--session", "--dest", "org.kde.KWin", "--object-path", path, "--method",
                 "org.freedesktop.DBus.Properties.Set", "org.kde.KWin.InputDevice", prop, val])
    return True


def apply_input(speed, natural, left):
    """Velocita' puntatore (-10..10), scorrimento naturale, mouse per mancini (X11 con xinput, Wayland con KWin)."""
    if _is_wayland():
        return _apply_input_wayland(speed, natural, left)
    code, out = _sh_out(["xinput", "list", "--id-only"])
    if code != 0:
        return False
    sp = "%.2f" % (max(-10, min(10, int(speed))) / 10.0)
    for dev in out.split():
        if not dev.isdigit():
            continue
        run(["xinput", "set-prop", dev, "libinput Accel Speed", sp])
        run(["xinput", "set-prop", dev, "libinput Natural Scrolling Enabled", "1" if natural else "0"])
        run(["xinput", "set-prop", dev, "libinput Left Handed Enabled", "1" if left else "0"])
    return True


def _sh_out(cmd):
    if shutil.which(cmd[0]) is None:
        return 127, ""
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=20)
        return r.returncode, r.stdout
    except (OSError, subprocess.SubprocessError):
        return 127, ""


# ------------------------------------------------ colore, notte, sfondi
ACCENTS = {   # nome -> RGB
    "Viola": (138, 79, 255), "Rosa": (236, 72, 153), "Blu": (59, 130, 246),
    "Verde": (34, 197, 94), "Arancio": (249, 115, 22), "Rosso": (239, 68, 68),
}


def apply_accent(name):
    """Nome di ACCENTS oppure colore libero '#rrggbb'."""
    rgb = ACCENTS.get(name)
    if rgb is None and isinstance(name, str) and __import__("re").match(r"^#[0-9a-fA-F]{6}$", name):
        rgb = tuple(int(name[i:i + 2], 16) for i in (1, 3, 5))
    if rgb is None:
        return False
    kw("kdeglobals", "General", "AccentColor", "%d,%d,%d" % rgb)
    return run(["plasma-apply-colorscheme", "--accent-color", "#%02x%02x%02x" % rgb])


def apply_night(on, temp):
    temp = max(1000, min(6500, int(temp)))
    kw("kwinrc", "NightColor", "Active", "true" if on else "false")
    kw("kwinrc", "NightColor", "Mode", "Constant")
    kw("kwinrc", "NightColor", "NightTemperature", temp)
    kwin_reconfigure()


def list_wallpapers():
    """[(nome, cartella)] degli sfondi EMAGIAKU installati, 'Benvenuto' per primo."""
    import glob
    res = []
    for d in glob.glob(os.path.join(WALL_DIR, "Emagiaku*")):
        name = os.path.basename(d)
        try:
            with open(os.path.join(d, "metadata.json"), encoding="utf-8") as f:
                name = json.load(f)["KPlugin"]["Name"]
        except (OSError, ValueError, KeyError):
            pass
        res.append((0 if d.endswith("EmagiakuWelcome") else 1, name, d))
    return [(n, d) for _, n, d in sorted(res)]


# ------------------------------------------------------------- icone
def list_icon_themes():
    """Temi di icone installati (esclusi quelli che contengono solo cursori)."""
    import glob
    res = set()
    for base in ("/usr/share/icons", os.path.join(HOME, ".local/share/icons")):
        for idx in glob.glob(os.path.join(base, "*", "index.theme")):
            d = os.path.dirname(idx)
            name = os.path.basename(d)
            if name in ("default", "hicolor", "locolor"):
                continue
            try:
                with open(idx, encoding="utf-8", errors="replace") as f:
                    txt = f.read()
            except OSError:
                continue
            if "Directories=" in txt and not txt.split("Directories=", 1)[1].split("\n", 1)[0].strip() == "":
                res.add(name)
    return sorted(res)


def apply_icons(theme):
    if not theme or not SAFE_NAME.match(theme):
        return False
    ok = False
    for tool in ("/usr/lib/plasma-changeicons", "/usr/libexec/plasma-changeicons"):
        if os.path.exists(tool):
            ok = run([tool, theme])
            break
    kw("kdeglobals", "Icons", "Theme", theme)
    return ok or True


# -------------------------------------------------------------- font
def apply_font(family, size):
    """Font di sistema (testi, menu, barre, titoli finestre)."""
    size = max(7, min(24, int(size)))
    family = family or "Noto Sans"
    if not SAFE_NAME.match(family):
        return False
    spec = "%s,%d,-1,5,400,0,0,0,0,0,0,0,0,0,0,1" % (family, size)
    small = "%s,%d,-1,5,400,0,0,0,0,0,0,0,0,0,0,1" % (family, max(7, size - 2))
    for key in ("font", "menuFont", "toolBarFont"):
        kw("kdeglobals", "General", key, spec)
    kw("kdeglobals", "General", "smallestReadableFont", small)
    kw("kdeglobals", "WM", "activeFont", spec)
    # avvisa le app KDE aperte che i font sono cambiati
    dbus_call("org.kde.KGlobalSettings", "/KGlobalSettings", "org.kde.KGlobalSettings.notifyChange", "int32:1", "int32:0")
    kwin_reconfigure()
    return True


# --------------------------------------------------- widget sul desktop
WIDGETS = {   # chiave -> (plugin Plasma, nome IT)
    "clock": ("org.kde.plasma.analogclock", "Orologio analogico"),
    "dclock": ("org.kde.plasma.digitalclock", "Orologio digitale"),
    "calendar": ("org.kde.plasma.calendar", "Calendario"),
    "notes": ("org.kde.plasma.notes", "Note adesive"),
    "cpu": ("org.kde.plasma.systemmonitor.cpu", "Uso del processore"),
    "ram": ("org.kde.plasma.systemmonitor.memory", "Uso della RAM"),
    "weather": ("org.kde.plasma.weather", "Meteo"),
    "folder": ("org.kde.plasma.folder", "Cartella sul desktop"),
}


def apply_widgets(keys):
    """Mette sul desktop i widget scelti (e toglie quelli EMAGIAKU non piu' scelti)."""
    plugins = [WIDGETS[k][0] for k in WIDGETS]
    chosen = [WIDGETS[k][0] for k in keys if k in WIDGETS]
    js = ("var all=%s;var want=%s;var ds=desktops();"
          "for(var i=0;i<ds.length;i++){var d=ds[i];var ws=d.widgets();"
          "for(var j=0;j<ws.length;j++){if(all.indexOf(ws[j].type)>=0){ws[j].remove();}}"
          "if(i==0){var x=40;for(var k=0;k<want.length;k++){d.addWidget(want[k],x,60,320,300);x+=340;}}}"
          % (json.dumps(plugins), json.dumps(chosen)))
    return plasma_script(js)


# --------------------------------------------- sfondo che cambia da solo
def apply_slideshow(on, minutes, folder=WALL_DIR):
    if not on:
        return True
    secs = max(1, int(minutes)) * 60
    js = ("var ds=desktops();for(var i=0;i<ds.length;i++){var d=ds[i];"
          "d.wallpaperPlugin='org.kde.slideshow';"
          "d.currentConfigGroup=['Wallpaper','org.kde.slideshow','General'];"
          "d.writeConfig('SlidePaths',%s);d.writeConfig('SlideInterval',%d);}"
          % (json.dumps([folder]), secs))
    return plasma_script(js)


# ------------------------------------------------------ effetti finestre
def apply_effects(wobbly, minimize_anim):
    kw("kwinrc", "Plugins", "wobblywindowsEnabled", "true" if wobbly else "false")
    kw("kwinrc", "Plugins", "magiclampEnabled", "true" if minimize_anim == "magiclamp" else "false")
    kw("kwinrc", "Plugins", "squashEnabled", "true" if minimize_anim == "squash" else "false")
    kwin_reconfigure()
    return True


# ------------------------------------------------- look salvati (preset)
LOOKS_DIR = os.path.join(CONF_DIR, "looks")
LOOK_KEYS = [k for k in DEFAULTS if k not in ("language", "origin")]


def list_looks():
    try:
        return sorted(f[:-5] for f in os.listdir(LOOKS_DIR) if f.endswith(".json"))
    except OSError:
        return []


def _look_file(name):
    safe = "".join(ch for ch in name if ch.isalnum() or ch in " -_").strip()[:40]
    return os.path.join(LOOKS_DIR, safe + ".json") if safe else None


def save_look(name, conf):
    p = _look_file(name)
    if not p:
        return False
    os.makedirs(LOOKS_DIR, exist_ok=True)
    with open(p, "w", encoding="utf-8") as f:
        json.dump({k: conf.get(k, DEFAULTS[k]) for k in LOOK_KEYS}, f, indent=2)
    return True


def load_look(name):
    p = _look_file(name)
    try:
        with open(p, encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, ValueError, TypeError):
        return None
    conf = load_conf()
    conf.update({k: v for k, v in data.items() if k in LOOK_KEYS})
    return conf


def delete_look(name):
    p = _look_file(name)
    try:
        os.remove(p)
        return True
    except (OSError, TypeError):
        return False


# ------------------------------------------------------ primo accesso
def first_login():
    conf = load_conf()
    apply_theme(conf["theme"])
    apply_wallpaper(wallpaper_path("welcome"))
    apply_buttons(conf["window_buttons"])
    apply_blur(conf["blur"])
    apply_layout(conf["layout"], conf["dock_position"], conf["dock_size"] or None, topbar_opts(conf))
    apply_glass(conf["app_glass"], conf["dock_glass"])
    apply_effects(conf["wobbly"], conf["minimize_anim"])


def session():
    """Eseguito a ogni login: impostazioni che X11 non ricorda da sole."""
    conf = load_conf()
    apply_input(conf["pointer_speed"], conf["natural_scroll"], conf["left_handed"])
    if conf["cursor_theme"]:
        apply_cursor(conf["cursor_theme"], conf["cursor_size"])
    sync_entries()   # app STUDY visibili solo con l'edizione STUDY
    # chiave PRO/STUDY dall'Account EMAGIAKU (27.20): in sottofondo, cosi' l'accesso non aspetta internet
    import threading

    def _sync():
        try:
            import egcloud
            if egcloud.load().get("session"):
                egcloud.status()
        except Exception:
            pass
    threading.Thread(target=_sync, daemon=True).start()
    set_windows_handler()
    hide_third_party()
    redirect_kde_settings()
    set_default_viewers()
    migrate_dock()
    apply_round_style()


# ------------------------------------------ sistema "tutto EMAGIAKU" (27.6)
# App di terze parti che restano nel sistema perche' servono a KDE, ma che l'utente non deve
# vedere nel menu: al loro posto ci sono EG Impostazioni ed EG Store.
HIDE_ENTRIES = ["systemsettings", "kdesystemsettings", "org.kde.discover", "kvantummanager",
                "org.kde.kmenuedit", "org.kde.plasma.emojier", "nm-connection-editor", "assistant",
                "designer", "linguist", "qdbusviewer", "lstopo", "qv4l2", "qvidcap", "stoken-gui",
                "stoken-gui-small", "vim", "lftp", "org.kde.kinfocenter", "org.kde.plasma-systemmonitor",
                "org.kde.ksystemstats", "avahi-discover", "bssh", "bvnc", "xgps", "xgpsspeed"]
USER_APPS = os.path.join(HOME, ".local", "share", "applications")
HIDE_MARK = "X-Emagiaku-Hidden=true"


# Impostazioni di KDE -> EG Impostazioni. Chi apre "systemsettings" o un modulo con "kcmshell6"
# (preferiti del menu, pulsanti "Configura..." dell'area di notifica, ecc.) arriva alla pagina EG giusta.
KCM_TO_EG = [   # pezzo del nome del modulo KDE -> pagina di EG Impostazioni
    ("networkmanagement", "rete"), ("network", "rete"), ("bluetooth", "bluetooth"), ("pulseaudio", "audio"),
    ("audio", "audio"), ("kscreen", "schermo"), ("display", "schermo"), ("nightcolor", "schermo"),
    ("nightlight", "schermo"), ("users", "utenti"), ("user", "utenti"), ("wallpaper", "sfondo"),
    ("lookandfeel", "aspetto"), ("colors", "aspetto"), ("desktoptheme", "aspetto"), ("icons", "aspetto"),
    ("fonts", "aspetto"), ("cursortheme", "aspetto"), ("style", "aspetto"), ("kwindecoration", "aspetto"),
    ("splashscreen", "aspetto"), ("screenlocker", "sfondo"), ("componentchooser", "app"), ("filetypes", "app"),
    ("clock", "avanzate"), ("keyboard", "avanzate"), ("powerdevil", "avanzate"), ("energy", "avanzate"),
    ("autostart", "avanzate"), ("regionandlang", "avanzate"), ("mouse", "aspetto"), ("touchpad", "aspetto"),
    ("updates", "aggiornamenti"), ("about-distro", "sistema"), ("kinfocenter", "sistema"),
]
WRAPPER = """#!/bin/sh
# EMAGIAKU: le impostazioni di KDE si aprono in EG Impostazioni (pagina giusta per il modulo richiesto)
exec /usr/bin/python3 -c 'import sys; sys.path.insert(0, "/usr/lib/emagiaku"); import common; common.open_kcm(sys.argv[1:])' "$@"
"""
ENV_SCRIPT = os.path.join(HOME, ".config", "plasma-workspace", "env", "emagiaku-path.sh")


def eg_page_for(args):
    text = " ".join(args).lower()
    for key, page in KCM_TO_EG:
        if key in text:
            return page
    return "sistema"


def open_kcm(args):
    """Chiamato al posto di systemsettings / kcmshell6."""
    page = eg_page_for([a for a in args if not a.startswith("-")])
    os.execv("/usr/bin/emagiaku-settings", ["emagiaku-settings", page])


def redirect_kde_settings():
    """Voci e comandi delle impostazioni di KDE -> EG Impostazioni (solo per questo utente)."""
    if not os.path.exists("/usr/bin/emagiaku-settings"):
        return
    # 1) le voci systemsettings (anche nei preferiti del menu) aprono EG Impostazioni
    for name in ("systemsettings", "kdesystemsettings"):
        dst = os.path.join(USER_APPS, name + ".desktop")
        try:
            os.makedirs(USER_APPS, exist_ok=True)
            with open(dst, "w", encoding="utf-8") as f:
                f.write("[Desktop Entry]\nType=Application\nName=EG Impostazioni\nIcon=emagiaku-settings\n"
                        "Exec=/usr/bin/emagiaku-settings\nNoDisplay=true\n%s\n" % HIDE_MARK)
        except OSError:
            pass
    # 2) i comandi systemsettings / kcmshell6 (usati dai pulsanti "Configura...") passano da EG
    bindir = os.path.join(HOME, ".local", "bin")
    try:
        os.makedirs(bindir, exist_ok=True)
        for cmd in ("systemsettings", "kcmshell6"):
            p = os.path.join(bindir, cmd)
            with open(p, "w", encoding="utf-8") as f:
                f.write(WRAPPER)
            os.chmod(p, 0o755)
        # 3) quella cartella va per prima nel PATH della sessione grafica (vale dal prossimo accesso)
        os.makedirs(os.path.dirname(ENV_SCRIPT), exist_ok=True)
        with open(ENV_SCRIPT, "w", encoding="utf-8") as f:
            f.write("# EMAGIAKU: comandi delle impostazioni -> EG Impostazioni\n"
                    "case \":$PATH:\" in *\":$HOME/.local/bin:\"*) ;; *) export PATH=\"$HOME/.local/bin:$PATH\" ;; esac\n")
    except OSError:
        pass


def hide_third_party():
    """Copia utente con NoDisplay=true: la voce sparisce dal menu ma il programma resta."""
    for name in HIDE_ENTRIES:
        src = "/usr/share/applications/%s.desktop" % name
        dst = os.path.join(USER_APPS, name + ".desktop")
        if name in ("systemsettings", "kdesystemsettings"):
            continue                      # queste le gestisce redirect_kde_settings()
        try:
            if os.path.exists(dst):
                with open(dst, encoding="utf-8", errors="replace") as f:
                    if HIDE_MARK not in f.read():
                        continue          # voce personalizzata dall'utente: non la tocco
            if not os.path.exists(src):
                if os.path.exists(dst):
                    os.remove(dst)
                continue
            with open(src, encoding="utf-8", errors="replace") as f:
                lines = [l for l in f.read().splitlines() if not l.startswith(("NoDisplay=", "Hidden="))]
            out, done = [], False
            for l in lines:
                out.append(l)
                if not done and l.strip() == "[Desktop Entry]":
                    out += ["NoDisplay=true", HIDE_MARK]
                    done = True
            os.makedirs(USER_APPS, exist_ok=True)
            with open(dst, "w", encoding="utf-8") as f:
                f.write("\n".join(out) + "\n")
        except OSError:
            pass


VIEW_MIMES = ["application/pdf", "image/png", "image/jpeg", "image/gif", "image/webp", "image/svg+xml",
              "image/bmp", "text/plain"]


def _entry_exists(name):
    return any(os.path.exists(os.path.join(d, name)) for d in
               ("/usr/share/applications", USER_APPS, "/var/lib/flatpak/exports/share/applications",
                os.path.join(HOME, ".local/share/flatpak/exports/share/applications")))


def set_default_viewers():
    """Senza Okular/Gwenview/Kate: PDF, foto e testi si aprono con Firefox (finche' l'utente non
    installa un'altra app dall'EG Store e la sceglie)."""
    if not shutil.which("xdg-mime"):
        return
    # cartelle -> EG Files, terminale -> EG Console (se l'utente non ha scelto altro che c'e' ancora)
    own = [("inode/directory", "emagiaku-files.desktop")]
    for mt, entry in own:
        if not os.path.exists("/usr/share/applications/" + entry):
            continue
        try:
            cur = subprocess.run(["xdg-mime", "query", "default", mt], capture_output=True, text=True,
                                 timeout=15).stdout.strip()
            if not cur or not _entry_exists(cur):
                subprocess.run(["xdg-mime", "default", entry, mt], capture_output=True, timeout=15)
        except (OSError, subprocess.SubprocessError):
            pass
    if os.path.exists("/usr/bin/emagiaku-console"):
        term = kread("kdeglobals", "General", "TerminalApplication")
        if not term or not shutil.which(term.split()[0]):
            kw("kdeglobals", "General", "TerminalApplication", "emagiaku-console")
            kw("kdeglobals", "General", "TerminalService", "emagiaku-console.desktop")
    if not os.path.exists("/usr/share/applications/firefox.desktop"):
        return
    for mt in VIEW_MIMES:
        try:
            cur = subprocess.run(["xdg-mime", "query", "default", mt], capture_output=True, text=True,
                                 timeout=15).stdout.strip()
            if not cur or not _entry_exists(cur):
                subprocess.run(["xdg-mime", "default", "firefox.desktop", mt], capture_output=True, timeout=15)
        except (OSError, subprocess.SubprocessError):
            pass


DOCK_FLAG = os.path.join(CONF_DIR, "dock-27.6")
DOCK_MIGRATE_JS = (
    "var ps=panels();for(var i=0;i<ps.length;i++){var ws=ps[i].widgets();"
    "for(var j=0;j<ws.length;j++){var w=ws[j];"
    "if(w.type=='org.kde.plasma.icontasks'||w.type=='org.kde.plasma.taskmanager'){"
    "w.currentConfigGroup=['General'];var l=w.readConfig('launchers','');"
    "var a=(typeof l=='string')?l.split(','):l;var o=[];"
    "for(var k=0;k<a.length;k++){var x=String(a[k]);"
    "if(x.indexOf('org.kde.dolphin')>=0){x='applications:emagiaku-settings.desktop';}"
    "if(x.indexOf('org.kde.konsole')>=0||x.indexOf('org.kde.discover')>=0||x.indexOf('systemsettings')>=0){continue;}"
    "if(x&&o.indexOf(x)<0){o.push(x);}}"
    "w.writeConfig('launchers',o.join(','));}}}")


DOCK_FLAG2 = os.path.join(CONF_DIR, "dock-27.8")
DOCK_ADD_FILES_JS = (
    "var ps=panels();for(var i=0;i<ps.length;i++){var ws=ps[i].widgets();"
    "for(var j=0;j<ws.length;j++){var w=ws[j];"
    "if(w.type=='org.kde.plasma.icontasks'||w.type=='org.kde.plasma.taskmanager'){"
    "w.currentConfigGroup=['General'];var l=w.readConfig('launchers','');"
    "var a=(typeof l=='string')?l.split(','):l;var o=[];var f='applications:emagiaku-files.desktop';"
    "for(var k=0;k<a.length;k++){var x=String(a[k]);if(x&&o.indexOf(x)<0){o.push(x);}}"
    "if(o.indexOf(f)<0){var p=o.indexOf('applications:emagiaku-settings.desktop');"
    "if(p<0){o.push(f);}else{o.splice(p+1,0,f);}}"
    "w.writeConfig('launchers',o.join(','));}}}")


def _plasma_once(flag, js):
    import time
    for _ in range(30):             # aspetta che il desktop (plasmashell) sia pronto
        if run(["dbus-send", "--session", "--print-reply", "--dest=org.kde.plasmashell", "/PlasmaShell",
                "org.kde.PlasmaShell.evaluateScript", "string:" + js]):
            try:
                os.makedirs(CONF_DIR, exist_ok=True)
                open(flag, "w").close()
            except OSError:
                pass
            return True
        time.sleep(3)
    return False


STYLE_FLAG_2720 = os.path.join(CONF_DIR, "style-27.20")


def apply_round_style():
    """Stile 27.20 (piu' rotondo, tipo macOS): finestre senza bordo con tutti e quattro gli angoli arrotondati.
    Una volta sola per chi aggiorna; poi l'utente puo' cambiare a piacere."""
    if os.path.exists(STYLE_FLAG_2720):
        return
    kw("kwinrc", "org.kde.kdecoration2", "BorderSize", "None")
    kw("kwinrc", "org.kde.kdecoration2", "BorderSizeAuto", "false")
    kw("breezerc", "Windeco", "RoundedCorners", "true")
    kwin_reconfigure()
    try:
        os.makedirs(CONF_DIR, exist_ok=True)
        open(STYLE_FLAG_2720, "w").close()
    except OSError:
        pass


def migrate_dock():
    """Una volta sola: nel dock Dolphin diventa EG Impostazioni, Konsole/Discover spariscono;
    dalla 27.8 si aggiunge EG Files."""
    if shutil.which("dbus-send") is None:
        return
    if not os.path.exists(DOCK_FLAG):
        _plasma_once(DOCK_FLAG, DOCK_MIGRATE_JS)
    if not os.path.exists(DOCK_FLAG2) and os.path.exists("/usr/share/applications/emagiaku-files.desktop"):
        _plasma_once(DOCK_FLAG2, DOCK_ADD_FILES_JS)


WIN_MIMES = ["application/x-ms-dos-executable", "application/x-msdownload", "application/x-msi",
             "application/vnd.microsoft.portable-executable", "application/x-dosexec"]


def set_windows_handler():
    """Doppio clic su un .exe/.msi -> EG Windows App (solo se l'utente non ha gia' scelto un'altra app)."""
    if not shutil.which("xdg-mime") or not os.path.exists("/usr/share/applications/emagiaku-winapp.desktop"):
        return
    for mt in WIN_MIMES:
        try:
            cur = subprocess.run(["xdg-mime", "query", "default", mt], capture_output=True, text=True,
                                 timeout=15).stdout.strip()
            if not cur:
                subprocess.run(["xdg-mime", "default", "emagiaku-winapp.desktop", mt], capture_output=True, timeout=15)
        except (OSError, subprocess.SubprocessError):
            pass


if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else ""
    if cmd == "first-login":
        first_login()
    elif cmd == "session":
        session()
    elif cmd == "scan":
        print(json.dumps(scan_hardware(), indent=2))
    else:
        print("uso: common.py first-login | session | scan")

# ------------------------------------------------------- 27.28: vedere la password mentre la scrivi
def pw_toggle(edit):
    """Mette un occhio dentro un campo password (QLineEdit): un clic la mostra, un altro la nasconde."""
    from PyQt6.QtCore import Qt
    from PyQt6.QtGui import QColor, QFont, QIcon, QPainter, QPixmap
    from PyQt6.QtWidgets import QLineEdit
    if edit is None:
        return edit

    def icona(nome, testo):
        ic = QIcon.fromTheme(nome)
        if not ic.isNull():
            return ic
        pm = QPixmap(32, 32)              # senza tema di icone: disegno l'occhio con un carattere
        pm.fill(Qt.GlobalColor.transparent)
        p = QPainter(pm)
        p.setPen(QColor("#c9a4ff"))
        f = QFont()
        f.setPixelSize(22)
        p.setFont(f)
        p.drawText(pm.rect(), Qt.AlignmentFlag.AlignCenter, testo)
        p.end()
        return QIcon(pm)
    mostra, nascondi = icona("view-visible", "👁"), icona("view-hidden", "◌")
    act = edit.addAction(mostra, QLineEdit.ActionPosition.TrailingPosition)
    act.setToolTip("Mostra la password")

    def cambia():
        nascosta = edit.echoMode() == QLineEdit.EchoMode.Password
        edit.setEchoMode(QLineEdit.EchoMode.Normal if nascosta else QLineEdit.EchoMode.Password)
        act.setIcon(nascondi if nascosta else mostra)
        act.setToolTip("Nascondi la password" if nascosta else "Mostra la password")
    act.triggered.connect(cambia)
    return edit
