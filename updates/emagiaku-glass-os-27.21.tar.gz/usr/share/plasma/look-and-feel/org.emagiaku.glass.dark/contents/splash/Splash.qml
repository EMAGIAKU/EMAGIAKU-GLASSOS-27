// EMAGIAKU GLASS OS 27 - schermata di avvio (KSplash) mostrata mentre si apre il desktop.
// 27.20: stile macOS - nero pieno, logo e scritte bianche, barra sottile.
import QtQuick

Rectangle {
    id: root
    color: "#000000"
    // KSplash aggiorna "stage" da 1 a 6 mentre il desktop si carica
    property int stage
    readonly property real unit: Math.min(width, height) / 100

    Column {
        anchors.centerIn: parent
        anchors.verticalCenterOffset: -root.unit * 2
        spacing: root.unit * 2.4
        opacity: 0
        Component.onCompleted: opacity = 1
        Behavior on opacity { NumberAnimation { duration: 900; easing.type: Easing.InOutQuad } }

        // logo: solo "EG" bianco, come la mela del Mac (niente riquadro)
        Text {
            anchors.horizontalCenter: parent.horizontalCenter
            text: "EG"
            color: "#ffffff"
            font.pixelSize: Math.max(64, root.unit * 15)
            font.weight: Font.DemiBold
            font.letterSpacing: -root.unit * 0.4
        }
        Text {
            anchors.horizontalCenter: parent.horizontalCenter
            text: "EMAGIAKU GLASS OS 27"
            color: "#ffffff"
            opacity: 0.92
            font.pixelSize: Math.max(15, root.unit * 2.6)
            font.weight: Font.Light
            font.letterSpacing: root.unit * 0.35
        }
        Item { width: 1; height: root.unit * 3 }
        // barra di avanzamento sottile, come all'accensione di un Mac
        Rectangle {
            width: Math.max(180, root.unit * 24); height: Math.max(5, root.unit * 0.7)
            radius: height / 2
            anchors.horizontalCenter: parent.horizontalCenter
            color: "#3a3a3c"
            Rectangle {
                height: parent.height; radius: parent.radius
                width: parent.width * Math.min(1, Math.max(0.04, root.stage / 6))
                color: "#ffffff"
                Behavior on width { NumberAnimation { duration: 500; easing.type: Easing.OutCubic } }
            }
        }
    }

    Text {
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.bottom: parent.bottom
        anchors.bottomMargin: Math.max(24, root.height / 22)
        text: "Developed by EMAGIAKU.TEAM  ·  Based on Arch Linux"
        color: "#ffffff"
        opacity: 0.45
        font.pixelSize: Math.max(12, root.unit * 1.5)
        font.weight: Font.Light
        font.letterSpacing: 0.5
    }
}
