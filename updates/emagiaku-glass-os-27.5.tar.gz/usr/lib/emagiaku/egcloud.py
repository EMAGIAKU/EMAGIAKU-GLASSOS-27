"""Account EMAGIAKU - registrazione, verifica email e accesso con Firebase Authentication (Google).

Le mail (verifica, password dimenticata) le manda Google. Nel sistema c'e' solo la chiave PUBBLICA
del progetto Firebase (fatta per stare nelle app). Sul PC NON si salva la password: solo il
"gettone di accesso" (refresh token) in ~/.config/emagiaku/account.json (leggibile solo dall'utente).
"""
import json
import os
import urllib.error
import urllib.parse
import urllib.request

API_KEY = "AIzaSyDo3hAOeFUmKnbgSBi6zX6mtkxmULNB-AA"      # pubblica (progetto emagiaku-glass-os)
ID_URL = "https://identitytoolkit.googleapis.com/v1/accounts:%s?key=" + API_KEY
TOKEN_URL = "https://securetoken.googleapis.com/v1/token?key=" + API_KEY
PRIVACY_URL = "https://github.com/EMAGIAKU/EMAGIAKU-GLASSOS-27/blob/main/PRIVACY.md"
STORE = os.path.join(os.path.expanduser("~"), ".config", "emagiaku", "account.json")

ERRORS = {   # codici di Firebase -> messaggi in italiano
    "EMAIL_EXISTS": "Esiste gia' un account con questa email: accedi.",
    "INVALID_EMAIL": "L'indirizzo email non e' valido.",
    "WEAK_PASSWORD": "Password troppo debole: usa almeno 8 caratteri.",
    "MISSING_PASSWORD": "Scrivi la password.",
    "INVALID_LOGIN_CREDENTIALS": "Email o password sbagliate.",
    "INVALID_PASSWORD": "Email o password sbagliate.",
    "EMAIL_NOT_FOUND": "Email o password sbagliate.",
    "USER_DISABLED": "Questo account e' stato disattivato.",
    "TOO_MANY_ATTEMPTS_TRY_LATER": "Troppi tentativi: riprova tra qualche minuto.",
    "TOKEN_EXPIRED": "Accesso scaduto: accedi di nuovo.",
    "INVALID_REFRESH_TOKEN": "Accesso scaduto: accedi di nuovo.",
    "USER_NOT_FOUND": "Account non trovato: accedi di nuovo.",
    "CREDENTIAL_TOO_OLD_LOGIN_AGAIN": "Per sicurezza accedi di nuovo e riprova.",
    "OPERATION_NOT_ALLOWED": "Registrazione con email non attiva nel servizio.",
    "INVALID_OOB_CODE": "Codice o link non valido (o gia' usato): usa l'ultima mail ricevuta.",
    "EXPIRED_OOB_CODE": "Il link e' scaduto: chiedi una nuova mail.",
}


def extract_code(text):
    """Dal link della mail (o dal codice da solo) ricava il codice 'oobCode'."""
    text = (text or "").strip()
    if "oobCode=" in text:
        q = urllib.parse.urlparse(text).query or text.split("?", 1)[-1]
        vals = urllib.parse.parse_qs(q).get("oobCode")
        if vals:
            return vals[0]
    return text if text and " " not in text and "/" not in text else ""


class CloudError(Exception):
    pass


def _post(url, data, form=False, timeout=30):
    if form:
        body = urllib.parse.urlencode(data).encode()
        headers = {"Content-Type": "application/x-www-form-urlencoded"}
    else:
        body = json.dumps(data).encode()
        headers = {"Content-Type": "application/json"}
    headers["X-Firebase-Locale"] = "it"          # mail di Google in italiano
    req = urllib.request.Request(url, data=body, headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode() or "{}")
    except urllib.error.HTTPError as e:
        try:
            msg = json.loads(e.read().decode()).get("error", {}).get("message", "")
        except (ValueError, OSError):
            msg = ""
        code = msg.split(" ")[0].split(":")[0]
        if code.startswith("WEAK_PASSWORD"):
            code = "WEAK_PASSWORD"
        raise CloudError(ERRORS.get(code, "Errore del servizio account (%s)." % (msg or e.code)))
    except (urllib.error.URLError, OSError):
        raise CloudError("Nessuna connessione: per l'account EMAGIAKU serve internet.")


# --------------------------------------------------------------- stato
def load():
    try:
        with open(STORE, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def save(data):
    os.makedirs(os.path.dirname(STORE), exist_ok=True)
    fd = os.open(STORE, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=1)


def forget():
    try:
        os.remove(STORE)
    except OSError:
        pass


def _remember(r, email):
    data = {"email": r.get("email", email), "uid": r.get("localId", ""), "refreshToken": r.get("refreshToken", "")}
    save(data)
    return data


# ------------------------------------------------------------- azioni
def sign_up(email, password):
    """Crea l'account e manda la mail di verifica."""
    if len(password or "") < 8:
        raise CloudError(ERRORS["WEAK_PASSWORD"])
    r = _post(ID_URL % "signUp", {"email": email.strip(), "password": password, "returnSecureToken": True})
    _remember(r, email)
    send_verification(r["idToken"])
    return r


def send_verification(id_token=None):
    id_token = id_token or id_token_now()
    _post(ID_URL % "sendOobCode", {"requestType": "VERIFY_EMAIL", "idToken": id_token})


def sign_in(email, password):
    r = _post(ID_URL % "signInWithPassword", {"email": email.strip(), "password": password, "returnSecureToken": True})
    _remember(r, email)
    return r


def id_token_now():
    """Nuovo gettone (valido 1 ora) dal gettone salvato."""
    st = load()
    if not st.get("refreshToken"):
        raise CloudError("Non hai ancora fatto l'accesso.")
    r = _post(TOKEN_URL, {"grant_type": "refresh_token", "refresh_token": st["refreshToken"]}, form=True)
    if r.get("refresh_token") and r["refresh_token"] != st["refreshToken"]:
        st["refreshToken"] = r["refresh_token"]
        save(st)
    return r["id_token"]


def status():
    """{'email', 'verified'} dell'account collegato, o None se non c'e'."""
    st = load()
    if not st.get("refreshToken"):
        return None
    r = _post(ID_URL % "lookup", {"idToken": id_token_now()})
    users = r.get("users") or []
    if not users:
        raise CloudError(ERRORS["USER_NOT_FOUND"])
    u = users[0]
    st["verified"] = bool(u.get("emailVerified"))
    st["email"] = u.get("email", st.get("email", ""))
    save(st)
    return {"email": st["email"], "verified": st["verified"]}


def reset_password(email):
    _post(ID_URL % "sendOobCode", {"requestType": "PASSWORD_RESET", "email": email.strip()})


def confirm_email(link_or_code):
    """Verifica l'account con il link/codice della mail (se il link nel browser non si apre)."""
    code = extract_code(link_or_code)
    if not code:
        raise CloudError("Incolla il link (o il codice) che trovi nella mail.")
    r = _post(ID_URL % "update", {"oobCode": code})
    if not r.get("emailVerified"):
        raise CloudError(ERRORS["INVALID_OOB_CODE"])
    st = load()
    if st:
        st["verified"] = True
        save(st)
    return r


def confirm_password_reset(link_or_code, new_password):
    """Imposta la nuova password usando il link/codice della mail di ripristino."""
    code = extract_code(link_or_code)
    if not code:
        raise CloudError("Incolla il link (o il codice) che trovi nella mail.")
    if len(new_password or "") < 8:
        raise CloudError(ERRORS["WEAK_PASSWORD"])
    return _post(ID_URL % "resetPassword", {"oobCode": code, "newPassword": new_password})


def delete_account():
    """Elimina DEFINITIVAMENTE l'account da Firebase (diritto alla cancellazione) e lo scollega dal PC."""
    _post(ID_URL % "delete", {"idToken": id_token_now()})
    forget()
