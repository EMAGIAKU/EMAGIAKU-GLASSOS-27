"""EG PLAY OS (27.24) - parte "console" del servizio EG PLAY: EG Store, Media, Libreria importata dagli account
collegati, impostazioni da console (rete, audio, account, chiave, aggiornamenti) e tasto EG del controller.

Niente finestre da PC: tutto passa dall'interfaccia EG PLAY (col controller). Gli acquisti si fanno SEMPRE nel
negozio collegato (Steam, Epic...): EG PLAY mostra il catalogo e apre la pagina del gioco nel programma del negozio.
"""
import glob
import json
import os
import re
import select
import shutil
import struct
import subprocess
import threading
import time
import urllib.parse
import urllib.request

HOME = os.path.expanduser("~")
CACHE = os.path.join(HOME, ".cache", "emagiaku", "play")
UA = {"User-Agent": "EGPLAY/27.25 (EMAGIAKU)"}


def _get_json(url, timeout=10, tries=2, data=None):
    """GET (o POST con `data`) JSON con un secondo tentativo: all'accensione la rete arriva qualche secondo dopo."""
    last = None
    for n in range(tries):
        try:
            body = json.dumps(data).encode() if data is not None else None
            hdr = dict(UA, **({"Content-Type": "application/json"} if body else {}))
            req = urllib.request.Request(url, data=body, headers=hdr)
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return json.loads(r.read().decode("utf-8", "replace"))
        except Exception as e:           # rete, DNS, timeout, risposta rotta
            last = e
            if n + 1 < tries:
                time.sleep(1.5)
    raise last


def online(timeout=2):
    """True se internet risponde (DNS + connessione a un server dei negozi)."""
    import socket
    for host in ("store.steampowered.com", "flathub.org"):
        try:
            socket.create_connection((host, 443), timeout=timeout).close()
            return True
        except OSError:
            continue
    return False


def _cached(name, ttl, fn, ok=lambda d: bool(d)):
    """Risultato salvato per `ttl` secondi (cosi' il negozio si apre subito e non si chiede troppo ai server).
    27.25: un risultato vuoto o rotto NON viene salvato (prima bastava un avvio senza rete per avere il negozio
    vuoto per ore); senza internet si usa l'ultima copia buona, anche vecchia."""
    os.makedirs(CACHE, exist_ok=True)
    path = os.path.join(CACHE, name + ".json")
    old = None
    try:
        with open(path, encoding="utf-8") as f:
            old = json.load(f)
        if ok(old) and time.time() - os.path.getmtime(path) < ttl:
            return old
    except (OSError, ValueError):
        old = None
    try:
        data = fn()
        if ok(data):
            tmp = path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(data, f)
            os.replace(tmp, path)
            return data
    except Exception:
        pass
    return old if old is not None and ok(old) else None


def _spawn(cmd):
    return subprocess.Popen(cmd, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                            start_new_session=True)


# =============================================================================================== EG STORE
def _euro(cents):
    return ("%.2f €" % (cents / 100)).replace(".", ",") if cents else "Gratis"


def _steam_store():
    d = _get_json("https://store.steampowered.com/api/featuredcategories?cc=IT&l=italian")
    out = {}
    for key, title in (("top_sellers", "I più venduti su Steam"), ("specials", "In offerta su Steam"),
                       ("new_releases", "Novità su Steam")):
        items = []
        for it in (d.get(key) or {}).get("items", [])[:18]:
            if not isinstance(it.get("id"), int) or it.get("type", 0) not in (0, None):
                continue
            if re.match(r"^Steam (Deck|Frame|Controller|Machine)", it.get("name", "")):
                continue                          # hardware di Valve, non giochi
            items.append({"id": "steam:%d" % it["id"], "nome": it.get("name", ""), "negozio": "Steam",
                          "prezzo": _euro(it.get("final_price") or 0),
                          "prima": _euro(it["original_price"]) if it.get("discount_percent") else "",
                          "sconto": it.get("discount_percent") or 0,
                          "immagine": it.get("large_capsule_image") or it.get("header_image") or ""})
        out[key] = {"titolo": title, "giochi": items}
    return out


def _epic_free():
    d = _get_json("https://store-site-backend-static.ak.epicgames.com/freeGamesPromotions?locale=it&country=IT&allowCountries=IT")
    items = []
    for e in d["data"]["Catalog"]["searchStore"]["elements"]:
        promo = e.get("promotions") or {}
        if not (promo.get("promotionalOffers") or []):
            continue                              # solo quelli gratis adesso
        slug = ((e.get("catalogNs") or {}).get("mappings") or [{}])[0].get("pageSlug") or e.get("productSlug") or ""
        img = next((k["url"] for k in e.get("keyImages", []) if k.get("type") in ("OfferImageWide", "DieselStoreFrontWide")), "")
        items.append({"id": "epic:" + re.sub(r"[^a-z0-9-]", "", slug.split("/")[0].lower()), "nome": e.get("title", ""),
                      "negozio": "Epic Games", "prezzo": "Gratis questa settimana", "prima": "", "sconto": 100,
                      "immagine": img})
    return {"titolo": "Gratis su Epic Games", "giochi": items}


def _gog_items(params, limit=18):
    """27.25: catalogo nuovo di GOG (catalog.gog.com). Il vecchio embed.gog.com non cerca piu' niente."""
    q = {"limit": str(limit), "productType": "in:game,pack", "countryCode": "IT", "currencyCode": "EUR"}
    q.update(params)
    d = _get_json("https://catalog.gog.com/v1/catalog?" + urllib.parse.urlencode(q, safe=":,"))
    items = []
    for p in d.get("products", [])[:limit]:
        slug = str(p.get("slug") or "")
        if not re.fullmatch(r"[a-z0-9_]{1,120}", slug):
            continue
        pr = p.get("price") or {}
        sc = int(re.sub(r"[^0-9]", "", str(pr.get("discount") or "")) or 0)
        fin = str(pr.get("final") or "")
        prezzo = "Gratis" if fin.startswith("0,00") else (fin or "Vedi su GOG")
        items.append({"id": "gog:/it/game/" + slug, "nome": (p.get("title") or "").strip(), "negozio": "GOG",
                      "prezzo": prezzo, "prima": str(pr.get("base") or "") if sc else "", "sconto": sc,
                      "immagine": p.get("coverHorizontal") or ""})
    return items


def _gog_store(order="desc:trending", titolo="Popolari su GOG", soloSconti=False):
    params = {"order": order}
    if soloSconti:
        params["discounted"] = "eq:true"
    return {"titolo": titolo, "giochi": _gog_items(params)}


def _flathub_games():
    d = _get_json("https://flathub.org/api/v2/collection/category/game?page=1&per_page=24")
    items = []
    for h in d.get("hits", []):
        app = h.get("app_id") or h.get("id") or ""
        if not re.fullmatch(r"[A-Za-z0-9._-]{3,120}", app):
            continue
        items.append({"id": "flathub:" + app, "nome": h.get("name", app), "negozio": "EG Store (Flathub)",
                      "prezzo": "Gratis", "prima": "", "sconto": 0, "immagine": h.get("icon") or "",
                      "descrizione": h.get("summary", "")})
    return {"titolo": "Gratis da installare subito", "giochi": items}


def store(demo=False):
    if demo:
        demo_items = [{"id": "demo:s%d" % i, "nome": n, "negozio": "Steam", "prezzo": p, "prima": "", "sconto": 0,
                       "immagine": ""} for i, (n, p) in enumerate((("Gioco Demo 1", "29,99 €"), ("Gioco Demo 2", "9,99 €"),
                                                                   ("Gioco Demo 3", "Gratis")))]
        return {"sezioni": [{"titolo": "In evidenza (demo)", "giochi": demo_items}]}
    # 27.25: i negozi si chiedono TUTTI INSIEME (prima uno dopo l'altro: fino a 75 secondi senza rete) e ognuno ha
    # la sua copia di riserva. Si dice all'interfaccia se manca la rete o qualche negozio, cosi' riprova da sola.
    has = lambda d: bool(d and d.get("giochi"))
    jobs = {
        "steam": lambda: _cached("store-steam", 3 * 3600, _steam_store,
                                 lambda d: bool(d) and any((d.get(k) or {}).get("giochi") for k in d)),
        "epic": lambda: _cached("store-epic", 3 * 3600, _epic_free, has),
        "gog_s": lambda: _cached("store-gog-sconti", 3 * 3600, lambda: _gog_store("desc:trending", "In offerta su GOG", True), has),
        "gog": lambda: _cached("store-gog", 6 * 3600, lambda: _gog_store("desc:trending", "Popolari su GOG"), has),
        "flathub": lambda: _cached("store-flathub", 12 * 3600, _flathub_games, has),
    }
    res = _parallel(jobs, 25)
    steam = res.get("steam") or {}
    sezioni = [steam[k] for k in ("top_sellers", "specials", "new_releases") if (steam.get(k) or {}).get("giochi")]
    if has(res.get("epic")):
        sezioni.insert(1 if sezioni else 0, res["epic"])
    for k in ("gog_s", "gog", "flathub"):
        if has(res.get(k)):
            sezioni.append(res[k])
    presenti = {"Steam": any((steam.get(k) or {}).get("giochi") for k in steam), "Epic Games": has(res.get("epic")),
                "GOG": has(res.get("gog")) or has(res.get("gog_s")), "Flathub": has(res.get("flathub"))}
    mancanti = [n for n, ok in presenti.items() if not ok]
    return {"sezioni": sezioni, "mancanti": mancanti, "rete": online() if mancanti else True}


def _parallel(jobs, timeout):
    """Esegue le funzioni insieme; quelle che non finiscono entro `timeout` secondi restano None."""
    out, threads = {}, []
    for k, fn in jobs.items():
        def run(k=k, fn=fn):
            try:
                out[k] = fn()
            except Exception:
                out[k] = None
        t = threading.Thread(target=run, daemon=True)
        t.start()
        threads.append(t)
    end = time.time() + timeout
    for t in threads:
        t.join(max(0.0, end - time.time()))
    return dict(out)


def prewarm_store():
    """All'accensione: aspetta la rete (anche se ti colleghi al Wi-Fi dopo) e prepara il negozio in anticipo."""
    def run():
        for _ in range(120):                       # fino a 10 minuti
            if online():
                try:
                    store(False)
                except Exception:
                    pass
                return
            time.sleep(5)
    threading.Thread(target=run, daemon=True).start()


# ----------------------------------------------------------------------------- RICERCA su tutti i negozi (27.25)
# Negozi senza una ricerca pubblica per i programmi: si apre la loro pagina di ricerca nel browser (col controller).
WEB_SEARCH = {
    "epic": ("Epic Games", "https://store.epicgames.com/it/browse?sortBy=relevancy&sortDir=DESC&q="),
    "ubisoft": ("Ubisoft Store", "https://store.ubisoft.com/it/search?q="),
    "ea": ("EA app", "https://www.ea.com/it/games"),
    "battlenet": ("Battle.net", "https://shop.battle.net/it-it"),
}
# Battle.net ha pochi giochi e nessuna ricerca pubblica: elenco dei suoi giochi (veri) per cercarli per nome
BATTLENET = ["Diablo IV", "Diablo III", "Diablo II: Resurrected", "Diablo Immortal", "Overwatch 2", "World of Warcraft",
             "Hearthstone", "StarCraft II", "StarCraft Remastered", "Warcraft III: Reforged", "Warcraft Rumble",
             "Heroes of the Storm", "Call of Duty: Black Ops 6", "Call of Duty: Modern Warfare III", "Call of Duty: Warzone",
             "Crash Bandicoot 4: It's About Time", "Tony Hawk's Pro Skater 1 + 2"]


def _steam_search(q):
    d = _get_json("https://store.steampowered.com/api/storesearch/?" +
                  urllib.parse.urlencode({"term": q, "l": "italian", "cc": "IT"}))
    items = []
    for it in d.get("items", [])[:18]:
        if it.get("type") != "app" or not isinstance(it.get("id"), int):
            continue
        pr = it.get("price") or {}
        fin, ini = pr.get("final") or 0, pr.get("initial") or 0
        items.append({"id": "steam:%d" % it["id"], "nome": it.get("name", ""), "negozio": "Steam",
                      "prezzo": _euro(fin), "prima": _euro(ini) if ini > fin else "",
                      "sconto": int(round(100 - fin * 100 / ini)) if ini > fin else 0,
                      "immagine": "https://shared.akamai.steamstatic.com/store_item_assets/steam/apps/%d/header.jpg" % it["id"],
                      "immagine2": it.get("tiny_image") or ""})      # riserva: i giochi nuovi hanno l'immagine altrove
    return items


def _flathub_search(q):
    d = _get_json("https://flathub.org/api/v2/search", data={"query": q, "filters": []})
    items = []
    for h in d.get("hits", []):
        cats = h.get("main_categories") or []
        cats = [cats] if isinstance(cats, str) else cats
        app = h.get("app_id") or ""
        if "game" not in [str(x).lower() for x in cats] or not re.fullmatch(r"[A-Za-z0-9._-]{3,120}", app):
            continue
        items.append({"id": "flathub:" + app, "nome": h.get("name", app), "negozio": "EG Store (Flathub)",
                      "prezzo": "Gratis", "prima": "", "sconto": 0, "immagine": h.get("icon") or "",
                      "descrizione": h.get("summary", "")})
    return items[:18]


def search(q):
    q = re.sub(r"\s+", " ", str(q or "")).strip()[:60]
    if len(q) < 2:
        return {"ok": False, "errore": "Scrivi almeno 2 lettere"}
    res = _parallel({"steam": lambda: _steam_search(q),
                     "gog": lambda: _gog_items({"query": "like:" + q, "order": "desc:score"}),
                     "flathub": lambda: _flathub_search(q)}, 15)
    sezioni = []
    for k, titolo in (("steam", "Steam"), ("gog", "GOG"), ("flathub", "Gratis (Flathub)")):
        if res.get(k):
            sezioni.append({"titolo": titolo, "giochi": res[k]})
    low = q.lower()
    bn = [{"id": "web:battlenet:" + n, "nome": n, "negozio": "Battle.net", "prezzo": "Vedi su Battle.net",
           "prima": "", "sconto": 0, "immagine": ""} for n in BATTLENET if low in n.lower()]
    if bn:
        sezioni.append({"titolo": "Battle.net", "giochi": bn})
    altri = [{"id": "web:%s:%s" % (k, q), "nome": "Cerca “%s” su %s" % (q, v[0]), "negozio": v[0],
              "prezzo": "Apri il negozio", "prima": "", "sconto": 0, "immagine": ""}
             for k, v in WEB_SEARCH.items() if k != "battlenet"]
    sezioni.append({"titolo": "Negli altri negozi", "giochi": altri})
    vuoti = [n for k, n in (("steam", "Steam"), ("gog", "GOG"), ("flathub", "Flathub")) if res.get(k) is None]
    return {"ok": True, "q": q, "sezioni": sezioni, "non_raggiunti": vuoti}


def store_action(gid, installing):
    """Compra / installa: il pagamento avviene SOLO nel negozio collegato."""
    kind, _, ref = gid.partition(":")
    if kind == "steam" and ref.isdigit():
        # 27.26: la pagina del negozio Steam nel browser a tutto schermo (niente finestra di Steam da cui non si esce)
        open_web_store("https://store.steampowered.com/app/%s/?l=italian" % ref)
        return {"ok": True, "messaggio": "Si apre Steam nel browser: compra con il tuo account, poi in Libreria premi "
                                         "Installa (si scarica senza aprire Steam). Torni con il tasto EG"}
    if kind == "epic" and re.fullmatch(r"[a-z0-9-]{1,80}", ref):
        open_web_store("https://store.epicgames.com/it/p/" + ref)
        return {"ok": True, "messaggio": "Si apre Epic Games: riscattalo con il tuo account (collegato in "
                                         "Impostazioni › Account di gioco), poi lo trovi in Libreria"}
    if kind == "gog":
        # la pagina del gioco su GOG, nel browser a tutto schermo (torni con il tasto EG del controller)
        path = ref if re.fullmatch(r"/[a-z]{2}/game/[a-z0-9_]{1,120}", ref or "") else ""
        open_web_store("https://www.gog.com" + path if path else "https://www.gog.com/it/games")
        return {"ok": True, "messaggio": "Si apre GOG: compra il gioco con il tuo account, poi lo trovi in Libreria"}
    if kind == "web":
        neg, _, q = ref.partition(":")
        if neg not in WEB_SEARCH or len(q) > 60:
            return {"ok": False, "errore": "Negozio non valido"}
        nome, base = WEB_SEARCH[neg]
        open_web_store(base + urllib.parse.quote(q) if base.endswith("=") else base)
        return {"ok": True, "messaggio": "Si apre %s: col controller muovi il cursore (levetta sinistra) e premi A. "
                                         "Torni con il tasto EG" % nome}
    if kind == "flathub" and re.fullmatch(r"[A-Za-z0-9._-]{3,120}", ref):
        if _flatpak_has(ref):
            return {"ok": True, "messaggio": "Già installato: lo trovi nella Libreria"}
        if ref in installing:
            return {"ok": True, "messaggio": "Sto già installando..."}
        installing.add(ref)

        def run():
            _flathub_remote()
            subprocess.run(["flatpak", "install", "-y", "--user", "--noninteractive", "flathub", ref], capture_output=True)
            installing.discard(ref)
        threading.Thread(target=run, daemon=True).start()
        return {"ok": True, "messaggio": "Installazione avviata (gratis): tra poco è nella Libreria"}
    return {"ok": False, "errore": "Gioco non valido"}


# =============================================================================================== LIBRERIA importata
def _flatpak_has(app):
    if not app or not shutil.which("flatpak"):
        return False
    return subprocess.run(["flatpak", "info", app], capture_output=True).returncode == 0


def _flathub_remote():
    subprocess.run(["flatpak", "remote-add", "--user", "--if-not-exists", "flathub",
                    "https://dl.flathub.org/repo/flathub.flatpakrepo"], capture_output=True)


HEROIC_DIRS = [os.path.join(HOME, ".var/app/com.heroicgameslauncher.hgl/config/heroic"),
               os.path.join(HOME, ".config/heroic")]


def heroic_library():
    """Giochi Epic / GOG / Amazon dell'account entrato in Heroic (anche non installati)."""
    out = []
    for base in HEROIC_DIRS:
        for name, store_name in (("legendary_library.json", "Epic Games"), ("gog_library.json", "GOG"),
                                 ("nile_library.json", "Amazon")):
            path = os.path.join(base, "store_cache", name)
            try:
                with open(path, encoding="utf-8") as f:
                    data = json.load(f)
            except (OSError, ValueError):
                continue
            games = data.get("library") or data.get("games") or (data if isinstance(data, list) else [])
            for g in games:
                if not isinstance(g, dict):
                    continue
                app = str(g.get("app_name") or g.get("appName") or "")
                title = g.get("title") or app
                if not app or not title:
                    continue
                out.append({"id": "heroic:%s:%s" % (store_name.split()[0].lower(), app), "nome": title,
                            "fonte": store_name, "installato": bool(g.get("is_installed")),
                            "immagine": g.get("art_cover") or g.get("art_square") or ""})
        if out:
            break
    return out


def _vdf_block(text, name):
    """Contenuto tra le graffe del primo blocco "name" { ... } (formato VDF di Steam)."""
    m = re.search(r'"%s"\s*\{' % re.escape(name), text, re.I)
    if not m:
        return ""
    i, depth = m.end(), 1
    while i < len(text) and depth:
        if text[i] == '"':
            j = text.find('"', i + 1)
            i = j + 1 if j > 0 else len(text)
            continue
        depth += 1 if text[i] == "{" else -1 if text[i] == "}" else 0
        i += 1
    return text[m.end():i - 1]


STEAM_ROOTS = [os.path.join(HOME, ".local/share/Steam"), os.path.join(HOME, ".steam/steam"),
               os.path.join(HOME, ".var/app/com.valvesoftware.Steam/.local/share/Steam")]


def _vdf_top_ids(block):
    """Chiavi numeriche di primo livello di un blocco VDF (gli ID dei giochi)."""
    ids, depth, key = set(), 0, None
    for tok in re.findall(r'"[^"]*"|\{|\}', block):
        if tok == "{":
            if depth == 0 and key and key.strip('"').isdigit():
                ids.add(key.strip('"'))
            depth += 1
        elif tok == "}":
            depth -= 1
        key = tok
    return ids


def steam_owned_ids():
    """ID dei giochi Steam dell'account entrato in Steam su questo PC, presi da 3 posti:
    - localconfig.vdf: giochi avviati almeno una volta;
    - sharedconfig.vdf: giochi della libreria messi in collezioni / nascosti / preferiti;
    - appcache/librarycache: Steam salva qui le copertine di TUTTA la libreria quando la apri."""
    ids = set()
    for r in STEAM_ROOTS:
        for cfg in glob.glob(os.path.join(r, "userdata", "*", "config", "localconfig.vdf")) + \
                glob.glob(os.path.join(r, "userdata", "*", "7", "remote", "sharedconfig.vdf")):
            try:
                text = open(cfg, encoding="utf-8", errors="replace").read()
            except OSError:
                continue
            ids |= _vdf_top_ids(_vdf_block(text, "apps"))
        cache = os.path.join(r, "appcache", "librarycache")
        try:
            for n in os.listdir(cache):
                m = re.match(r"^(\d+)(?:_|$)", n)
                if m:
                    ids.add(m.group(1))
        except OSError:
            pass
    ids.discard("0")
    ids.discard("7")             # il client di Steam
    return ids


def steam_logged_in():
    return any(glob.glob(os.path.join(r, "userdata", "*", "config", "localconfig.vdf")) for r in STEAM_ROOTS)


def steam_controls(categories):
    """27.30: come si gioca, dalle categorie ufficiali del negozio Steam:
    "c" = supporto controller completo o parziale (categorie 28 e 18),
    "t" = giocabile su telefono/tablet con i comandi touch di Steam (Remote Play su telefono 41 o tablet 42)."""
    ids = {c.get("id") for c in categories or [] if isinstance(c, dict)}
    return ("c" if ids & {28, 18} else "") + ("t" if ids & {41, 42} else "")


def steam_controls_cached():
    """{appid: "ct"} dalla memoria dei nomi Steam (per i giochi installati)."""
    try:
        names = json.load(open(os.path.join(CACHE, "steam-names.json"), encoding="utf-8"))
        return {i: v.get("comandi", "") for i, v in names.items() if isinstance(v, dict)}
    except (OSError, ValueError):
        return {}


def steam_owned(max_new=25):
    """Giochi Steam posseduti (anche non installati). I nomi arrivano dal negozio Steam e restano in memoria:
    ogni volta se ne chiedono al massimo `max_new` nuovi (Steam limita le richieste)."""
    ids = steam_owned_ids()
    if not ids:
        return []
    names_path = os.path.join(CACHE, "steam-names.json")
    try:
        names = json.load(open(names_path, encoding="utf-8"))
    except (OSError, ValueError):
        names = {}
    # 27.30: anche i nomi gia' in memoria senza "comandi" vengono richiesti di nuovo (poco per volta)
    missing = (sorted(i for i in ids if i not in names) + sorted(i for i in ids if i in names and "comandi" not in names[i]))
    missing = missing[:max_new]

    def info(i):
        d = _get_json("https://store.steampowered.com/api/appdetails?appids=%s&l=italian&filters=basic,categories"
                      % i, 8, 1)
        x = d.get(i) or {}
        if not x.get("success", True) and "data" not in x:
            return {"nome": "", "tipo": "sconosciuto", "immagine": "", "comandi": ""}   # tolto dal negozio
        data = x.get("data") or {}
        return {"nome": data.get("name", ""), "tipo": data.get("type", ""), "immagine": data.get("header_image", ""),
                "comandi": steam_controls(data.get("categories"))}
    for start in range(0, len(missing), 6):                       # 6 per volta
        chunk = missing[start:start + 6]
        got = _parallel({i: (lambda i=i: info(i)) for i in chunk}, 20)
        for i, v in got.items():
            if v:
                names[i] = v
        if not any(got.get(i) for i in chunk):
            break                                                 # niente rete o Steam ci ha fermati
    os.makedirs(CACHE, exist_ok=True)
    try:
        json.dump(names, open(names_path, "w", encoding="utf-8"))
    except OSError:
        pass
    return [{"id": "steam:" + i, "nome": names[i]["nome"], "fonte": "Steam", "installato": False,
             "immagine": names[i].get("immagine", ""), "comandi": names[i].get("comandi", "")}
            for i in sorted(ids) if i in names and names[i].get("nome") and names[i].get("tipo") in ("game", "")]


# ----------------------------------------------------------------------------- SINCRONIZZA libreria (27.25)
SYNC_FILE = os.path.join(HOME, ".config", "emagiaku", "play-libreria.json")
SYNC = {"stato": "", "lock": threading.Lock()}


def synced_library():
    try:
        with open(SYNC_FILE, encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d.get("giochi"), list) else {"quando": 0, "giochi": []}
    except (OSError, ValueError):
        return {"quando": 0, "giochi": []}


def sync_library(installed_ids=()):
    """Importa TUTTI i giochi posseduti negli account entrati su questa console (Steam, e con Heroic Epic, GOG,
    Amazon) e li salva: compaiono in Libreria e anche in Home. Le password restano nei programmi dei negozi."""
    if not SYNC["lock"].acquire(blocking=False):
        return {"ok": False, "errore": "Sincronizzazione già in corso"}
    try:
        SYNC["stato"] = "in corso"
        steam = steam_owned(max_new=150)
        # 27.26: Epic, GOG, Amazon, Ubisoft, EA, Battle.net dagli account collegati (Lutris), poi Heroic se c'e'
        heroic = [g for g in lutris_library() if not g["installato"]]
        visti_h = {(g["fonte"], g["nome"].lower()) for g in heroic}
        heroic += [g for g in heroic_library() if (g["fonte"], g["nome"].lower()) not in visti_h]
        giochi, visti = [], set(installed_ids)
        for g in heroic + steam:
            if g["id"] in visti:
                continue
            visti.add(g["id"])
            giochi.append(g)
        giochi.sort(key=lambda g: g["nome"].lower())
        conteggio = {}
        for g in heroic + steam:
            conteggio[g["fonte"]] = conteggio.get(g["fonte"], 0) + 1
        avvisi = []
        if not steam_logged_in():
            avvisi.append("Steam: apri Steam ed entra con il tuo account, poi sincronizza di nuovo")
        elif len(steam) < len(steam_owned_ids()) // 2:
            avvisi.append("Steam: alcuni nomi arrivano alla prossima sincronizzazione (Steam limita le richieste)")
        if not heroic:
            avvisi.append("Epic, GOG, Ubisoft, EA, Battle.net: collegali in Impostazioni › Account di gioco, poi sincronizza")
        os.makedirs(os.path.dirname(SYNC_FILE), exist_ok=True)
        with open(SYNC_FILE + ".tmp", "w", encoding="utf-8") as f:
            json.dump({"quando": int(time.time()), "giochi": giochi[:1000]}, f)
        os.replace(SYNC_FILE + ".tmp", SYNC_FILE)
        SYNC["stato"] = "fatto"
        return {"ok": True, "totale": len(giochi), "per_negozio": conteggio, "avvisi": avvisi,
                "messaggio": "Sincronizzati %d giochi dai tuoi account" % len(giochi)}
    finally:
        SYNC["lock"].release()


def library_action(gid):
    kind, _, rest = gid.partition(":")
    if kind == "steam" and rest.isdigit():
        return steam_install(rest)                  # 27.26: scarica senza aprire la finestra di Steam
    if kind == "lutris":
        return lutris_install(rest)
    if kind == "heroic":
        store_id, _, app = rest.partition(":")
        runner = {"epic": "legendary", "gog": "gog", "amazon": "nile"}.get(store_id)
        if not runner or not re.fullmatch(r"[A-Za-z0-9._-]{1,120}", app):
            return {"ok": False, "errore": "Gioco non valido"}
        url = "heroic://launch?appName=%s&runner=%s" % (app, runner)
        cmd = ["flatpak", "run", "com.heroicgameslauncher.hgl", url] if _flatpak_has("com.heroicgameslauncher.hgl") \
            else (["heroic", url] if shutil.which("heroic") else None)
        if not cmd:
            return {"ok": False, "errore": "Heroic non è installato: Impostazioni › Account di gioco"}
        _spawn(cmd)
        return {"ok": True, "messaggio": "Heroic apre il gioco (se non è installato, ti chiede di installarlo)"}
    return {"ok": False, "errore": "Gioco non valido"}


# =============================================================================================== MEDIA
# Musica, film e video: app web a tutto schermo (si esce col tasto EG del controller) o app per la TV.
MEDIA = [
    {"id": "youtube", "nome": "YouTube", "tipo": "Video", "url": "https://www.youtube.com/", "colore": "#ff3d3d"},
    {"id": "netflix", "nome": "Netflix", "tipo": "Film e serie", "url": "https://www.netflix.com/", "colore": "#e50914"},
    {"id": "prime", "nome": "Prime Video", "tipo": "Film e serie", "url": "https://www.primevideo.com/", "colore": "#1aa3ff"},
    {"id": "disney", "nome": "Disney+", "tipo": "Film e serie", "url": "https://www.disneyplus.com/", "colore": "#1c3fa8"},
    {"id": "raiplay", "nome": "RaiPlay", "tipo": "TV", "url": "https://www.raiplay.it/", "colore": "#0057b8"},
    {"id": "twitch", "nome": "Twitch", "tipo": "Dirette", "url": "https://www.twitch.tv/", "colore": "#9146ff"},
    {"id": "spotify", "nome": "Spotify", "tipo": "Musica", "url": "https://open.spotify.com/", "colore": "#1ed760"},
    {"id": "kodi", "nome": "Kodi", "tipo": "I tuoi film e la tua musica", "flatpak": "tv.kodi.Kodi", "colore": "#17b2e7"},
]
MEDIA_PROC = {"p": None}
FG_PROCS = []          # 27.26: finestre "da PC" aperte da EG PLAY (accesso ai negozi, installatori): mouse col controller


def media_list():
    out = []
    for m in MEDIA:
        x = {k: m[k] for k in ("id", "nome", "tipo", "colore")}
        x["pronto"] = True if "url" in m else _flatpak_has(m.get("flatpak"))
        out.append(x)
    return out


def media_open(mid, installing):
    m = next((x for x in MEDIA if x["id"] == mid), None)
    if not m:
        return {"ok": False, "errore": "App non trovata"}
    media_close()
    if "url" in m:
        ff = shutil.which("firefox")
        if not ff:
            return {"ok": False, "errore": "Firefox non è installato"}
        prof = os.path.join(HOME, ".local/share/emagiaku/play-media")
        os.makedirs(prof, exist_ok=True)
        with open(os.path.join(prof, "user.js"), "w") as f:
            f.write('user_pref("browser.shell.checkDefaultBrowser", false);\n'
                    'user_pref("media.eme.enabled", true);\n'          # Netflix, Prime, Disney+ (Widevine)
                    'user_pref("media.gmp-widevinecdm.enabled", true);\n'
                    'user_pref("browser.aboutwelcome.enabled", false);\n'
                    'user_pref("full-screen-api.warning.timeout", 0);\n')
        MEDIA_PROC["p"] = _spawn([ff, "--kiosk", "--new-instance", "--profile", prof, m["url"]])
        return {"ok": True, "messaggio": m["nome"] + ": per tornare a EG PLAY premi il tasto EG / PS / Xbox / Home del controller"}
    app = m["flatpak"]
    if _flatpak_has(app):
        MEDIA_PROC["p"] = _spawn(["flatpak", "run", app])
        return {"ok": True, "messaggio": "Apro " + m["nome"]}
    if app in installing:
        return {"ok": True, "messaggio": "Sto già installando " + m["nome"] + "..."}
    installing.add(app)

    def run():
        _flathub_remote()
        r = subprocess.run(["flatpak", "install", "-y", "--user", "--noninteractive", "flathub", app], capture_output=True)
        installing.discard(app)
        if r.returncode == 0:
            MEDIA_PROC["p"] = _spawn(["flatpak", "run", app])
    threading.Thread(target=run, daemon=True).start()
    return {"ok": True, "messaggio": "Installo " + m["nome"] + " (gratis, qualche minuto): poi si apre da solo"}


def open_web_store(url):
    """Apre una pagina di negozio (GOG, Epic...) nel browser a tutto schermo: si torna col tasto EG del controller."""
    if not url.startswith("https://"):
        return
    media_close()
    ff = shutil.which("firefox")
    if not ff:
        _spawn(["xdg-open", url])
        return
    prof = os.path.join(HOME, ".local/share/emagiaku", "play-media")
    os.makedirs(prof, exist_ok=True)
    MEDIA_PROC["p"] = _spawn([ff, "--kiosk", "--new-instance", "--profile", prof, url])


def media_running():
    """True mentre un'app Media o un negozio nel browser e' aperto: il controller fa da mouse (padmouse.py)."""
    p = MEDIA_PROC["p"]
    if p and p.poll() is None:
        return True
    # 27.26: anche mentre e' aperta la finestra di accesso a un negozio o un installatore di Lutris
    return any(q.poll() is None for q in FG_PROCS)


def media_close():
    p = MEDIA_PROC["p"]
    if p and p.poll() is None:
        try:
            os.killpg(p.pid, 15)
        except OSError:
            p.terminate()
        MEDIA_PROC["p"] = None
        return True
    return False


# =============================================================================================== tasto EG del controller
# Il tasto centrale (EG / PS / Xbox / Home, BTN_MODE) da qualsiasi app: chiude l'app media e torna a EG PLAY.
BTN_MODE = 0x13C


def _has_mode_button(ev):
    try:
        caps = open("/sys/class/input/%s/device/capabilities/key" % ev).read().split()
    except OSError:
        return False
    bits = 0
    for word in caps:                                  # le parole sono dalla piu' alta alla piu' bassa
        bits = (bits << 64) | int(word, 16)
    return bool(bits >> BTN_MODE & 1)


def watch_home_button(on_press):
    def loop():
        fds = {}
        last_scan = 0
        while True:
            if time.time() - last_scan > 5:          # controller collegati dopo (Bluetooth)
                last_scan = time.time()
                for path in glob.glob("/dev/input/event*"):
                    ev = os.path.basename(path)
                    if ev in fds.values() or not _has_mode_button(ev):
                        continue
                    try:
                        fds[os.open(path, os.O_RDONLY | os.O_NONBLOCK)] = ev
                    except OSError:
                        pass
            if not fds:
                time.sleep(2)
                continue
            r, _, _ = select.select(list(fds), [], [], 2)
            for fd in r:
                try:
                    data = os.read(fd, 24 * 32)
                except OSError:
                    os.close(fd)
                    fds.pop(fd, None)
                    continue
                for i in range(0, len(data) - 23, 24):
                    _, _, t, code, val = struct.unpack("llHHi", data[i:i + 24])
                    if t == 1 and code == BTN_MODE and val == 1:
                        try:
                            on_press()
                        except Exception:
                            pass
    threading.Thread(target=loop, daemon=True).start()


# =============================================================================================== INSTALLAZIONE (27.25)
# Installatore di EG PLAY OS col controller: l'interfaccia e' in EG PLAY, il lavoro da root lo fa
# /usr/bin/emagiaku-play-install-backend (solo dalla chiavetta: li' l'utente live ha sudo senza password).
INST_BACKEND = "/usr/bin/emagiaku-play-install-backend"
INST = {"stato": "", "pct": 0, "passo": "", "righe": [], "proc": None}


def _inst_prefix():
    if _run(["sudo", "-n", "true"], 5)[0] == 0:
        return ["sudo", "-n"]
    return None


def install_list():
    if not os.path.isdir("/run/archiso"):
        return {"ok": False, "errore": "L'installazione si fa dalla chiavetta di EG PLAY OS"}
    pre = _inst_prefix()
    if not pre or not os.path.exists(INST_BACKEND):
        return {"ok": False, "errore": "Installatore non disponibile su questa chiavetta"}
    code, out = _run(pre + [INST_BACKEND, "--elenco"], 90)
    try:
        return json.loads(out.strip().splitlines()[-1])
    except (ValueError, IndexError):
        return {"ok": False, "errore": "Non riesco a leggere i dischi"}


def install_start(d):
    if INST["stato"] == "in corso":
        return {"ok": False, "errore": "Installazione già in corso"}
    pre = _inst_prefix()
    if not pre or not os.path.isdir("/run/archiso"):
        return {"ok": False, "errore": "L'installazione si fa dalla chiavetta di EG PLAY OS"}
    modo, disk = str(d.get("modo", "")), str(d.get("disco", ""))
    args = [INST_BACKEND, "--installa", "--modo", modo, "--disk", disk, "--confirm", str(d.get("conferma", "")),
            "--user", str(d.get("utente", ""))[:32], "--host", str(d.get("nome", "EG-PLAY"))[:32],
            "--predefinito", "altro" if d.get("predefinito") == "altro" else "play"]
    if modo == "libero":
        args += ["--spazio", str(int(d.get("spazio", -1)))]
    elif modo == "accanto":
        args += ["--part", str(d.get("partizione", "")), "--gb", str(int(d.get("gb", 0)))]
    if d.get("prova"):
        args.append("--dry-run")
    pw = str(d.get("password", ""))
    if len(pw) < 4 or "\n" in pw:
        return {"ok": False, "errore": "La password deve avere almeno 4 caratteri"}
    INST.update(stato="in corso", pct=0, passo="Avvio…", righe=[])

    def run():
        try:
            p = subprocess.Popen(pre + args, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                 text=True)
            INST["proc"] = p
            p.stdin.write(pw + "\n")
            p.stdin.close()
            errore = ""
            for line in p.stdout:
                line = line.rstrip()
                if line.startswith("PROGRESS "):
                    try:
                        INST["pct"] = int(line.split()[1])
                    except (IndexError, ValueError):
                        pass
                elif line.startswith("== "):
                    INST["passo"] = line[3:]
                elif line.startswith("ERRORE: "):
                    errore = line[8:]
                INST["righe"] = (INST["righe"] + [line])[-40:]
            p.wait()
            if p.returncode == 0 and not errore:
                INST.update(stato="fatto", pct=100, passo="Installazione completata")
            else:
                INST.update(stato="errore", passo=errore or "Non riuscita (codice %d)" % p.returncode)
        except Exception as e:
            INST.update(stato="errore", passo=str(e))
    threading.Thread(target=run, daemon=True).start()
    return {"ok": True, "messaggio": "Installazione avviata"}


def install_status():
    return {k: INST[k] for k in ("stato", "pct", "passo", "righe")}


# =============================================================================================== IMPOSTAZIONI da console
def _run(cmd, timeout=20):
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return r.returncode, (r.stdout or "") + (r.stderr or "")
    except (OSError, subprocess.SubprocessError) as e:
        return 1, str(e)


def wifi_list():
    if not shutil.which("nmcli"):
        return {"ok": False, "errore": "Gestione della rete non disponibile"}
    _run(["nmcli", "dev", "wifi", "rescan"], 10)
    code, out = _run(["nmcli", "-t", "-f", "IN-USE,SSID,SIGNAL,SECURITY", "dev", "wifi", "list"])
    reti, visti = [], set()
    for line in out.splitlines():
        parts = re.split(r"(?<!\\):", line)
        if len(parts) < 4 or not parts[1] or parts[1] in visti:
            continue
        visti.add(parts[1])
        reti.append({"ssid": parts[1].replace("\\:", ":"), "attiva": parts[0] == "*",
                     "segnale": int(parts[2] or 0), "protetta": bool(parts[3] and parts[3] != "--")})
    code, st = _run(["nmcli", "-t", "-f", "STATE", "general"])
    return {"ok": True, "reti": sorted(reti, key=lambda x: (-x["attiva"], -x["segnale"]))[:20],
            "stato": st.strip()}


def wifi_connect(ssid, password):
    if not ssid or len(ssid) > 64 or len(password) > 128:
        return {"ok": False, "errore": "Dati non validi"}
    cmd = ["nmcli", "dev", "wifi", "connect", ssid]
    if password:
        cmd += ["password", password]
    code, out = _run(cmd, 45)
    return {"ok": code == 0, "errore": "" if code == 0 else "Connessione non riuscita: controlla la password"}


def volume_get():
    code, out = _run(["wpctl", "get-volume", "@DEFAULT_AUDIO_SINK@"])
    m = re.search(r"Volume:\s*([\d.]+)", out)
    return {"ok": code == 0 and bool(m), "volume": int(float(m.group(1)) * 100) if m else 0, "muto": "MUTED" in out}


def volume_set(v):
    v = max(0, min(100, int(v)))
    _run(["wpctl", "set-volume", "@DEFAULT_AUDIO_SINK@", "%.2f" % (v / 100)])
    _run(["wpctl", "set-mute", "@DEFAULT_AUDIO_SINK@", "0"])
    return volume_get()


def system_info():
    info = {"versione": "", "spazio": "", "nome": "EG PLAY OS"}
    try:
        info["versione"] = open("/etc/emagiaku/version").read().strip()
    except OSError:
        pass
    try:
        st = os.statvfs(HOME)
        free, tot = st.f_bavail * st.f_frsize, st.f_blocks * st.f_frsize
        info["spazio"] = "%s liberi su %s" % (_gb(free), _gb(tot))
    except OSError:
        pass
    return info


def _gb(b):
    return ("%.1f GB" % (b / 1024 ** 3)).replace(".", ",")


UPDATE = {"stato": "", "pct": 0}


def update_check():
    import updater as U
    m, err = U.check()
    if err:
        return {"ok": False, "errore": err}
    if not m:
        return {"ok": True, "nuovo": False, "versione": U.installed_version()}
    return {"ok": True, "nuovo": True, "versione": m["version"], "note": m.get("notes", "")[:1500]}


def update_install():
    """Scarica e installa l'aggiornamento firmato (come EG Update). L'installatore ricontrolla tutto da root."""
    if UPDATE["stato"] == "in corso":
        return {"ok": True, "messaggio": "Aggiornamento già in corso"}
    UPDATE.update(stato="in corso", pct=0)

    def run():
        import updater as U
        try:
            m, err = U.check()
            if not m:
                UPDATE.update(stato=err or "già aggiornato")
                return
            d = os.path.join(HOME, ".cache", "emagiaku", "update")
            os.makedirs(d, exist_ok=True)
            path = U.download(m, d, lambda p: UPDATE.update(pct=int(p * 0.7)))
            UPDATE["pct"] = 75
            cmd = (["sudo", "-n"] if _run(["sudo", "-n", "true"])[0] == 0 else ["pkexec"]) + \
                ["/usr/bin/emagiaku-update-apply", path]
            code, out = _run(cmd, 1800)
            righe = [l for l in out.strip().splitlines() if l.strip()]
            UPDATE.update(stato="fatto: riavvia la console" if code == 0 else
                          "non riuscito (%s)" % (righe[-1] if righe else "errore"),
                          pct=100 if code == 0 else UPDATE["pct"])
        except Exception as e:
            UPDATE.update(stato="non riuscito (%s)" % e)
    threading.Thread(target=run, daemon=True).start()
    return {"ok": True, "messaggio": "Aggiornamento avviato"}


# =============================================================================================== STEAM senza finestra (27.26)
# Su EG PLAY OS Steam resta NASCOSTO: i giochi partono con "-silent -applaunch" e si scaricano scrivendo il loro
# "manifest" (come fa Steam stesso). Cosi' non resta una finestra di Steam da cui col controller non si esce.
STATE = {"steam_login": False}


def steam_root():
    for r in STEAM_ROOTS:
        if os.path.isdir(os.path.join(r, "steamapps")):
            return os.path.realpath(r)
    return None


def steam_running():
    return _run(["pgrep", "-x", "steam"], 5)[0] == 0


def _steam_debug_flag():
    """File che fa leggere a EG Hub la lista amici dal programma di Steam (solo su 127.0.0.1)."""
    root = steam_root()
    if root:
        try:
            open(os.path.join(root, ".cef-enable-remote-debugging"), "a").close()
        except OSError:
            pass


def steam_silent_start():
    # solo se sei gia' entrato in Steam (altrimenti comparirebbe la finestra di accesso)
    if shutil.which("steam") and steam_logged_in() and not steam_running():
        _steam_debug_flag()
        _spawn(["steam", "-silent"])


def steam_restart_silent():
    def run():
        if not shutil.which("steam"):
            return
        if steam_running():
            _run(["steam", "-shutdown"], 30)
            for _ in range(40):
                if not steam_running():
                    break
                time.sleep(1)
        _steam_debug_flag()
        try:
            _spawn(["steam", "-silent"])
        except OSError:
            pass
    threading.Thread(target=run, daemon=True).start()


def steam_launch(appid):
    if not shutil.which("steam"):
        return {"ok": False, "errore": "Steam non è installato"}
    if not steam_logged_in():
        return {"ok": False, "errore": "Collega prima Steam: Impostazioni › Account di gioco"}
    if not steam_running():
        _steam_debug_flag()
    _spawn(["steam", "-silent", "-applaunch", str(appid)])
    return {"ok": True}


def steam_install(appid):
    """Download di un gioco Steam SENZA aprire Steam: si scrive appmanifest_<id>.acf con lo stato
    "da aggiornare" e si riavvia Steam nascosto, che lo scarica da solo (lo vedi in Home con la percentuale)."""
    if not appid.isdigit():
        return {"ok": False, "errore": "Gioco non valido"}
    root = steam_root()
    if not shutil.which("steam"):
        return {"ok": False, "errore": "Steam non è installato"}
    if not root or not steam_logged_in():
        return {"ok": False, "errore": "Collega prima Steam: Impostazioni › Account di gioco"}
    acf =os.path.join(root, "steamapps", "appmanifest_%s.acf" % appid)
    if os.path.exists(acf):
        return {"ok": True, "messaggio": "Il gioco è già installato o si sta scaricando: guarda in Home"}
    name = ""
    try:
        names = json.load(open(os.path.join(CACHE, "steam-names.json"), encoding="utf-8"))
        name = (names.get(appid) or {}).get("nome", "")
    except (OSError, ValueError):
        pass
    if not name:
        try:
            d = _get_json("https://store.steampowered.com/api/appdetails?appids=%s&filters=basic" % appid, 8)
            name = ((d.get(appid) or {}).get("data") or {}).get("name", "")
        except Exception:
            pass
    folder = re.sub(r"[^A-Za-z0-9 ._-]", "", name).strip() or "app%s" % appid
    text = ('"AppState"\n{\n\t"appid"\t\t"%s"\n\t"Universe"\t\t"1"\n\t"name"\t\t"%s"\n\t"StateFlags"\t\t"1026"\n'
            '\t"installdir"\t\t"%s"\n\t"LastUpdated"\t\t"0"\n\t"SizeOnDisk"\t\t"0"\n\t"buildid"\t\t"0"\n'
            '\t"BytesToDownload"\t\t"0"\n\t"BytesDownloaded"\t\t"0"\n\t"AutoUpdateBehavior"\t\t"0"\n'
            '\t"AllowOtherDownloadsWhileRunning"\t\t"0"\n\t"ScheduledAutoUpdate"\t\t"0"\n}\n'
            % (appid, name.replace('"', "") or folder, folder))
    try:
        with open(acf, "w", encoding="utf-8") as f:
            f.write(text)
    except OSError as e:
        return {"ok": False, "errore": "Non riesco a preparare il download: %s" % e}
    steam_restart_silent()
    return {"ok": True, "messaggio": "Download avviato (Steam lavora nascosto): lo vedi in Home con la percentuale"}


def _x_windows():
    from Xlib import display
    d = display.Display()
    out = []

    def walk(w, depth):
        try:
            kids = w.query_tree().children
        except Exception:
            return
        for c in kids:
            try:
                cls = c.get_wm_class() or ()
            except Exception:
                cls = ()
            out.append((c, [x.lower() for x in cls]))
            if depth < 2:
                walk(c, depth + 1)
    walk(d.screen().root, 0)
    return d, out


def hide_steam_windows():
    """Nasconde le finestre di Steam (Steam continua a lavorare, i download vanno avanti)."""
    try:
        from Xlib import X
        d, wins = _x_windows()
        n = 0
        for w, cls in wins:
            if any(k in ("steam", "steamwebhelper") for k in cls):
                try:
                    if w.get_attributes().map_state == X.IsViewable:
                        w.unmap()
                        n += 1
                except Exception:
                    pass
        d.sync()
        return n
    except Exception:
        return 0


def home_pressed():
    """Tasto EG / PS / Xbox / Home: torna sempre a EG PLAY."""
    media_close()
    for q in list(FG_PROCS):                    # finestre di accesso ai negozi: si chiudono
        if q.poll() is None and getattr(q, "eg_tipo", "") == "collega":
            try:
                os.killpg(q.pid, 15)
            except OSError:
                q.terminate()
    hide_steam_windows()
    if STATE["steam_login"]:                    # Steam aperto per entrare: ora resta nascosto
        STATE["steam_login"] = False
        steam_restart_silent()


def _track(p, tipo):
    p.eg_tipo = tipo
    FG_PROCS[:] = [q for q in FG_PROCS if q.poll() is None] + [p]
    return p


# =============================================================================================== LUTRIS: tutti i negozi (27.26)
# Un solo programma (Lutris, gia' nel sistema) per Epic Games, GOG, Amazon, Ubisoft Connect, EA app e Battle.net:
# si collegano da EG PLAY › Impostazioni › Account di gioco (finestra di accesso del negozio) e i giochi arrivano qui.
LUTRIS_DBS = [os.path.join(HOME, ".local/share/lutris/pga.db"),
              os.path.join(HOME, ".var/app/net.lutris.Lutris/data/lutris/pga.db")]
LUTRIS_SERVICES = {"egs": "Epic Games", "gog": "GOG", "amazon": "Amazon", "ubisoft": "Ubisoft",
                   "ea_app": "EA", "battlenet": "Battle.net"}
ROCKSTAR = re.compile(r"Grand Theft Auto|\bGTA\b|Red Dead|Max Payne|L\.A\. Noire|\bBully\b|Midnight Club|Manhunt|"
                      r"Rockstar", re.I)


def _lutris_cmd():
    if shutil.which("lutris"):
        return ["lutris"]
    if _flatpak_has("net.lutris.Lutris"):
        return ["flatpak", "run", "net.lutris.Lutris"]
    return None


def _lutris_query(sql, args=()):
    import sqlite3
    for path in LUTRIS_DBS:
        if not os.path.isfile(path):
            continue
        try:
            con = sqlite3.connect("file:%s?mode=ro" % path, uri=True, timeout=3)
            try:
                con.row_factory = sqlite3.Row
                return [dict(r) for r in con.execute(sql, args)]
            finally:
                con.close()
        except Exception:
            continue
    return []


def _editore(nome):
    return "Rockstar" if ROCKSTAR.search(nome or "") else ""


def lutris_installed():
    """Giochi installati con Lutris (anche Ubisoft / EA / Battle.net): partono da EG PLAY."""
    out = []
    for g in _lutris_query("SELECT id, name, slug, service, lastplayed FROM games WHERE installed = 1"):
        if not g.get("name") or not str(g.get("id", "")).isdigit():
            continue
        fonte = LUTRIS_SERVICES.get(g.get("service") or "", "Lutris")
        out.append({"id": "lutrisgame:%d" % g["id"], "nome": g["name"], "fonte": fonte, "editore": _editore(g["name"]),
                    "ultimo": int(g.get("lastplayed") or 0), "dimensione": 0, "pronto": True, "immagine": False})
    return out


def lutris_library():
    """Giochi posseduti negli account collegati (anche non installati)."""
    installed = {(r.get("service"), str(r.get("service_id"))) for r in
                 _lutris_query("SELECT service, service_id FROM games WHERE installed = 1")}
    out = []
    marks = ",".join("?" * len(LUTRIS_SERVICES))
    for g in _lutris_query("SELECT service, appid, name, icon FROM service_games WHERE service IN (%s)" % marks,
                           tuple(LUTRIS_SERVICES)):
        appid = str(g.get("appid") or "")
        if not g.get("name") or not re.fullmatch(r"[A-Za-z0-9._:-]{1,120}", appid):
            continue
        icon = g.get("icon") or ""
        out.append({"id": "lutris:%s:%s" % (g["service"], appid), "nome": g["name"],
                    "fonte": LUTRIS_SERVICES[g["service"]], "editore": _editore(g["name"]),
                    "installato": (g["service"], appid) in installed,
                    "immagine": icon if str(icon).startswith("https://") else ""})
    return out


def lutris_launch(gid):
    n = gid.partition(":")[2]
    cmd = _lutris_cmd()
    if not n.isdigit() or not cmd:
        return {"ok": False, "errore": "Gioco non valido"}
    _spawn(cmd + ["lutris:rungameid/%s" % n])
    return {"ok": True}


def lutris_install(rest):
    service, _, appid = rest.partition(":")
    cmd = _lutris_cmd()
    if service not in LUTRIS_SERVICES or not cmd:
        return {"ok": False, "errore": "Collega prima il negozio: Impostazioni › Account di gioco"}
    rows = _lutris_query("SELECT lutris_slug FROM service_games WHERE service = ? AND appid = ?", (service, appid))
    slug = (rows[0].get("lutris_slug") if rows else "") or ""
    if not re.fullmatch(r"[a-z0-9-]{1,120}", slug):
        return {"ok": False, "errore": "Per questo gioco non c'è ancora un'installazione automatica"}
    p = subprocess.Popen(cmd + ["lutris:install/" + slug], stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                         stderr=subprocess.DEVNULL, start_new_session=True)
    _track(p, "installa")
    return {"ok": True, "messaggio": "Si apre l'installazione: col controller levetta = cursore, A = clic. "
                                     "Quando ha finito il gioco compare in Home"}


# =============================================================================================== ACCOUNT DI GIOCO (27.26)
COLLEGA = "/usr/bin/emagiaku-play-collega"
NEGOZI = [("steam", "Steam"), ("egs", "Epic Games"), ("gog", "GOG"), ("amazon", "Amazon Games"),
          ("ubisoft", "Ubisoft Connect"), ("ea_app", "EA app"), ("battlenet", "Battle.net"),
          ("rockstar", "Rockstar Games")]


def accounts_status():
    stato = {}
    if os.path.exists(COLLEGA) and _lutris_cmd():
        code, out = _run(["python3", COLLEGA, "--stato"], 30)
        try:
            stato = json.loads(out.strip().splitlines()[-1])
        except (ValueError, IndexError):
            stato = {}
    out = []
    for sid, nome in NEGOZI:
        x = {"id": sid, "nome": nome, "collegato": False, "nota": ""}
        if sid == "steam":
            x["collegato"] = steam_logged_in()
            x["nota"] = "Entri una volta con l'app di Steam a tutto schermo (anche col telefono/QR)"
        elif sid == "rockstar":
            x["collegato"] = None
            x["nota"] = "I giochi Rockstar sono su Steam ed Epic: collega quelli e li trovi nel filtro Rockstar"
        else:
            x["collegato"] = bool(stato.get(sid))
            if sid in ("ubisoft", "ea_app", "battlenet"):
                x["nota"] = "La prima volta si installa da solo il programma del negozio (qualche minuto)"
            if sid not in stato and stato:
                x["collegato"] = None
                x["nota"] = "Non disponibile in questa versione di Lutris"
        out.append(x)
    return {"ok": True, "negozi": out, "lutris": bool(_lutris_cmd())}


def account_connect(sid):
    if sid == "steam":
        if not shutil.which("steam"):
            return {"ok": False, "errore": "Steam non è installato"}
        if steam_running():
            _run(["steam", "-shutdown"], 30)
            time.sleep(3)
        _steam_debug_flag()
        STATE["steam_login"] = True
        _spawn(["steam", "-gamepadui"])     # interfaccia di Steam fatta per il controller (anche accesso con QR)
        return {"ok": True, "messaggio": "Entra nel tuo account Steam, poi premi il tasto EG: Steam resta nascosto"}
    if sid not in LUTRIS_SERVICES:
        return {"ok": False, "errore": "Negozio non valido"}
    if not _lutris_cmd() or not os.path.exists(COLLEGA):
        return {"ok": False, "errore": "Manca Lutris: aggiorna EG PLAY OS (Impostazioni › Sistema)"}
    p = subprocess.Popen(["python3", COLLEGA, sid], stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                         stderr=subprocess.DEVNULL, start_new_session=True)
    _track(p, "collega")
    return {"ok": True, "messaggio": "Si apre l'accesso a %s: levetta sinistra = cursore, A = clic, tastiera in basso. "
                                     "Il tasto EG annulla" % LUTRIS_SERVICES[sid]}


# =============================================================================================== EG HUB (27.26)
def _read(path):
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            return f.read().strip()
    except OSError:
        return ""


def hub_controllers():
    pads = []
    for ev in sorted(glob.glob("/sys/class/input/event*")):
        name = os.path.basename(ev)
        try:
            import padmouse
            if not padmouse._is_gamepad(name):
                continue
        except Exception:
            continue
        nm = _read(os.path.join(ev, "device/name"))
        if nm and nm != "EG PLAY Mouse":
            pads.append(nm)
    batt = []
    for ps in sorted(glob.glob("/sys/class/power_supply/*")):
        if _read(os.path.join(ps, "scope")) != "Device":
            continue
        cap = _read(os.path.join(ps, "capacity"))
        lvl = _read(os.path.join(ps, "capacity_level"))
        nome = _read(os.path.join(ps, "model_name")) or os.path.basename(ps)
        batt.append({"nome": nome, "carica": int(cap) if cap.isdigit() else None, "livello": lvl,
                     "stato": {"Charging": "in carica", "Full": "carica completa", "Discharging": ""}.get(
                         _read(os.path.join(ps, "status")), "")})
    return {"collegati": pads, "batterie": batt}


def _ws_eval(ws_url, expr, timeout=4):
    """Mini client WebSocket (solo libreria standard) per chiedere un dato al programma di Steam."""
    import base64
    import socket
    u = urllib.parse.urlparse(ws_url)
    if u.hostname not in ("127.0.0.1", "localhost"):
        raise ValueError("solo locale")
    s = socket.create_connection((u.hostname, u.port), timeout)
    try:
        key = base64.b64encode(os.urandom(16)).decode()
        s.sendall(("GET %s HTTP/1.1\r\nHost: %s:%d\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n"
                   "Sec-WebSocket-Key: %s\r\nSec-WebSocket-Version: 13\r\n\r\n" % (u.path, u.hostname, u.port, key)).encode())
        buf = b""
        while b"\r\n\r\n" not in buf:
            chunk = s.recv(4096)
            if not chunk:
                raise OSError("chiuso")
            buf += chunk
        head, buf = buf.split(b"\r\n\r\n", 1)
        if b" 101" not in head.split(b"\r\n")[0]:
            raise OSError("niente websocket")
        msg = json.dumps({"id": 1, "method": "Runtime.evaluate",
                          "params": {"expression": expr, "returnByValue": True, "awaitPromise": True}}).encode()
        hdr = bytearray([0x81])
        n = len(msg)
        if n < 126:
            hdr.append(0x80 | n)
        elif n < 65536:
            hdr.append(0x80 | 126)
            hdr += n.to_bytes(2, "big")
        else:
            hdr.append(0x80 | 127)
            hdr += n.to_bytes(8, "big")
        mask = os.urandom(4)
        s.sendall(bytes(hdr) + mask + bytes(b ^ mask[i % 4] for i, b in enumerate(msg)))
        data = b""
        end = time.time() + timeout
        while time.time() < end:
            while len(buf) < 2:
                buf += s.recv(65536)
            ln = buf[1] & 0x7F
            off = 2
            if ln == 126:
                while len(buf) < 4:
                    buf += s.recv(65536)
                ln, off = int.from_bytes(buf[2:4], "big"), 4
            elif ln == 127:
                while len(buf) < 10:
                    buf += s.recv(65536)
                ln, off = int.from_bytes(buf[2:10], "big"), 10
            while len(buf) < off + ln:
                buf += s.recv(65536)
            fin, payload, buf = buf[0] & 0x80, buf[off:off + ln], buf[off + ln:]
            data += payload
            if fin:
                try:
                    r = json.loads(data.decode("utf-8", "replace"))
                except ValueError:
                    r = {}
                data = b""
                if r.get("id") == 1:
                    return ((r.get("result") or {}).get("result") or {}).get("value")
        raise OSError("tempo scaduto")
    finally:
        s.close()


FRIENDS_JS = ("(()=>{try{const a=(g_FriendsUIApp.FriendStore.allFriends||[]);return a.map(f=>{const p=f.persona||f;"
              "return {n:p.m_strPlayerName||'',s:p.m_ePersonaState||0,g:p.m_strGameExtraInfo||''}})}catch(e)"
              "{return {errore:String(e)}}})()")
STATI = {1: "online", 2: "occupato", 3: "assente", 4: "assente", 5: "online", 6: "online"}


def hub_friends():
    """Amici di Steam e cosa giocano: dal programma di Steam acceso su questa console (porta locale 8080)."""
    if not steam_logged_in():
        return {"ok": False, "errore": "Collega Steam per vedere i tuoi amici"}
    if not steam_running():
        return {"ok": False, "errore": "Steam si sta avviando: tra poco vedi i tuoi amici"}
    try:
        req = urllib.request.Request("http://127.0.0.1:8080/json", headers=UA)
        with urllib.request.urlopen(req, timeout=3) as r:
            targets = json.loads(r.read().decode())
        ws = next((t["webSocketDebuggerUrl"] for t in targets if t.get("title") == "SharedJSContext"), None)
        if not ws:
            raise OSError("contesto non trovato")
        lista = _ws_eval(ws, FRIENDS_JS)
    except Exception:
        return {"ok": False, "errore": "Amici non disponibili adesso (riavvia la console se hai appena collegato Steam)"}
    if not isinstance(lista, list):
        return {"ok": False, "errore": "Amici non disponibili con questa versione di Steam"}
    on = [{"nome": f["n"], "stato": STATI.get(f.get("s"), "online"), "gioca": f.get("g", "")}
          for f in lista if isinstance(f, dict) and f.get("s") and f.get("n")]
    on.sort(key=lambda f: (not f["gioca"], f["nome"].lower()))
    return {"ok": True, "online": on[:30], "totale": len(lista)}


def steam_manifests():
    root = steam_root()
    if not root:
        return []
    libs = [root]
    try:
        txt = open(os.path.join(root, "steamapps", "libraryfolders.vdf"), encoding="utf-8", errors="replace").read()
        libs += [v for k, v in re.findall(r'"([^"]+)"\s+"([^"]*)"', txt) if k == "path"]
    except OSError:
        pass
    out = []
    for lib in dict.fromkeys(os.path.realpath(x) for x in libs):
        for acf in glob.glob(os.path.join(lib, "steamapps", "appmanifest_*.acf")):
            try:
                d = dict(re.findall(r'"([^"]+)"\s+"([^"]*)"', open(acf, encoding="utf-8", errors="replace").read()))
            except OSError:
                continue
            flags = int(d.get("StateFlags", "0") or 0)
            tot, done = int(d.get("BytesToDownload", "0") or 0), int(d.get("BytesDownloaded", "0") or 0)
            out.append({"id": d.get("appid", ""), "nome": d.get("name", ""), "flags": flags,
                        "pct": int(done * 100 / tot) if tot else 0, "scarica": bool(flags & 2) or (tot and done < tot)})
    return out


HUB_CACHE = {"t": 0, "os": None, "flatpak": None}


def _cloud_safe():
    try:
        return _cloud_attesa()
    except Exception:
        return ""


def hub_info():
    """EG Hub: controller e batterie, amici online, download e aggiornamenti dei giochi, sistema, EG PLUS."""
    mf = [m for m in steam_manifests() if m["nome"] and not re.match(r"^(Proton|Steam Linux Runtime|Steamworks)", m["nome"])]
    now = time.time()
    if now - HUB_CACHE["t"] > 1800:
        HUB_CACHE["t"] = now

        def bg():
            try:
                upd = update_check()
                HUB_CACHE["os"] = upd if upd.get("ok") else None
            except Exception:
                pass
            if shutil.which("flatpak"):
                code, out = _run(["flatpak", "remote-ls", "--updates", "--user", "--app", "--columns=name"], 40)
                HUB_CACHE["flatpak"] = [l for l in out.splitlines() if l.strip()] if code == 0 else None
        threading.Thread(target=bg, daemon=True).start()
    return {"ok": True, "controller": hub_controllers(), "amici": hub_friends(),
            "download": [m for m in mf if m["scarica"]],
            # aggiornamento = gioco GIA' installato (4) che Steam deve aggiornare (2)
            "aggiornamenti": [m["nome"] for m in mf if m["flags"] & 4 and m["flags"] & 2] + (HUB_CACHE["flatpak"] or []),
            "sistema": HUB_CACHE["os"], "spazio": system_info().get("spazio", ""),
            "cloud": next((p["nome"] for p in CLOUD_PIANI if p["id"] == (_cloud_safe() or "")), "")}


# =============================================================================================== EG CLOUD (27.27)
# Al posto degli abbonamenti EG PLUS: i piani di EG PLAY CLOUD. Non includono giochi (servirebbero accordi con chi li
# crea): includono ORE di un PC cloud con scheda video dove entri con i TUOI account (Steam, EA, Ubisoft...) e giochi
# i tuoi giochi o il tuo abbonamento (es. EA Play). I server non sono ancora accesi: lista d'attesa gratuita, senza
# pagare, salvata nell'Account EMAGIAKU (preferenza "eg_cloud_attesa" = "piano|data", la stessa dell'app EG PLAY CLOUD).
CLOUD_PIANI = [
    {"id": "free", "nome": "FREE", "prezzo": "Gratis", "colore": "#94a3b8",
     "cose": ["5 ore di cloud al mese", "Giochi i giochi dei tuoi account", "Coda standard, fino a 1080p"]},
    {"id": "plus", "nome": "PLUS", "prezzo": "2,99 €/mese", "colore": "#22c55e",
     "cose": ["20 ore di cloud al mese", "Fino a 1080p 60 FPS", "Sessioni fino a 2 ore"]},
    {"id": "pro", "nome": "PRO", "prezzo": "5,99 €/mese", "colore": "#3b82f6",
     "cose": ["50 ore di cloud al mese", "Fino a 1440p", "Priorità nelle code, salvataggi cloud"],
     "nota": "2 mesi inclusi con EG GLASS OS PRO"},
    {"id": "ultra", "nome": "ULTRA", "prezzo": "9,99 €/mese", "colore": "#f59e0b",
     "cose": ["100 ore di cloud al mese", "Fino a 4K e 120 FPS", "PC cloud più potente, accesso prioritario"]},
]
CLOUD_PREF = "eg_cloud_attesa"
CLOUD_NOTA = ("EG PLAY CLOUD è in arrivo: un PC da gioco nel cloud dove entri con i tuoi account (Steam, EA, Ubisoft, "
              "Epic...) e giochi i tuoi giochi senza scaricarli. Non paghi niente adesso: mettiti in lista d'attesa.")


def _cloud_attesa():
    import egcloud
    if not egcloud.load().get("session") and not egcloud.load().get("jwt"):
        return None
    try:
        return str((egcloud._call("GET", "/account/prefs") or {}).get(CLOUD_PREF) or "").split("|")[0]
    except Exception:
        return ""


def cloud_info():
    try:
        attesa = _cloud_attesa()
    except Exception:
        attesa = None
    return {"ok": True, "piani": CLOUD_PIANI, "nota": CLOUD_NOTA, "account": attesa is not None,
            "attesa": attesa or ""}


def cloud_waitlist(pid):
    """Lista d'attesa (gratis): si salva nell'Account EMAGIAKU, la stessa dell'app EG PLAY CLOUD."""
    import egcloud
    if pid and not any(p["id"] == pid for p in CLOUD_PIANI):
        return {"ok": False, "errore": "Piano non valido"}
    if not egcloud.load().get("session") and not egcloud.load().get("jwt"):
        return {"ok": False, "errore": "Entra prima con l'Account EMAGIAKU (Impostazioni › Account EMAGIAKU)"}
    try:
        prefs = egcloud._call("GET", "/account/prefs") or {}
        prefs[CLOUD_PREF] = (pid + "|" + time.strftime("%Y-%m-%d")) if pid else ""
        egcloud._call("PATCH", "/account/prefs", {"prefs": prefs})
    except Exception as e:
        return {"ok": False, "errore": "Non riuscito: %s" % e}
    nome = next((p["nome"] for p in CLOUD_PIANI if p["id"] == pid), "")
    return {"ok": True, "messaggio": ("Sei in lista d'attesa per EG PLAY CLOUD %s: ti avvisiamo quando apre. "
                                      "Non paghi niente adesso." % nome) if pid else "Tolto dalla lista d'attesa"}


# vecchie chiavi EG PLUS (EGPLS-...): restano valide per EG PLAY (vedi common.plus_role)
PLUS_NOMI = {"plus_essential": "EG PLUS Essential", "plus_mega": "EG PLUS Mega", "plus_max": "EG PLUS Max",
             "plus_max_life": "EG PLUS Max (a vita)"}