"""EG PLAY OS (27.25) - controller come mouse e tastiera per le app Media (YouTube, Netflix, negozi nel browser...).

Legge i controller (PlayStation / Xbox / Nintendo / EG Remoto) da /dev/input SENZA prenderli in esclusiva e, solo
quando serve (app Media aperta), muove un mouse + tastiera virtuali (uinput, come vpad.py):

  levetta sinistra   cursore (piu' la spingi, piu' va veloce)      A / Croce     clic
  levetta destra     scorri la pagina (su/giu e destra/sinistra)   B / Cerchio   Esc (esci dallo schermo intero)
  croce direzionale  frecce                                        X / Quadrato  Spazio (play/pausa)
  LB / RB            pagina indietro / avanti                      Y / Triangolo F (schermo intero)
  LT / RT            scorri veloce giu' / su                       Start         Invio
  L3                 clic destro                                   Back / Share  Tab
Il tasto EG / PS / Xbox / Home resta a EG PLAY (chiude l'app e torna alla console).
Solo libreria standard di Python. Permessi: /dev/uinput e i controller (regola 71-emagiaku-controller.rules).
"""
import array
import fcntl
import glob
import os
import select
import struct
import threading
import time

EV_SYN, EV_KEY, EV_REL, EV_ABS = 0, 1, 2, 3
REL_X, REL_Y, REL_HWHEEL, REL_WHEEL = 0, 1, 6, 8
REL_WHEEL_HI_RES, REL_HWHEEL_HI_RES = 11, 12
ABS_X, ABS_Y, ABS_Z, ABS_RX, ABS_RY, ABS_RZ, ABS_HAT0X, ABS_HAT0Y = 0, 1, 2, 3, 4, 5, 0x10, 0x11
BTN_LEFT, BTN_RIGHT = 0x110, 0x111
BTN_SOUTH, BTN_EAST, BTN_NORTH, BTN_WEST = 0x130, 0x131, 0x133, 0x134
BTN_TL, BTN_TR, BTN_TL2, BTN_TR2, BTN_SELECT, BTN_START, BTN_MODE, BTN_THUMBL, BTN_THUMBR = \
    0x136, 0x137, 0x138, 0x139, 0x13A, 0x13B, 0x13C, 0x13D, 0x13E
BTN_DPAD_UP, BTN_DPAD_DOWN, BTN_DPAD_LEFT, BTN_DPAD_RIGHT = 0x220, 0x221, 0x222, 0x223
KEY_ESC, KEY_TAB, KEY_ENTER, KEY_SPACE, KEY_F, KEY_LEFTALT = 1, 15, 28, 57, 33, 56
KEY_UP, KEY_LEFT, KEY_RIGHT, KEY_DOWN = 103, 105, 106, 108

UI_SET_EVBIT, UI_SET_KEYBIT, UI_SET_RELBIT = 0x40045564, 0x40045565, 0x40045566
UI_DEV_CREATE, UI_DEV_DESTROY = 0x5501, 0x5502


def EVIOCGABS(axis):                       # _IOR('E', 0x40 + axis, struct input_absinfo) = 24 byte
    return 0x80184540 + axis


# Nintendo (Switch Pro, Joy-Con) ha A e B scambiati rispetto a Xbox: il tasto "di destra" e' sempre A (conferma).
NINTENDO_VENDOR = 0x057E
BUTTONS = {          # tasto del controller -> (tipo, codici)
    BTN_SOUTH: ("mouse", BTN_LEFT),
    BTN_THUMBL: ("mouse", BTN_RIGHT),
    BTN_EAST: ("key", (KEY_ESC,)),
    BTN_WEST: ("key", (KEY_SPACE,)),       # Xbox X (sinistra) / PS Quadrato
    BTN_NORTH: ("key", (KEY_F,)),          # Xbox Y (sopra) / PS Triangolo
    BTN_START: ("key", (KEY_ENTER,)),
    BTN_SELECT: ("key", (KEY_TAB,)),
    BTN_TL: ("key", (KEY_LEFTALT, KEY_LEFT)),
    BTN_TR: ("key", (KEY_LEFTALT, KEY_RIGHT)),
    BTN_DPAD_UP: ("key", (KEY_UP,)), BTN_DPAD_DOWN: ("key", (KEY_DOWN,)),
    BTN_DPAD_LEFT: ("key", (KEY_LEFT,)), BTN_DPAD_RIGHT: ("key", (KEY_RIGHT,)),
}
OUT_KEYS = {BTN_LEFT, BTN_RIGHT, KEY_ESC, KEY_TAB, KEY_ENTER, KEY_SPACE, KEY_F, KEY_LEFTALT,
            KEY_UP, KEY_LEFT, KEY_RIGHT, KEY_DOWN}
VIRTUAL_NAME = b"EG PLAY Mouse"


def _caps(ev, kind):
    try:
        words = open("/sys/class/input/%s/device/capabilities/%s" % (ev, kind)).read().split()
    except OSError:
        return 0
    bits = 0
    for w in words:
        bits = (bits << 64) | int(w, 16)
    return bits


def _is_gamepad(ev):
    try:
        if open("/sys/class/input/%s/device/name" % ev, "rb").read().strip() == VIRTUAL_NAME:
            return False
    except OSError:
        return False
    keys = _caps(ev, "key")
    return bool(keys >> BTN_SOUTH & 1) and bool(_caps(ev, "abs") >> ABS_X & 1)


def _vendor(ev):
    try:
        return int(open("/sys/class/input/%s/device/id/vendor" % ev).read().strip(), 16)
    except (OSError, ValueError):
        return 0


class VirtualMouse:
    """Mouse + qualche tasto della tastiera (uinput)."""

    def __init__(self):
        self.fd = os.open("/dev/uinput", os.O_WRONLY | os.O_NONBLOCK)
        try:
            for ev in (EV_KEY, EV_REL):
                fcntl.ioctl(self.fd, UI_SET_EVBIT, ev)
            for k in OUT_KEYS:
                fcntl.ioctl(self.fd, UI_SET_KEYBIT, k)
            for r in (REL_X, REL_Y, REL_WHEEL, REL_HWHEEL, REL_WHEEL_HI_RES, REL_HWHEEL_HI_RES):
                fcntl.ioctl(self.fd, UI_SET_RELBIT, r)
            dev = struct.pack("80sHHHHi", VIRTUAL_NAME, 0x06, 0x1209, 0xE6A1, 1, 0)   # bus virtuale
            dev += b"\0" * (64 * 4 * 4)
            os.write(self.fd, dev)
            fcntl.ioctl(self.fd, UI_DEV_CREATE)
        except OSError:
            os.close(self.fd)
            raise
        self.down = set()

    def _ev(self, typ, code, value):
        t = time.time()
        os.write(self.fd, struct.pack("llHHi", int(t), int((t % 1) * 1e6), typ, code, value))

    def syn(self):
        self._ev(EV_SYN, 0, 0)

    def key(self, code, value):
        if value and code in self.down or not value and code not in self.down:
            return
        (self.down.add if value else self.down.discard)(code)
        self._ev(EV_KEY, code, value)

    def move(self, dx, dy):
        if dx:
            self._ev(EV_REL, REL_X, dx)
        if dy:
            self._ev(EV_REL, REL_Y, dy)

    def scroll(self, v_hi, h_hi):
        """Valori in 1/120 di "scatto" della rotellina (alta risoluzione: scorre fluido)."""
        if v_hi:
            self._ev(EV_REL, REL_WHEEL_HI_RES, v_hi)
        if h_hi:
            self._ev(EV_REL, REL_HWHEEL_HI_RES, h_hi)

    def release_all(self):
        for k in list(self.down):
            self.key(k, 0)
        self.syn()

    def close(self):
        try:
            self.release_all()
            fcntl.ioctl(self.fd, UI_DEV_DESTROY)
        except OSError:
            pass
        os.close(self.fd)


class Pad:
    def __init__(self, path, ev):
        self.ev = ev
        self.fd = os.open(path, os.O_RDONLY | os.O_NONBLOCK)
        self.nintendo = _vendor(ev) == NINTENDO_VENDOR
        self.abs = {}            # asse -> (minimo, massimo)
        self.val = {}
        for a in (ABS_X, ABS_Y, ABS_Z, ABS_RX, ABS_RY, ABS_RZ, ABS_HAT0X, ABS_HAT0Y):
            buf = array.array("i", [0] * 6)
            try:
                fcntl.ioctl(self.fd, EVIOCGABS(a), buf, True)
            except OSError:
                continue
            if buf[2] > buf[1]:
                self.abs[a] = (buf[1], buf[2])
                self.val[a] = buf[0]

    def norm(self, a):
        """Asse tra -1 e 1 (levette) o tra 0 e 1 (grilletti)."""
        if a not in self.abs:
            return 0.0
        lo, hi = self.abs[a]
        v = self.val.get(a, 0)
        if a in (ABS_Z, ABS_RZ) and lo >= 0:
            return (v - lo) / float(hi - lo)
        return max(-1.0, min(1.0, (2.0 * (v - lo) / (hi - lo)) - 1.0))


class PadMouse:
    """Gira in un thread. `active()` dice quando trasformare il controller in mouse (es. app Media aperta)."""

    def __init__(self, active):
        self.active = active
        self.pads = {}
        self.mouse = None
        self.err = ""

    def _scan(self):
        for path in glob.glob("/dev/input/event*"):
            ev = os.path.basename(path)
            if any(p.ev == ev for p in self.pads.values()) or not _is_gamepad(ev):
                continue
            try:
                p = Pad(path, ev)
                self.pads[p.fd] = p
            except OSError:
                pass

    def _button(self, p, code, value):
        if p.nintendo and code in (BTN_SOUTH, BTN_EAST):     # Nintendo: A e' a destra (BTN_EAST)
            code = BTN_EAST if code == BTN_SOUTH else BTN_SOUTH
        m =BUTTONS.get(code)
        if not m or not self.mouse:
            return
        kind, out = m
        if kind == "mouse":
            self.mouse.key(out, value)
        else:
            seq = out if value else tuple(reversed(out))
            for k in seq:
                self.mouse.key(k, value)
        self.mouse.syn()

    def _hat(self, p, axis, value):
        if not self.mouse:
            return
        neg, pos = (KEY_LEFT, KEY_RIGHT) if axis == ABS_HAT0X else (KEY_UP, KEY_DOWN)
        self.mouse.key(neg, 1 if value < 0 else 0)
        self.mouse.key(pos, 1 if value > 0 else 0)
        self.mouse.syn()

    def _tick(self, dt):
        """Movimento continuo: cursore e scorrimento in base a quanto sono spinte levette e grilletti."""
        dx = dy = sv = sh = 0.0
        for p in self.pads.values():
            lx, ly, rx, ry = p.norm(ABS_X), p.norm(ABS_Y), p.norm(ABS_RX), p.norm(ABS_RY)
            dz = lambda v: 0.0 if abs(v) < 0.15 else (abs(v) - 0.15) / 0.85 * (1 if v > 0 else -1)
            lx, ly, rx, ry = dz(lx), dz(ly), dz(rx), dz(ry)
            speed = 1400.0                                   # pixel al secondo a levetta tutta spinta
            dx += (lx * abs(lx)) * speed * dt                # curva: preciso piano, veloce in fondo
            dy += (ly * abs(ly)) * speed * dt
            sv += -ry * 1500.0 * dt                          # 1/120 di scatto
            sh += rx * 1500.0 * dt
            lt, rt = p.norm(ABS_Z), p.norm(ABS_RZ)
            if lt > 0.1:
                sv -= lt * 4000.0 * dt
            if rt > 0.1:
                sv += rt * 4000.0 * dt
        self._rest = getattr(self, "_rest", [0.0, 0.0, 0.0, 0.0])
        r = self._rest
        r[0] += dx; r[1] += dy; r[2] += sv; r[3] += sh
        mx, my, v, h = int(r[0]), int(r[1]), int(r[2]), int(r[3])
        r[0] -= mx; r[1] -= my; r[2] -= v; r[3] -= h
        if mx or my or v or h:
            self.mouse.move(mx, my)
            self.mouse.scroll(v, h)
            self.mouse.syn()

    def run(self):
        last_scan, last_tick, was_on = 0.0, time.time(), False
        while True:
            now = time.time()
            if now - last_scan > 3:                          # controller collegati dopo (Bluetooth)
                last_scan = now
                self._scan()
            on = False
            try:
                on = bool(self.active())
            except Exception:
                pass
            if on and not self.mouse:
                try:
                    self.mouse = VirtualMouse()
                except OSError as e:
                    self.err = "uinput non disponibile: %s" % e
                    time.sleep(5)
                    continue
            if not on and was_on and self.mouse:
                self.mouse.close()                            # niente mouse finto mentre giochi
                self.mouse = None
            was_on = on
            if not self.pads:
                time.sleep(1)
                continue
            r, _, _ = select.select(list(self.pads), [], [], 0.012 if on else 0.5)
            for fd in r:
                p = self.pads.get(fd)
                try:
                    data = os.read(fd, 24 * 64)
                except OSError:
                    os.close(fd)
                    self.pads.pop(fd, None)
                    continue
                for i in range(0, len(data) - 23, 24):
                    _, _, t, code, val = struct.unpack("llHHi", data[i:i + 24])
                    if t == EV_ABS:
                        p.val[code] = val
                        if on and code in (ABS_HAT0X, ABS_HAT0Y):
                            self._hat(p, code, val)
                    elif t == EV_KEY and on and code != BTN_MODE and val in (0, 1):
                        self._button(p, code, val)
            now = time.time()
            if on and self.mouse:
                self._tick(min(0.05, now - last_tick))
            last_tick = now


def start(active):
    pm = PadMouse(active)
    threading.Thread(target=pm.run, daemon=True).start()
    return pm


if __name__ == "__main__":       # prova a mano: emagiaku-play-mouse (sempre attivo finche' non premi Ctrl+C)
    print("Controller = mouse. Ctrl+C per uscire.")
    PadMouse(lambda: True).run()
