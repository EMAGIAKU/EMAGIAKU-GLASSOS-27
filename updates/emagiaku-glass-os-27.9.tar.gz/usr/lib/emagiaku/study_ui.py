"""EMAGIAKU GLASS OS 27 STUDY - parti comuni delle app di studio.

Stile viola/nero con glass, animazione di apertura, controllo dell'edizione,
materie e salvataggio dei dati (tutto in locale, in file JSON leggibili).
"""
import json
import os
import subprocess
import sys

import common as c
import logic as L

HOME = os.path.expanduser("~")
STUDY_DIR = os.path.join(HOME, ".local", "share", "emagiaku", "study")


def documents_dir():
    try:
        out = subprocess.run(["xdg-user-dir", "DOCUMENTS"], capture_output=True, text=True, timeout=5).stdout.strip()
        if out and out != HOME and os.path.isdir(out):
            return out
    except (OSError, subprocess.SubprocessError):
        pass
    for name in ("Documenti", "Documents"):
        p = os.path.join(HOME, name)
        if os.path.isdir(p):
            return p
    return os.path.join(HOME, "Documenti")


NOTES_DIR = os.path.join(documents_dir(), "EG Notes")
LIBRARY_DIR = os.path.join(documents_dir(), "EG Library")

DEFAULT_SUBJECTS = ["Italiano", "Matematica", "Inglese", "Storia", "Geografia", "Scienze",
                    "Fisica", "Informatica", "Arte", "Musica", "Educazione fisica"]

STUDY_STYLE = L.GLASS_STYLE + """
QTabWidget::pane { border: 1px solid #3a2a60; border-radius: 12px; top: -1px; }
QTabBar::tab { background: #1b1230; padding: 9px 16px; margin-right: 3px;
               border-top-left-radius: 10px; border-top-right-radius: 10px; }
QTabBar::tab:selected { background: #8a4fff; color: white; }
QFrame#card { background: rgba(38, 24, 64, 200); border: 1px solid #3a2a60; border-radius: 16px; }
QLabel#big { font-size: 34px; font-weight: 800; color: white; background: transparent; }
QLabel#cardtitle { font-size: 15px; font-weight: 700; color: #c9a4ff; background: transparent; }
QLabel#muted { color: #968caa; background: transparent; }
QTableWidget, QTreeWidget { background: #1b1230; border: 1px solid #3a2a60; border-radius: 10px;
                            gridline-color: #2c1f48; }
QHeaderView::section { background: #261840; color: #c9a4ff; border: none; padding: 6px; }
QTextEdit { background: #1b1230; border: 1px solid #3a2a60; border-radius: 10px; padding: 8px; }
QCalendarWidget QWidget { alternate-background-color: #1b1230; }
QCalendarWidget QAbstractItemView:enabled { background: #1b1230; selection-background-color: #8a4fff; }
QSpinBox, QDateEdit, QTimeEdit { background: #1b1230; border: 1px solid #3a2a60; border-radius: 8px; padding: 4px 8px; }
QCheckBox { background: transparent; }
"""


# ------------------------------------------------------------- dati
def data_path(name):
    os.makedirs(STUDY_DIR, exist_ok=True)
    return os.path.join(STUDY_DIR, name)


def load_json(name, default):
    try:
        with open(data_path(name), encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return default


def save_json(name, data):
    p = data_path(name)
    tmp = p + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    os.replace(tmp, p)   # salvataggio atomico: niente file a meta' se si spegne il PC


def subjects():
    return load_json("subjects.json", DEFAULT_SUBJECTS) or list(DEFAULT_SUBJECTS)


def save_subjects(lst):
    save_json("subjects.json", [s for s in dict.fromkeys(x.strip() for x in lst) if s])


def safe_name(name):
    keep = "".join(ch for ch in name if ch.isalnum() or ch in " -_'.,()").strip(" .")
    return keep[:80] or "senza nome"


def open_path(path):
    subprocess.Popen(["xdg-open", path], start_new_session=True)


def launch(app):
    subprocess.Popen(["/usr/bin/" + app], start_new_session=True)


def pdf_text(path, max_chars=200000):
    """Testo di un PDF con pdftotext (poppler). '' se non disponibile."""
    try:
        r = subprocess.run(["pdftotext", "-layout", "-q", path, "-"], capture_output=True, text=True, timeout=60)
        return r.stdout[:max_chars] if r.returncode == 0 else ""
    except (OSError, subprocess.SubprocessError):
        return ""


# --------------------------------------------------------- interfaccia
def app_icon():
    """Icona propria di ogni app STUDY (emagiaku-notes, emagiaku-focus...)."""
    name = os.path.basename(sys.argv[0] if sys.argv else "")
    return name if name.startswith("emagiaku-") else "emagiaku-study-hub"


def header(title, subtitle):
    from PyQt6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel
    from PyQt6.QtGui import QIcon
    w = QWidget()
    row = QHBoxLayout(w)
    row.setContentsMargins(0, 0, 0, 6)
    ic = QLabel()
    ic.setPixmap(QIcon.fromTheme(app_icon()).pixmap(44, 44))
    ic.setStyleSheet("background: transparent;")
    row.addWidget(ic)
    col = QVBoxLayout()
    t = QLabel(title)
    t.setObjectName("h")
    s = QLabel(subtitle)
    s.setObjectName("s")
    col.addWidget(t)
    col.addWidget(s)
    row.addLayout(col, 1)
    tag = QLabel("STUDY")
    tag.setStyleSheet("background: #8a4fff; color: white; font-weight: 800; border-radius: 9px; padding: 4px 10px;")
    row.addWidget(tag)
    return w


def card(title=None):
    from PyQt6.QtWidgets import QFrame, QVBoxLayout, QLabel
    f = QFrame()
    f.setObjectName("card")
    lay = QVBoxLayout(f)
    if title:
        t = QLabel(title)
        t.setObjectName("cardtitle")
        lay.addWidget(t)
    return f, lay


def fade_in(w):
    from PyQt6.QtCore import QPropertyAnimation, QEasingCurve
    if c.load_conf().get("light_mode") or c.load_conf().get("motion") == "off":
        return
    w.setWindowOpacity(0.0)
    a = QPropertyAnimation(w, b"windowOpacity", w)
    a.setDuration(260)
    a.setStartValue(0.0)
    a.setEndValue(1.0)
    a.setEasingCurve(QEasingCurve.Type.OutCubic)
    a.start()
    w._fade = a


def locked_dialog(app_name):
    """Mostrata se l'edizione STUDY non e' attiva. True se l'utente la attiva qui."""
    from PyQt6.QtWidgets import QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton
    d = QDialog()
    d.setWindowTitle(app_name)
    d.setStyleSheet(STUDY_STYLE)
    lay = QVBoxLayout(d)
    lay.addWidget(header(app_name, "Fa parte di EMAGIAKU GLASS OS 27 STUDY"))
    m = QLabel("Questa app e' inclusa nell'edizione <b>STUDY</b> (5 €): Study Hub, Notes, Focus, "
               "Calculator, Library e AI Study.<br><br>Puoi acquistarla con PayPal oppure, se hai gia' "
               "una chiave STUDY, attivarla qui.")
    m.setWordWrap(True)
    lay.addWidget(m)
    row = QHBoxLayout()
    close = QPushButton("Chiudi")
    close.setObjectName("alt")
    close.clicked.connect(d.reject)
    act = QPushButton("Attiva chiave")
    buy_btn = QPushButton("Acquista STUDY con PayPal - %s" % c.BUY_PRICES["study"])
    buy_btn.setStyleSheet("background: #8a4fff; color: white; font-weight: 800;")

    def do_buy():
        import pro_ui
        pro_ui.buy(d, "study")
    buy_btn.clicked.connect(do_buy)
    row.addStretch(1)
    row.addWidget(close)
    row.addWidget(buy_btn)
    row.addWidget(act)
    lay.addLayout(row)

    def activate():
        import pro_ui
        pro_ui.ActivateDialog(d).exec()
        if c.has_study():
            d.accept()
    act.clicked.connect(activate)
    return d.exec() == QDialog.DialogCode.Accepted and c.has_study()


def run_app(name, window_factory):
    """Avvio comune: registro errori, controllo edizione, glass, animazione."""
    from PyQt6.QtWidgets import QApplication
    from PyQt6.QtGui import QIcon
    L.install_crash_guard(name)
    app = QApplication(sys.argv)
    app.setApplicationName(name)
    app.setWindowIcon(QIcon.fromTheme(app_icon()))
    if not c.has_study() and not locked_dialog(name):
        return 0
    w = window_factory()
    w.setStyleSheet(STUDY_STYLE + (w.styleSheet() or ""))
    L.glass_window(w)
    fade_in(w)
    w.show()
    return app.exec()
