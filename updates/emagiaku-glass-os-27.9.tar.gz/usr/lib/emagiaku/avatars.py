"""EG Account - icone profilo EMAGIAKU (disegni originali, generati come SVG).

Ogni icona = colori (sfumatura) + simbolo (iniziale o disegno) + stile (cerchio o glass).
"""
import os
import subprocess

PALETTES = [  # nome, colore 1, colore 2
    ("Viola EMAGIAKU", "#a070ff", "#3b0f8a"), ("Rosa neon", "#ff6ad5", "#8a1f6b"),
    ("Notte", "#3a2a60", "#07040d"), ("Blu elettrico", "#4f8cff", "#14246b"),
    ("Ciano", "#2ee6e6", "#0b5d7a"), ("Menta", "#5ef2a8", "#0d6b4a"),
    ("Lime", "#c6f432", "#4b7a0d"), ("Oro", "#ffd34f", "#a6620b"),
    ("Arancio", "#ff9a3d", "#a3330b"), ("Rosso fuoco", "#ff4f5e", "#7a0b1f"),
    ("Pesca", "#ffc2a8", "#d65c7a"), ("Lilla", "#d9b8ff", "#7a4fd6"),
    ("Tramonto", "#ffb04f", "#c13cf0"), ("Aurora", "#4fffd2", "#8a4fff"),
    ("Ghiaccio", "#e6f4ff", "#7aa6d6"), ("Grafite", "#8a8a9a", "#1e1e28"),
]

# simboli disegnati a mano (coordinate 0..100, centro 50,50), riempiti di bianco
SYMBOLS = {
    "iniziale": None,
    "stella": "M50 14 L60 39 L87 40 L66 57 L73 84 L50 69 L27 84 L34 57 L13 40 L40 39 Z",
    "corona": "M18 70 L22 34 L38 50 L50 26 L62 50 L78 34 L82 70 Z M20 76 H80 V84 H20 Z",
    "fulmine": "M56 10 L26 56 H46 L40 90 L74 42 H54 Z",
    "cuore": "M50 82 C20 62 14 44 22 32 C30 20 45 22 50 34 C55 22 70 20 78 32 C86 44 80 62 50 82 Z",
    "controller": "M24 38 C14 38 10 52 12 66 C14 76 24 78 30 70 L36 62 H64 L70 70 C76 78 86 76 88 66 "
                  "C90 52 86 38 76 38 Z",
    "nota": "M40 20 L76 12 V62 A10 10 0 1 1 68 52 V30 L48 34 V70 A10 10 0 1 1 40 60 Z",
    "luna": "M60 14 A36 36 0 1 0 86 62 A28 28 0 1 1 60 14 Z",
    "fiamma": "M50 10 C64 30 76 40 74 60 C72 78 60 88 50 88 C40 88 28 78 26 60 C25 46 34 40 40 30 "
              "C42 44 48 48 52 48 C56 40 50 24 50 10 Z",
    "razzo": "M50 8 C66 22 70 44 64 66 H36 C30 44 34 22 50 8 Z M36 60 L22 78 L36 74 Z M64 60 L78 78 L64 74 Z "
             "M42 70 H58 L54 90 H46 Z",
    "gatto": "M22 30 L34 44 C44 40 56 40 66 44 L78 30 L80 58 C80 76 66 86 50 86 C34 86 20 76 20 58 Z",
    "fantasma": "M24 50 C24 30 36 16 50 16 C64 16 76 30 76 50 V86 L68 78 L59 86 L50 78 L41 86 L32 78 L24 86 Z",
    "diamante": "M30 18 H70 L88 40 L50 88 L12 40 Z",
    "nuvola": "M28 76 C16 76 10 66 14 57 C18 48 28 48 31 50 C33 36 47 30 57 36 C65 28 81 34 80 48 "
              "C90 50 92 64 86 70 C82 76 76 76 72 76 Z",
    "foglia": "M20 80 C20 40 46 18 84 16 C84 54 62 80 24 84 L36 64 Z",
    "eg": None,
}
SYMBOL_LABELS = {"iniziale": "Iniziale", "stella": "Stella", "corona": "Corona", "fulmine": "Fulmine",
                 "cuore": "Cuore", "controller": "Controller", "nota": "Musica", "luna": "Luna",
                 "fiamma": "Fiamma", "razzo": "Razzo", "gatto": "Gatto", "fantasma": "Fantasma",
                 "diamante": "Diamante", "nuvola": "Nuvola", "foglia": "Foglia", "eg": "EG"}
STYLES = {"cerchio": "Cerchio", "glass": "Glass", "quadrato": "Quadrato"}


def _esc(t):
    return t.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")


def svg(palette=0, symbol="iniziale", style="glass", initial="E"):
    _name, c1, c2 = PALETTES[palette % len(PALETTES)]
    if style == "quadrato":
        bg = '<rect x="0" y="0" width="100" height="100" rx="22" fill="url(#g)"/>'
        clip = '<rect x="0" y="0" width="100" height="100" rx="22"/>'
    else:
        bg = '<circle cx="50" cy="50" r="50" fill="url(#g)"/>'
        clip = '<circle cx="50" cy="50" r="50"/>'
    shine, ring = "", ""
    if style == "glass":   # riflesso glass (dentro la forma) + bordo luminoso
        # tutto DENTRO il cerchio: QtSvg ignora clipPath
        shine = '<ellipse cx="50" cy="30" rx="36" ry="20" fill="#ffffff" fill-opacity="0.18"/>'
        ring = '<circle cx="50" cy="50" r="48.5" fill="none" stroke="#ffffff" stroke-opacity="0.35" stroke-width="3"/>'
    if symbol in ("iniziale", "eg"):
        txt = "EG" if symbol == "eg" else _esc((initial or "?").strip()[:2].upper())
        size = 52 if len(txt) == 1 else 38
        # QtSvg non gestisce dominant-baseline: centro a mano (la linea di base sta ~0.36 em sotto il centro)
        mark = ('<text x="50" y="%.1f" text-anchor="middle" font-family="Noto Sans, sans-serif" '
                'font-weight="900" font-size="%d" fill="#ffffff">%s</text>' % (50 + size * 0.36, size, txt))
    else:
        mark = '<g transform="translate(18 18) scale(0.64)"><path d="%s" fill="#ffffff"/></g>' % SYMBOLS[symbol]
    return ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" width="256" height="256">'
            '<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1">'
            '<stop offset="0" stop-color="%s"/><stop offset="1" stop-color="%s"/></linearGradient>'
            '<clipPath id="c">%s</clipPath></defs>%s<g clip-path="url(#c)">%s%s</g>%s</svg>'
            % (c1, c2, clip, bg, shine, mark, ring))


def render_png(svg_text, path, size=256):
    """Disegna l'SVG in un PNG (serve Qt). Restituisce True se riesce."""
    from PyQt6.QtCore import QByteArray, QRectF
    from PyQt6.QtGui import QImage, QPainter, QColor
    from PyQt6.QtSvg import QSvgRenderer
    r = QSvgRenderer(QByteArray(svg_text.encode("utf-8")))
    if not r.isValid():
        return False
    img = QImage(size, size, QImage.Format.Format_ARGB32)
    img.fill(QColor(0, 0, 0, 0))
    p = QPainter(img)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    r.render(p, QRectF(0, 0, size, size))
    p.end()
    return img.save(path, "PNG")


def set_profile_picture(png_path):
    """Imposta l'immagine del profilo: per il sistema (AccountsService: schermata password, menu)
    e per KDE (~/.face.icon). Restituisce (ok_sistema, ok_utente)."""
    import shutil
    home = os.path.expanduser("~")
    ok_user = False
    try:
        for name in (".face.icon", ".face"):
            dst = os.path.join(home, name)
            if os.path.islink(dst):
                os.remove(dst)
            shutil.copyfile(png_path, dst)
            os.chmod(dst, 0o644)
        ok_user = True
    except OSError:
        pass
    ok_sys = False
    if shutil.which("busctl"):
        r = subprocess.run(["busctl", "call", "--system", "org.freedesktop.Accounts",
                            "/org/freedesktop/Accounts/User%d" % os.getuid(), "org.freedesktop.Accounts.User",
                            "SetIconFile", "s", os.path.join(home, ".face.icon")],
                           capture_output=True, text=True, timeout=60)
        ok_sys = r.returncode == 0
    return ok_sys, ok_user


def default_initial():
    import pwd
    try:
        pw = pwd.getpwuid(os.getuid())
        name = (pw.pw_gecos.split(",")[0] or pw.pw_name).strip()
    except KeyError:
        name = os.environ.get("USER", "E")
    return (name[:1] or "E").upper()
