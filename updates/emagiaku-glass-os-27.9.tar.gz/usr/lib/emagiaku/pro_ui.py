"""EMAGIAKU GLASS OS PRO - finestre condivise (promo, attivazione chiave, pannello amministratore)."""
import common as c
import logic as L
from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QLineEdit,
                             QComboBox, QSpinBox, QFormLayout, QCheckBox, QFrame)

PRO_STYLE = L.GLASS_STYLE + """
QFrame#hero { border-radius: 20px; background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #8a4fff, stop:1 #2b0f5e); }
QLabel#big { font-size: 30px; font-weight: 900; color: white; background: transparent; }
QLabel#tag { font-size: 17px; color: #f1e8ff; background: transparent; }
QLabel#price { font-size: 40px; font-weight: 900; color: white; background: transparent; }
QPushButton#buy { background: white; color: #4b1fb0; font-weight: 800; font-size: 15px; padding: 11px 18px; }
QPushButton#buy:hover { background: #efe6ff; }
QPushButton#key { background: white; color: #4b1fb0; font-weight: 800; }
"""


def buy(parent, edition):
    """Apre il pagamento PayPal nel browser e spiega come arriva la chiave."""
    import subprocess
    from PyQt6.QtWidgets import QMessageBox
    name = "PRO" if edition == "pro" else "STUDY"
    link = c.BUY_LINKS[edition]
    box = QMessageBox(parent)
    box.setWindowTitle("Acquista EMAGIAKU GLASS OS 27 %s" % name)
    box.setTextFormat(Qt.TextFormat.RichText)
    box.setText(
        "<b>EMAGIAKU GLASS OS 27 %s - %s</b><br><br>"
        "1. Si apre la pagina di pagamento <b>PayPal</b> di EMAGIAKU (serve internet).<br>"
        "2. Paga <b>%s</b>. Nella nota del pagamento scrivi <b>&quot;%s&quot;</b> e, se vuoi, l'email "
        "dove ricevere la chiave.<br>"
        "3. Riceverai la tua chiave <b>%s</b> da EMAGIAKU.TEAM all'email del tuo conto PayPal.<br>"
        "4. Inseriscila con <b>Attiva chiave</b>.<br><br>"
        "<span style='color:#968caa'>Il pagamento avviene sul sito di PayPal: EMAGIAKU GLASS OS non vede "
        "e non salva i tuoi dati di pagamento.</span>"
        % (name, c.BUY_PRICES[edition], c.BUY_PRICES[edition], name, "EGPRO-..." if edition == "pro" else "EGSTD-..."))
    box.setStandardButtons(QMessageBox.StandardButton.Ok | QMessageBox.StandardButton.Cancel)
    box.button(QMessageBox.StandardButton.Ok).setText("Vai a PayPal")
    box.button(QMessageBox.StandardButton.Cancel).setText("Annulla")
    if box.exec() == QMessageBox.StandardButton.Ok:
        try:
            subprocess.Popen(["xdg-open", link], start_new_session=True)
        except OSError:
            QMessageBox.information(parent, "PayPal", "Apri questo indirizzo nel browser:\n" + link)


def scan_text(s):
    lines = ["<b>CPU:</b> %s (%d thread)" % (s["cpu"], s["threads"]),
             "<b>RAM:</b> %.1f GB" % s["ram_gb"],
             "<b>Grafica:</b> %s" % "<br>".join(s["gpu"])]
    if s["old"]:
        lines.append("<br><b style='color:#ffd36e'>PC datato</b> (%s): la Modalita' Gioco PRO "
                     "chiudera' le altre app quando avvii un gioco." % ", ".join(s["reasons"]))
    else:
        lines.append("<br><b style='color:#8affc1'>PC recente</b>: la Modalita' Gioco resta in automatico "
                     "e non chiude le app (puoi forzarla dal pannello amministratore).")
    return "<br>".join(lines)


def run_scan_and_save():
    conf = c.load_pro()
    conf["scan"] = c.scan_hardware(conf)
    c.save_pro(conf)
    return conf["scan"]


class ActivateDialog(QDialog):
    """Chiede la chiave. Dopo l'attivazione scansiona il PC."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.role = None
        self.setWindowTitle("Attiva EMAGIAKU GLASS OS 27 PRO / STUDY")
        self.setStyleSheet(PRO_STYLE)
        self.setMinimumWidth(480)
        lay = QVBoxLayout(self)
        h = QLabel("Attiva chiave")
        h.setObjectName("h")
        lay.addWidget(h)
        self.key = QLineEdit()
        self.key.setPlaceholderText("EGPRO-XXXX-...  oppure  EGSTD-XXXX-...")
        self.key.setStyleSheet("font-size: 17px; padding: 10px; letter-spacing: 1px;")
        self.key.returnPressed.connect(self.try_key)
        lay.addWidget(self.key)
        self.msg = QLabel("")
        self.msg.setWordWrap(True)
        lay.addWidget(self.msg)
        row = QHBoxLayout()
        self.cancel = QPushButton("Annulla")
        self.cancel.setObjectName("alt")
        self.cancel.clicked.connect(self.reject)
        self.ok = QPushButton("Attiva")
        self.ok.clicked.connect(self.try_key)
        row.addStretch(1)
        row.addWidget(self.cancel)
        row.addWidget(self.ok)
        lay.addLayout(row)

    def try_key(self):
        if self.role:
            self.accept()
            return
        role = c.activate_key(self.key.text())
        if not role:
            self.msg.setText("<span style='color:#ff8aa0'>Chiave non valida.</span>")
            return
        self.role = role
        self.key.setEnabled(False)
        study_txt = ("Le app STUDY sono nel menu (categoria Istruzione): EG Study Hub, EG Notes, EG Focus, "
                     "EG Calculator, EG Library, EG AI Study.")
        if role == "study":
            self.msg.setText("<b style='color:#8affc1'>EMAGIAKU GLASS OS 27 STUDY attivato.</b><br><br>%s<br><br>"
                             "<i>Studia meglio. Rimani concentrato.</i>" % study_txt)
        else:
            self.msg.setText("Attivata! Scansiono il tuo PC...")
            self.repaint()
            s = run_scan_and_save()
            who = {"admin": "PRO + STUDY (AMMINISTRATORE)", "test": "PRO + STUDY (CHIAVE DI PROVA)",
                   "prize": "PRO + STUDY (PREMIO)"}.get(role, "PRO")
            extra = ("<br><br>" + study_txt) if role in c.FULL_ROLES else ""
            self.msg.setText("<b style='color:#8affc1'>EMAGIAKU GLASS OS 27 %s attivato.</b><br><br>%s%s"
                             % (who, scan_text(s), extra))
        self.cancel.hide()
        self.ok.setText("Fatto")


class PromoDialog(QDialog):
    """ACQUISTA EGGLASS OS PRO - gaming anche su PC scarsi."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("EMAGIAKU GLASS OS 27 - Edizioni")
        self.setStyleSheet(PRO_STYLE)
        self.setMinimumWidth(760)
        lay = QVBoxLayout(self)
        intro = QLabel("Stai usando <b>EMAGIAKU GLASS OS 27 STANDARD</b>. Passa a un'altra edizione:")
        intro.setWordWrap(True)
        lay.addWidget(intro)
        cards = QHBoxLayout()
        for edition, title, tag, grad in (
                ("pro", "ACQUISTA EGGLASS OS PRO",
                 "Gaming anche su PC scarsi: quando avvii un gioco, PRO chiude tutto il resto e lascia "
                 "scheda grafica e processore solo al gioco. Pannello prestazioni dedicato.",
                 "stop:0 #8a4fff, stop:1 #2b0f5e"),
                ("study", "EMAGIAKU GLASS OS 27 STUDY",
                 "Per studenti e scuole: Study Hub, Notes, Focus (Pomodoro), Calculator scientifica, "
                 "Library e AI Study. Studia meglio. Rimani concentrato.",
                 "stop:0 #5b3fd9, stop:1 #12082a")):
            price = c.BUY_PRICES[edition]
            hero = QFrame()
            hero.setObjectName("hero")
            hero.setStyleSheet("QFrame#hero { border-radius: 20px; background: qlineargradient(x1:0, y1:0, "
                               "x2:1, y2:1, %s); }" % grad)
            hl = QVBoxLayout(hero)
            hl.setContentsMargins(24, 22, 24, 22)
            a = QLabel(title)
            a.setObjectName("big")
            a.setStyleSheet("font-size: 22px;")
            a.setWordWrap(True)
            b = QLabel(tag)
            b.setObjectName("tag")
            b.setStyleSheet("font-size: 14px;")
            b.setWordWrap(True)
            p = QLabel(price)
            p.setObjectName("price")
            btn = QPushButton("Acquista con PayPal - %s" % price)
            btn.setObjectName("buy")
            btn.setCursor(Qt.CursorShape.PointingHandCursor)
            btn.clicked.connect(lambda _c, e=edition: buy(self, e))
            hl.addWidget(a)
            hl.addWidget(b, 1)
            hl.addWidget(p)
            hl.addWidget(btn)
            cards.addWidget(hero, 1)
        lay.addLayout(cards)
        row = QHBoxLayout()
        key = QPushButton("Attiva chiave (PRO o STUDY)")
        key.setObjectName("key")
        key.clicked.connect(self.activate)
        row.addStretch(1)
        row.addWidget(key, 1)
        row.addStretch(1)
        lay.addLayout(row)
        bottom = QHBoxLayout()
        self.hide_cb = QCheckBox("Non mostrare piu'")
        later = QPushButton("Piu' tardi")
        later.setObjectName("alt")
        later.clicked.connect(self.close_promo)
        bottom.addWidget(self.hide_cb)
        bottom.addStretch(1)
        bottom.addWidget(later)
        lay.addLayout(bottom)

    def close_promo(self):
        if self.hide_cb.isChecked():
            conf = c.load_pro()
            conf["promo_hidden"] = True
            c.save_pro(conf)
        self.reject()

    def activate(self):
        d = ActivateDialog(self)
        if d.exec() and d.role:
            self.accept()


class AdminPanel(QDialog):
    """Solo con la chiave amministratore: regola la Modalita' Gioco PRO e la licenza."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("EGGLASS OS PRO - Amministratore")
        self.setStyleSheet(PRO_STYLE)
        self.setMinimumWidth(560)
        self.conf = c.load_pro()
        lay = QVBoxLayout(self)
        h = QLabel("Pannello amministratore")
        h.setObjectName("h")
        lay.addWidget(h)
        self.scan_lbl = QLabel(scan_text(self.conf["scan"] or run_scan_and_save()))
        self.scan_lbl.setWordWrap(True)
        self.scan_lbl.setTextFormat(Qt.TextFormat.RichText)
        lay.addWidget(self.scan_lbl)
        form = QFormLayout()
        self.mode = QComboBox()
        for label, v in (("Automatica (solo se il PC e' datato)", "auto"),
                         ("Sempre attiva", "on"), ("Spenta", "off")):
            self.mode.addItem(label, v)
        self.mode.setCurrentIndex(max(0, self.mode.findData(self.conf["game_mode"])))
        form.addRow("Modalita' Gioco:", self.mode)
        self.cd = QSpinBox()
        self.cd.setRange(0, 60)
        self.cd.setSuffix(" s")
        self.cd.setValue(int(self.conf["countdown"]))
        form.addRow("Avviso prima di chiudere:", self.cd)
        self.ram = QSpinBox()
        self.ram.setRange(1, 64)
        self.ram.setSuffix(" GB")
        self.ram.setValue(int(self.conf["min_ram_gb"]))
        form.addRow("Datato se RAM sotto:", self.ram)
        self.thr = QSpinBox()
        self.thr.setRange(1, 64)
        self.thr.setValue(int(self.conf["min_threads"]))
        form.addRow("Datato se thread CPU sotto:", self.thr)
        self.keep = QLineEdit(", ".join(self.conf["keep"]))
        self.keep.setPlaceholderText("es. discord, obs")
        form.addRow("Non chiudere mai:", self.keep)
        lay.addLayout(form)
        self.msg = QLabel("")
        self.msg.setObjectName("s")
        lay.addWidget(self.msg)
        row = QHBoxLayout()
        rescan = QPushButton("Riscansiona PC")
        rescan.setObjectName("alt")
        rescan.clicked.connect(self.rescan)
        deact = QPushButton("Disattiva PRO")
        deact.setObjectName("alt")
        deact.clicked.connect(self.deactivate)
        save = QPushButton("Salva")
        save.clicked.connect(self.save)
        row.addWidget(rescan)
        row.addWidget(deact)
        row.addStretch(1)
        row.addWidget(save)
        lay.addLayout(row)

    def collect(self):
        self.conf["game_mode"] = self.mode.currentData()
        self.conf["countdown"] = self.cd.value()
        self.conf["min_ram_gb"] = self.ram.value()
        self.conf["min_threads"] = self.thr.value()
        self.conf["keep"] = [k.strip().lower() for k in self.keep.text().split(",") if k.strip()]

    def rescan(self):
        self.collect()
        self.conf["scan"] = c.scan_hardware(self.conf)
        c.save_pro(self.conf)
        self.scan_lbl.setText(scan_text(self.conf["scan"]))
        self.msg.setText("Scansione aggiornata.")

    def save(self):
        self.collect()
        self.conf["scan"] = c.scan_hardware(self.conf)
        c.save_pro(self.conf)
        self.scan_lbl.setText(scan_text(self.conf["scan"]))
        self.msg.setText("Salvato. Vale dal prossimo gioco avviato.")

    def deactivate(self):
        c.deactivate()
        self.msg.setText("PRO disattivato su questo PC.")
