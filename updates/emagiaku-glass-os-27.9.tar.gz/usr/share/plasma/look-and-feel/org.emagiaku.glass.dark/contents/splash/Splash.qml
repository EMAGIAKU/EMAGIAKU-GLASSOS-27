// EMAGIAKU GLASS OS 27 - schermata di avvio (KSplash) mostrata mentre si apre il desktop
import QtQuick

Rectangle {
    id: root
    color: "#120c1c"
    // KSplash aggiorna "stage" da 1 a 6 mentre il desktop si carica
    property int stage

    Rectangle {
        anchors.fill: parent
        gradient: Gradient {
            GradientStop { position: 0.0; color: "#1d1035" }
            GradientStop { position: 1.0; color: "#0b0712" }
        }
    }

    Column {
        anchors.centerIn: parent
        spacing: 14
        opacity: 0
        Component.onCompleted: opacity = 1
        Behavior on opacity { NumberAnimation { duration: 600 } }

        Rectangle {
            width: 96; height: 96; radius: 26
            anchors.horizontalCenter: parent.horizontalCenter
            gradient: Gradient {
                GradientStop { position: 0.0; color: "#a070ff" }
                GradientStop { position: 1.0; color: "#4b1fb0" }
            }
            Text {
                anchors.centerIn: parent
                text: "EG"
                color: "white"
                font.pixelSize: 44
                font.weight: Font.Black
            }
        }
        Text {
            anchors.horizontalCenter: parent.horizontalCenter
            text: "EMAGIAKU"
            color: "white"
            font.pixelSize: Math.max(34, root.width / 22)
            font.weight: Font.Black
            font.letterSpacing: 4
        }
        Text {
            anchors.horizontalCenter: parent.horizontalCenter
            text: "GLASS OS 27"
            color: "#c9a4ff"
            font.pixelSize: Math.max(18, root.width / 56)
            font.weight: Font.DemiBold
            font.letterSpacing: 8
        }
        Rectangle {
            width: 280; height: 4; radius: 2
            anchors.horizontalCenter: parent.horizontalCenter
            color: "#2c1f48"
            Rectangle {
                height: parent.height; radius: 2
                width: parent.width * Math.min(1, Math.max(0.05, root.stage / 6))
                color: "#8a4fff"
                Behavior on width { NumberAnimation { duration: 400; easing.type: Easing.OutCubic } }
            }
        }
    }

    Text {
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.bottom: parent.bottom
        anchors.bottomMargin: Math.max(24, root.height / 22)
        text: "Developed by EMAGIAKU.TEAM  ·  Based on Arch Linux"
        color: "#968caa"
        font.pixelSize: Math.max(12, root.width / 110)
        font.letterSpacing: 1
    }
}
