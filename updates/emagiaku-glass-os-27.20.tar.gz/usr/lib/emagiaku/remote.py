"""EG Remoto - usa il PC da telefono, tablet o visore (web app EG Remoto).

Come funziona
  - Il PC si registra nella tabella "devices" dell'Account EMAGIAKU (visibile SOLO al proprietario).
  - La web app scrive una richiesta nella tabella "signals"; il PC prepara la connessione WebRTC
    (schermo in H.264 + canale per mouse/tastiera) e scrive l'offerta; la web app risponde.
  - Video e comandi viaggiano cifrati (DTLS-SRTP) direttamente tra PC e telefono (STUN per attraversare
    il router). Accetta solo richieste create dallo stesso Account EMAGIAKU.
Servono: gst-plugins-good (RTP); su X11 ximagesrc + python-xlib (XTEST); su Wayland (Plasma 6.8+)
gst-plugin-pipewire + il portale RemoteDesktop/ScreenCast di KDE (la prima volta il PC chiede il permesso).
"""
import json
import os
import re
import socket
import subprocess
import threading
import time
import urllib.parse

import egcloud as C

DB = "/tablesdb/emagiaku/tables"
DEVICES = DB + "/devices/rows"
SIGNALS = DB + "/signals/rows"
STUN = "stun://stun.l.google.com:19302"
# X11: ximagesrc + XTEST (python-xlib). Wayland (Plasma 6.8+): pipewiresrc + portale KDE.
PACKAGES = ["gst-plugins-good", "python-xlib", "gst-plugin-pipewire", "xdg-desktop-portal-kde"]
CONF = os.path.join(os.path.expanduser("~"), ".config", "emagiaku", "remote.json")


# --------------------------------------------------------------- stato
def load_conf():
    try:
        with open(CONF, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def save_conf(conf):
    os.makedirs(os.path.dirname(CONF), exist_ok=True)
    fd = os.open(CONF, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump(conf, f)


def components_ok():
    """Componenti di sistema per lo streaming e i comandi."""
    try:
        import gi
        gi.require_version("Gst", "1.0")
        from gi.repository import Gst
        Gst.init(None)
        need = ["webrtcbin", "rtph264pay", "openh264enc", "videoconvert", "videoscale", "videorate"]
        need.append("pipewiresrc" if is_wayland() else "ximagesrc")
        if not all(Gst.ElementFactory.find(e) for e in need):
            return False
        if not is_wayland():
            import Xlib.display  # noqa: F401
        return True
    except Exception:
        return False


def install_command():
    import logic as L
    return L.root_prefix() + ["pacman", "-Syu", "--noconfirm", "--needed"] + PACKAGES


def _uid():
    st = C.load()
    if not st.get("session"):
        raise C.CloudError("Accedi prima all'Account EMAGIAKU.")
    uid = st.get("uid") or (C.status() or {}).get("uid", "")
    if not uid:
        raise C.CloudError("Account EMAGIAKU non pronto: riapri la pagina Account.")
    return uid


def _perms(uid):
    return ['read("user:%s")' % uid, 'update("user:%s")' % uid, 'delete("user:%s")' % uid]


def _query(method, attr, values):
    return "queries[]=" + urllib.parse.quote(json.dumps({"method": method, "attribute": attr, "values": values}))


# ------------------------------------------------------- dispositivo
def register():
    """Crea o aggiorna la voce di questo PC. Restituisce l'ID del dispositivo."""
    uid = _uid()
    conf = load_conf()
    did = conf.get("device_id")
    data = {"name": conf.get("name") or socket.gethostname()[:60], "platform": "EMAGIAKU GLASS OS",
            "version": _os_version(), "seen": int(time.time()), "status": "online"}
    if did:
        try:
            C._call("PATCH", "%s/%s" % (DEVICES, did), {"data": data})
            return did
        except C.CloudError:
            did = None                          # cancellato dall'utente o account cambiato: lo ricreo
    import secrets
    did = secrets.token_hex(16)
    C._call("POST", DEVICES, {"rowId": did, "data": data, "permissions": _perms(uid)})
    conf["device_id"] = did
    conf["uid"] = uid
    save_conf(conf)
    return did


def set_status(status):
    did = load_conf().get("device_id")
    if not did:
        return
    try:
        C._call("PATCH", "%s/%s" % (DEVICES, did), {"data": {"status": status, "seen": int(time.time())}})
    except C.CloudError:
        pass


def unregister():
    conf = load_conf()
    did = conf.pop("device_id", None)
    save_conf(conf)
    if did:
        try:
            C._call("DELETE", "%s/%s" % (DEVICES, did))
        except C.CloudError:
            pass


def _os_version():
    try:
        with open("/etc/emagiaku/version", encoding="utf-8") as f:
            return f.read().strip()[:16]
    except OSError:
        return ""


# ------------------------------------------------------- segnalazione
def pending_requests(did, uid):
    """Richieste di collegamento per questo PC create dal proprietario (ultimi 2 minuti)."""
    q = "&".join([_query("equal", "device", [did]), _query("equal", "kind", ["request"])])
    res = C._call("GET", "%s?%s" % (SIGNALS, q))
    out = []
    for r in res.get("rows", []):
        perms = r.get("$permissions", [])
        if 'read("user:%s")' % uid not in perms or any('"any"' in p or '"users"' in p or '"guests"' in p for p in perms):
            continue                             # non creata dal proprietario: la ignoro
        opts = {}
        try:
            d = json.loads(r.get("data") or "{}")
            age = time.time() - int(d.get("t", 0))
            # preferenze del telefono (dalla 27.18): formato video e larghezza massima
            if d.get("codec") in ("h264", "vp8"):
                opts["codec"] = d["codec"]
            if isinstance(d.get("maxw"), int):
                opts["max_width"] = max(640, min(1920, d["maxw"]))
        except (ValueError, TypeError, AttributeError):
            age = 999
        out.append((r["$id"], r.get("session", ""), age, opts))
    return out


def put_signal(did, uid, session, kind, data):
    import secrets
    C._call("POST", SIGNALS, {"rowId": secrets.token_hex(16),
                              "data": {"device": did, "session": session, "kind": kind,
                                       "data": json.dumps(data) if not isinstance(data, str) else data},
                              "permissions": _perms(uid)})


def get_signal(did, session, kind):
    q = "&".join([_query("equal", "device", [did]), _query("equal", "session", [session]),
                  _query("equal", "kind", [kind])])
    rows = C._call("GET", "%s?%s" % (SIGNALS, q)).get("rows", [])
    return rows[0] if rows else None


def delete_row(rid):
    try:
        C._call("DELETE", "%s/%s" % (SIGNALS, rid))
    except C.CloudError:
        pass


def cleanup_session(did, session):
    q = "&".join([_query("equal", "device", [did]), _query("equal", "session", [session])])
    try:
        for r in C._call("GET", "%s?%s" % (SIGNALS, q)).get("rows", []):
            delete_row(r["$id"])
    except C.CloudError:
        pass


# ------------------------------------------------------ mouse e tastiera
# keysym X11 (gli stessi numeri valgono per XTEST e per il portale Wayland)
KEYSYMS = {"Enter": 0xff0d, "Backspace": 0xff08, "Tab": 0xff09, "Escape": 0xff1b, "Delete": 0xffff,
           "ArrowLeft": 0xff51, "ArrowUp": 0xff52, "ArrowRight": 0xff53, "ArrowDown": 0xff54, "Home": 0xff50,
           "End": 0xff57, "PageUp": 0xff55, "PageDown": 0xff56, "Control": 0xffe3, "Shift": 0xffe1, "Alt": 0xffe9,
           "Meta": 0xffeb, "Super": 0xffeb, " ": 0x20, "\n": 0xff0d}
KEYSYMS.update({"F%d" % i: 0xffbd + i for i in range(1, 13)})


def keysym_for(name):
    if name in KEYSYMS:
        return KEYSYMS[name]
    if len(name) == 1:
        cp = ord(name)
        return cp if 0x20 <= cp < 0x100 else 0x01000000 | cp
    return 0


class BaseInput:
    """Comandi JSON della web app -> mouse e tastiera. I sottotipi fanno il lavoro vero."""
    def _move(self, nx, ny): raise NotImplementedError
    def _button(self, b, down): raise NotImplementedError       # 1 sinistro, 2 centrale, 3 destro
    def _key(self, keysym, down): raise NotImplementedError

    def _wheel(self, steps):
        b = 5 if steps > 0 else 4
        for _ in range(abs(steps)):
            self._button(b, True)
            self._button(b, False)

    def _flush(self):
        pass

    def handle(self, msg):
        try:
            m = json.loads(msg)
        except ValueError:
            return
        t = m.get("t")
        try:
            if t == "move":
                self._move(m["x"], m["y"])
            elif t in ("down", "up"):
                if "x" in m:
                    self._move(m["x"], m["y"])
                self._button(m.get("b", 1) if m.get("b") in (1, 2, 3) else 1, t == "down")
            elif t == "click":
                if "x" in m:
                    self._move(m["x"], m["y"])
                b = m.get("b", 1) if m.get("b") in (1, 2, 3) else 1
                self._button(b, True)
                self._button(b, False)
            elif t == "wheel":
                steps = max(-20, min(20, int(m.get("dy", 0))))
                if steps:
                    self._wheel(steps)
            elif t == "text":
                for ch in str(m.get("s", ""))[:500]:
                    ks = keysym_for(ch)
                    if ks:
                        self._key(ks, True)
                        self._key(ks, False)
            elif t == "key":
                mods = [keysym_for(x) for x in m.get("mods", []) if x in ("Control", "Shift", "Alt", "Meta")]
                ks = keysym_for(str(m.get("k", "")))
                if ks:
                    for md in mods:
                        self._key(md, True)
                    self._key(ks, True)
                    self._key(ks, False)
                    for md in reversed(mods):
                        self._key(md, False)
            self._flush()
        except Exception:
            pass


class Input(BaseInput):
    """Sessione X11: estensione XTEST."""

    def __init__(self):
        from Xlib import X, display
        from Xlib.ext import xtest
        self.X, self.xtest = X, xtest
        self.d = display.Display()
        g = self.d.screen().root.get_geometry()
        self.w, self.h = g.width, g.height
        self.spare = None

    def _move(self, nx, ny):
        x = int(max(0.0, min(1.0, float(nx))) * (self.w - 1))
        y = int(max(0.0, min(1.0, float(ny))) * (self.h - 1))
        self.xtest.fake_input(self.d, self.X.MotionNotify, x=x, y=y)

    def _button(self, b, down):
        self.xtest.fake_input(self.d, self.X.ButtonPress if down else self.X.ButtonRelease, int(b))

    def _keycode(self, keysym):
        kc = self.d.keysym_to_keycode(keysym)
        if kc:
            return kc
        # carattere che non c'e' sulla tastiera: uso per un attimo un tasto libero
        if self.spare is None:
            mn, mx = self.d.display.info.min_keycode, self.d.display.info.max_keycode
            mapping = self.d.get_keyboard_mapping(mn, mx - mn + 1)
            self.spare = next((mn + i for i in range(len(mapping) - 1, -1, -1) if not any(mapping[i])), mx)
        self.d.change_keyboard_mapping(self.spare, [(keysym,) * 4])
        self.d.sync()
        return self.spare

    def _key(self, keysym, down):
        self.xtest.fake_input(self.d, self.X.KeyPress if down else self.X.KeyRelease, self._keycode(keysym))

    def _flush(self):
        self.d.sync()


def is_wayland():
    return os.environ.get("XDG_SESSION_TYPE") == "wayland" or bool(os.environ.get("WAYLAND_DISPLAY"))


class Portal:
    """Sessione Wayland (Plasma 6.8+): schermo e comandi dal portale RemoteDesktop/ScreenCast di KDE.
    La prima volta il PC puo' chiedere il permesso; poi lo ricorda (restore_token salvato in remote.json)."""
    BUS = "org.freedesktop.portal.Desktop"
    PATH = "/org/freedesktop/portal/desktop"
    RD = "org.freedesktop.portal.RemoteDesktop"
    SC = "org.freedesktop.portal.ScreenCast"

    def __init__(self, on_ready, on_error):
        from gi.repository import Gio, GLib
        self.Gio, self.GLib = Gio, GLib
        self.on_ready, self.on_error = on_ready, on_error
        self.bus = Gio.bus_get_sync(Gio.BusType.SESSION, None)
        self.sender = self.bus.get_unique_name()[1:].replace(".", "_")
        self.handle = None
        self.node = None
        self.fd = -1
        self.size = (1920, 1080)
        self.closed = False
        self._request(self.RD, "CreateSession", lambda tok: GLib.Variant(
            "(a{sv})", ({"handle_token": GLib.Variant("s", tok),
                         "session_handle_token": GLib.Variant("s", "egs" + tok)},)), self._created)

    # una chiamata del portale: la risposta arriva con il segnale Response sul percorso della richiesta
    def _request(self, iface, method, make_args, done):
        import secrets
        tok = "eg" + secrets.token_hex(6)
        path = "%s/request/%s/%s" % (self.PATH, self.sender, tok)
        sub = [0]

        def on_response(_c, _s, _p, _i, _n, params):
            self.bus.signal_unsubscribe(sub[0])
            code, results = params.unpack()
            if self.closed:
                return
            if code != 0:
                self.on_error("permesso negato sul PC" if code == 1 else "il portale ha risposto %d" % code)
                return
            try:
                done(results)
            except Exception as e:
                self.on_error("portale: %s" % e)

        sub[0] = self.bus.signal_subscribe(self.BUS, "org.freedesktop.portal.Request", "Response", path, None,
                                           self.Gio.DBusSignalFlags.NONE, on_response)

        def called(bus, res):
            try:
                bus.call_finish(res)
            except Exception as e:
                self.bus.signal_unsubscribe(sub[0])
                self.on_error("portale non disponibile: %s" % e)

        self.bus.call(self.BUS, self.PATH, iface, method, make_args(tok), None,
                      self.Gio.DBusCallFlags.NONE, 120000, None, called)

    def _created(self, results):
        V = self.GLib.Variant
        self.handle = results["session_handle"]
        opts = {"types": V("u", 3), "persist_mode": V("u", 2)}           # tastiera + puntatore, ricorda sempre
        token = load_conf().get("portal_token")
        if token:
            opts["restore_token"] = V("s", token)
        self._request(self.RD, "SelectDevices", lambda tok: V(
            "(oa{sv})", (self.handle, dict(opts, handle_token=V("s", tok)))), self._devices)

    def _devices(self, _results):
        V = self.GLib.Variant
        self._request(self.SC, "SelectSources", lambda tok: V(
            "(oa{sv})", (self.handle, {"handle_token": V("s", tok), "types": V("u", 1), "multiple": V("b", False),
                                       "cursor_mode": V("u", 2)})), self._sources)

    def _sources(self, _results):
        V = self.GLib.Variant
        self._request(self.RD, "Start", lambda tok: V(
            "(osa{sv})", (self.handle, "", {"handle_token": V("s", tok)})), self._started)

    def _started(self, results):
        streams = results.get("streams") or []
        if not streams:
            raise RuntimeError("nessuno schermo condiviso")
        self.node, props = streams[0]
        if "size" in props:
            self.size = tuple(props["size"])
        if results.get("restore_token"):
            conf = load_conf()
            conf["portal_token"] = results["restore_token"]
            save_conf(conf)
        res, fds = self.bus.call_with_unix_fd_list_sync(
            self.BUS, self.PATH, self.SC, "OpenPipeWireRemote",
            self.GLib.Variant("(oa{sv})", (self.handle, {})), self.GLib.VariantType("(h)"),
            self.Gio.DBusCallFlags.NONE, 10000, None, None)
        self.fd = fds.get(res.unpack()[0])
        self.on_ready(self)

    def notify(self, method, sig, *args):
        if self.closed or not self.handle:
            return
        V = self.GLib.Variant
        self.bus.call(self.BUS, self.PATH, self.RD, method, V(sig, (self.handle, {}) + args), None,
                      self.Gio.DBusCallFlags.NONE, -1, None, None)

    def close(self):
        if self.closed:
            return
        self.closed = True
        if self.handle:
            try:
                self.bus.call(self.BUS, self.handle, "org.freedesktop.portal.Session", "Close", None, None,
                              self.Gio.DBusCallFlags.NONE, -1, None, None)
            except Exception:
                pass
        if self.fd >= 0:
            try:
                os.close(self.fd)
            except OSError:
                pass


class PortalInput(BaseInput):
    """Sessione Wayland: comandi tramite il portale RemoteDesktop (pulsanti evdev, keysym X11)."""
    BUTTONS = {1: 0x110, 2: 0x112, 3: 0x111}                        # BTN_LEFT, BTN_MIDDLE, BTN_RIGHT

    def __init__(self, portal):
        self.p = portal

    def _move(self, nx, ny):
        w, h = self.p.size
        x = max(0.0, min(1.0, float(nx))) * (w - 1)
        y = max(0.0, min(1.0, float(ny))) * (h - 1)
        self.p.notify("NotifyPointerMotionAbsolute", "(oa{sv}udd)", int(self.p.node), float(x), float(y))

    def _button(self, b, down):
        self.p.notify("NotifyPointerButton", "(oa{sv}iu)", self.BUTTONS.get(int(b), 0x110), 1 if down else 0)

    def _wheel(self, steps):
        self.p.notify("NotifyPointerAxisDiscrete", "(oa{sv}ui)", 0, int(steps))

    def _key(self, keysym, down):
        self.p.notify("NotifyKeyboardKeysym", "(oa{sv}iu)", int(keysym), 1 if down else 0)


# ------------------------------------------------------- sessione video
def _fix_sdp(sdp):
    """openh264 dichiara 42c0xx: Safari (iPhone/iPad) vuole il Constrained Baseline scritto come 42e01f.
    E' lo stesso flusso (Constrained Baseline), cambia solo come viene annunciato."""
    return re.sub(r"profile-level-id=42[0-9a-fA-F]{4}", "profile-level-id=42e01f", sdp)


class Session:
    """Una connessione: schermo -> H.264 -> WebRTC, canale "input" per i comandi."""

    def __init__(self, did, uid, session, on_end, max_width=1920, fps=30, kbps=6000, codec="h264"):
        import gi
        gi.require_version("Gst", "1.0")
        gi.require_version("GstWebRTC", "1.0")
        gi.require_version("GstSdp", "1.0")
        from gi.repository import Gst, GstWebRTC, GstSdp
        Gst.init(None)
        self.Gst, self.GstWebRTC, self.GstSdp = Gst, GstWebRTC, GstSdp
        self.did, self.uid, self.session, self.on_end = did, uid, session, on_end
        self.input = None
        self.ended = False
        self.connected = False
        self.portal = None
        self.pipe = None
        self.opts = (max_width, fps, kbps, codec)
        if is_wayland():
            # Plasma Wayland: prima il portale (schermo + comandi), poi la pipeline
            self.portal = Portal(self._portal_ready, lambda why: self.stop("Wayland: %s" % why))
            return
        self._build("ximagesrc use-damage=false show-pointer=true", self._screen_size())
        try:
            self.input = Input()
        except Exception:
            self.input = None

    def _portal_ready(self, portal):
        if self.ended:
            portal.close()
            return
        self._build("pipewiresrc fd=%d path=%s do-timestamp=true keepalive-time=500 always-copy=true"
                    % (portal.fd, portal.node), portal.size)
        self.input = PortalInput(portal)

    def _build(self, source, size):
        Gst = self.Gst
        max_width, fps, kbps, codec = self.opts
        w, h = size
        if w > max_width:
            h, w = int(h * max_width / w) // 2 * 2, max_width
        w, h = w // 2 * 2, h // 2 * 2
        if codec == "vp8" and Gst.ElementFactory.find("vp8enc"):
            # VP8: lo decodificano tutti i browser (anche iPhone/iPad) senza dipendere dall'hardware
            enc = ("vp8enc deadline=1 cpu-used=8 end-usage=cbr target-bitrate=%d keyframe-max-dist=60 threads=4 "
                   "error-resilient=partitions lag-in-frames=0 ! rtpvp8pay picture-id-mode=15-bit ! "
                   "application/x-rtp,media=video,encoding-name=VP8,payload=96,clock-rate=90000" % (kbps * 1000))
        else:
            # H.264 Constrained Baseline dichiarato come 42e01f: il profilo che Safari (iPhone) accetta sempre
            # (il profilo viene sistemato nell'offerta, vedi _fix_sdp)
            enc = ("openh264enc bitrate=%d complexity=low usage-type=screen gop-size=60 rate-control=bitrate ! "
                   "h264parse ! rtph264pay config-interval=-1 aggregate-mode=zero-latency ! "
                   "application/x-rtp,media=video,encoding-name=H264,payload=102,clock-rate=90000" % (kbps * 1000))
        self.codec = "vp8" if enc.startswith("vp8") else "h264"
        pipe = ("%s ! videorate ! video/x-raw,framerate=%d/1 ! queue leaky=downstream "
                "max-size-buffers=2 ! videoscale ! videoconvert ! video/x-raw,format=I420,width=%d,height=%d ! "
                "%s ! webrtcbin name=webrtc bundle-policy=max-bundle stun-server=%s"
                % (source, fps, w, h, enc, STUN))
        self.pipe = Gst.parse_launch(pipe)
        self.webrtc = self.pipe.get_by_name("webrtc")
        self.webrtc.connect("on-negotiation-needed", self._negotiate)
        self.webrtc.connect("notify::ice-gathering-state", self._gathering)
        self.webrtc.connect("notify::connection-state", self._conn_state)
        bus = self.pipe.get_bus()
        bus.add_signal_watch()
        bus.connect("message::error", lambda _b, m: self.stop("errore: %s" % m.parse_error()[0].message))
        self.offer_sent = False
        self.pipe.set_state(Gst.State.PLAYING)
        self.channel = self.webrtc.emit("create-data-channel", "input", None)
        if self.channel:
            self.channel.connect("on-message-string", lambda _c, s: self.input and self.input.handle(s))
            self.channel.connect("on-close", lambda _c: self.stop("il telefono si e' scollegato"))

    @staticmethod
    def _screen_size():
        try:
            out = subprocess.run(["xrandr", "--query"], capture_output=True, text=True, timeout=5).stdout
            m = re.search(r"current (\d+) x (\d+)", out)
            if m:
                return int(m.group(1)), int(m.group(2))
        except (OSError, subprocess.SubprocessError):
            pass
        return 1920, 1080

    def _negotiate(self, _el):
        # l'offerta si crea nel thread principale: leggerla dentro la callback di webrtcbin fa crashare PyGObject
        from gi.repository import GLib
        GLib.idle_add(self._make_offer)

    def _make_offer(self):
        if self.ended:
            return False
        promise = self.Gst.Promise.new()
        self.webrtc.emit("create-offer", None, promise)
        promise.wait()
        reply = promise.get_reply()
        offer = reply.get_value("offer") if reply else None
        if offer is None:
            self.stop("offerta non creata")
            return False
        self.webrtc.emit("set-local-description", offer, self.Gst.Promise.new())
        return False

    def _gathering(self, *_a):
        # offerta completa (con tutti i candidati) quando la raccolta ICE e' finita: un solo messaggio
        if self.offer_sent or self.webrtc.get_property("ice-gathering-state") != self.GstWebRTC.WebRTCICEGatheringState.COMPLETE:
            return
        self.offer_sent = True
        sdp = _fix_sdp(self.webrtc.get_property("local-description").sdp.as_text())
        threading.Thread(target=self._exchange, args=(sdp,), daemon=True).start()

    def _exchange(self, sdp):
        from gi.repository import GLib
        try:
            put_signal(self.did, self.uid, self.session, "offer", {"type": "offer", "sdp": sdp})
            for _ in range(90):                 # la web app ha 90 secondi per rispondere
                if self.ended:
                    return
                row = get_signal(self.did, self.session, "answer")
                if row:
                    ans = json.loads(row["data"])
                    GLib.idle_add(self._set_answer, ans["sdp"])
                    return
                time.sleep(1)
            GLib.idle_add(self.stop, "nessuna risposta dal telefono")
        except Exception as e:
            GLib.idle_add(self.stop, "errore: %s" % e)

    def _set_answer(self, sdp_text):
        res, msg = self.GstSdp.SDPMessage.new_from_text(sdp_text)
        answer = self.GstWebRTC.WebRTCSessionDescription.new(self.GstWebRTC.WebRTCSDPType.ANSWER, msg)
        self.webrtc.emit("set-remote-description", answer, self.Gst.Promise.new())
        return False

    def _conn_state(self, *_a):
        st = self.webrtc.get_property("connection-state")
        S = self.GstWebRTC.WebRTCPeerConnectionState
        if st == S.CONNECTED and not self.connected:
            self.connected = True
            set_status("busy")
            _notify_connected(self)
        elif st in (S.FAILED, S.CLOSED) or (st == S.DISCONNECTED and self.connected):
            self.stop("connessione chiusa" if st != S.FAILED else
                      "connessione non riuscita (la rete potrebbe bloccare il collegamento diretto)")

    def stop(self, reason=""):
        if self.ended:
            return False
        self.ended = True
        try:
            if self.pipe:
                self.pipe.set_state(self.Gst.State.NULL)
        except Exception:
            pass
        if self.portal:
            self.portal.close()
        threading.Thread(target=cleanup_session, args=(self.did, self.session), daemon=True).start()
        set_status("online")
        self.on_end(reason)
        return False


def _notify_connected(sess):
    """Avviso sul PC con il pulsante Disconnetti (sempre visibile chi controlla il PC)."""
    def run():
        try:
            r = subprocess.run(["notify-send", "-a", "EG Remoto", "-i", "emagiaku-remote", "-u", "critical",
                                "-A", "stop=Disconnetti", "--wait", "Connessione remota attiva",
                                "Qualcuno con il tuo Account EMAGIAKU sta usando questo PC."],
                               capture_output=True, text=True)
            if r.stdout.strip() == "stop":
                from gi.repository import GLib
                GLib.idle_add(sess.stop, "disconnesso dal PC")
        except OSError:
            pass
    threading.Thread(target=run, daemon=True).start()


# ------------------------------------------------------------ agente
def agent():
    """In sottofondo: tiene il PC visibile nella web app e accetta le connessioni del proprietario."""
    from gi.repository import GLib
    state = {"session": None, "did": None, "uid": None, "last_beat": 0}
    loop = GLib.MainLoop()

    def end(reason):
        state["session"] = None
        print("EG Remoto: sessione finita (%s)" % reason, flush=True)

    def tick():
        if state["session"] is not None:
            return True
        if not load_conf().get("enabled"):
            loop.quit()
            return False
        threading.Thread(target=check, daemon=True).start()
        return True

    def check():
        try:
            if not state["did"] or time.time() - state["last_beat"] > 120:
                state["uid"] = _uid()
                state["did"] = register()
                state["last_beat"] = time.time()
            for rid, session, age, opts in pending_requests(state["did"], state["uid"]):
                delete_row(rid)
                if age > 120 or not re.fullmatch(r"[a-f0-9]{16,64}", session or ""):
                    continue
                GLib.idle_add(start, session, opts)
                break
        except Exception as e:
            print("EG Remoto: %s" % e, flush=True)

    def start(session, opts):
        if state["session"] is None:
            try:
                state["session"] = Session(state["did"], state["uid"], session, end, **opts)
            except Exception as e:
                print("EG Remoto: avvio non riuscito: %s" % e, flush=True)
        return False

    GLib.timeout_add_seconds(3, tick)
    try:
        loop.run()
    finally:
        set_status("offline")
