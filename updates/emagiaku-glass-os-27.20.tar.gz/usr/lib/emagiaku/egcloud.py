"""Account EMAGIAKU - registrazione, verifica email, accesso e verifica in due passaggi (Appwrite Cloud).

Servizio: Appwrite Cloud, progetto "EMAGIAKU GLASS OS", regione Francoforte (UE).
Nel sistema c'e' solo l'ID PUBBLICO del progetto (come in ogni app). Sul PC NON si salva la password:
solo il "gettone di sessione" in ~/.config/emagiaku/account.json (leggibile solo dall'utente).
La verifica in due passaggi (app di autenticazione / codici di recupero) e' controllata dal server:
con la sola password l'account resta bloccato finche' non si inserisce il codice.
"""
import json
import os
import re
import time
import urllib.error
import urllib.parse
import urllib.request

ENDPOINT = "https://fra.cloud.appwrite.io/v1"
PROJECT = "6af5ebe90008bba8da64"                 # ID pubblico del progetto
COOKIE = "a_session_" + PROJECT
PRIVACY_URL = "https://github.com/EMAGIAKU/EMAGIAKU-GLASSOS-27/blob/main/PRIVACY.md"
# pagine EMAGIAKU (GitHub Pages) aperte dai link nelle mail e dal QR: fanno tutto da sole
SITE = "https://emagiaku.github.io/EMAGIAKU-GLASSOS-27/"
VERIFY_PAGE = SITE + "verifica.html"
RESET_PAGE = SITE + "password.html"
PHONE_PAGE = SITE + "accedi.html"
LINK_PAGE = VERIFY_PAGE           # compatibilita'
QR_TABLE = "/tablesdb/emagiaku/tables/qrlogin/rows"
STORE = os.path.join(os.path.expanduser("~"), ".config", "emagiaku", "account.json")

ERRORS = {   # tipi di errore di Appwrite -> messaggi in italiano
    "user_already_exists": "Esiste gia' un account con questa email: accedi.",
    "user_email_already_exists": "Questa email e' gia' usata da un altro account.",
    "user_invalid_credentials": "Email o password sbagliate.",
    "user_password_mismatch": "La password attuale non e' giusta.",
    "user_blocked": "Questo account e' stato bloccato.",
    "user_not_found": "Account non trovato.",
    "user_unauthorized": "Accesso scaduto: accedi di nuovo.",
    "general_unauthorized_scope": "Accesso scaduto: accedi di nuovo.",
    "user_session_not_found": "Accesso scaduto: accedi di nuovo.",
    "user_invalid_token": "Codice sbagliato o scaduto: riprova (con l'app usa il codice nuovo).",
    "user_more_factors_required": "Serve il codice della verifica in due passaggi.",
    "user_password_recently_used": "Hai gia' usato questa password di recente: scegline un'altra.",
    "user_password_personal_data": "La password non deve contenere nome o email.",
    "password_recently_used": "Hai gia' usato questa password di recente: scegline un'altra.",
    "password_personal_data": "La password non deve contenere nome o email.",
    "user_password_pwned": "Questa password e' comparsa in un furto di dati: scegline un'altra.",
    "password_pwned": "Questa password e' comparsa in un furto di dati: scegline un'altra.",
    "general_rate_limit_exceeded": "Troppi tentativi: riprova tra qualche minuto.",
    "user_count_exceeded": "Non e' possibile creare altri account ora.",
    "user_challenge_required": "Serve il codice della verifica in due passaggi.",
    "user_authenticator_already_verified": "La verifica in due passaggi e' gia' attiva.",
    "user_recovery_codes_already_exists": "I codici di recupero esistono gia'.",
    "user_more_factors_required_already": "Serve il codice della verifica in due passaggi.",
    "general_argument_invalid": "Dati non validi.",
}

COMMON_PASSWORDS = {
    "12345678", "123456789", "1234567890", "password", "password1", "password123", "qwertyuiop", "qwerty123",
    "11111111", "00000000", "abcdefgh", "abcd1234", "iloveyou", "12341234", "87654321", "asdfghjk",
    "ciao1234", "ciaociao", "passw0rd", "juventus", "napoli123", "inter123", "milan123", "emagiaku", "emagiaku1",
    "qwerty12", "1q2w3e4r", "zxcvbnm1", "password!", "amore123", "forzanapoli",
}


class CloudError(Exception):
    pass


class MfaRequired(CloudError):
    """Password giusta, ma serve il codice della verifica in due passaggi."""


def password_problem(pw, email=""):
    """Perche' la password non va bene ('' se va bene). Il server fa anche i suoi controlli."""
    pw = pw or ""
    if len(pw) < 8:
        return "La password deve avere almeno 8 caratteri."
    if not any(ch.isalpha() for ch in pw) or not any(ch.isdigit() for ch in pw):
        return "La password deve avere sia lettere sia numeri."
    if pw.lower() in COMMON_PASSWORDS or len(set(pw)) <= 3:
        return "Password troppo facile da indovinare: scegline un'altra."
    user = (email or "").split("@")[0].lower()
    if len(user) >= 4 and user in pw.lower():
        return "La password non deve contenere il tuo indirizzo email."
    return ""


# --------------------------------------------------------------- stato
def load():
    try:
        with open(STORE, encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, ValueError):
        return {}
    if data.get("refreshToken") and not data.get("session"):
        return {"old_service": True}            # account del vecchio servizio (fino alla 27.9)
    return data


def save(data):
    os.makedirs(os.path.dirname(STORE), exist_ok=True)
    fd = os.open(STORE, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=1)


def forget():
    try:
        os.remove(STORE)
    except OSError:
        pass


# ------------------------------------------------------------ chiamate
def _call(method, path, data=None, session=True, raw=False):
    headers = {"Content-Type": "application/json", "X-Appwrite-Project": PROJECT,
               "X-Appwrite-Response-Format": "1.6.0", "X-Appwrite-Locale": "it",
               "User-Agent": "EMAGIAKU-GLASS-OS"}
    st = load() if session else {}
    if st.get("session"):
        headers["Cookie"] = "%s=%s" % (COOKIE, st["session"])
    body = json.dumps(data).encode() if data is not None else None
    req = urllib.request.Request(ENDPOINT + path, data=body, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            new = None
            for c in r.headers.get_all("Set-Cookie") or []:
                k, _s, rest = c.partition("=")
                if k.strip() == COOKIE:
                    new = rest.split(";", 1)[0]
            fb = r.headers.get("X-Fallback-Cookies")
            if fb and not new:
                try:
                    new = json.loads(fb).get(COOKIE)
                except ValueError:
                    pass
            content = r.read()
            if raw:
                return content
            res = json.loads(content.decode() or "{}") if content else {}
            if new:
                res["_session"] = new
            return res
    except urllib.error.HTTPError as e:
        try:
            b = json.loads(e.read().decode() or "{}")
        except ValueError:
            b = {}
        typ = b.get("type", "")
        msg = ERRORS.get(typ)
        if typ == "user_more_factors_required":
            raise MfaRequired(msg)
        if not msg and "password" in typ and "history" in typ:
            msg = ERRORS["password_recently_used"]
        if not msg and ("pwned" in typ or "breach" in typ):
            msg = ERRORS["password_pwned"]
        raise CloudError(msg or "Errore del servizio account (%s)." % (b.get("message") or e.code))
    except (urllib.error.URLError, OSError):
        raise CloudError("Nessuna connessione: per l'account EMAGIAKU serve internet.")


def _remember(res, email):
    st = {"email": email.strip(), "uid": res.get("userId", ""), "session": res.get("_session", "")}
    if not st["session"]:
        raise CloudError("Il servizio non ha restituito la sessione: riprova.")
    save(st)
    return st


def link_params(text):
    """Dal link della mail ricava (userId, secret)."""
    text = (text or "").strip()
    q = urllib.parse.urlparse(text).query or (text.split("?", 1)[1] if "?" in text else "")
    p = urllib.parse.parse_qs(q)
    uid, sec = (p.get("userId") or [""])[0], (p.get("secret") or [""])[0]
    if not uid or not sec:
        raise CloudError("Incolla il link completo che trovi nella mail.")
    return uid, sec


# ---------------------------------------------------------- accesso
def sign_up(email, password):
    """Crea l'account, entra e manda la mail di verifica."""
    bad = password_problem(password, email)
    if bad:
        raise CloudError(bad)
    _call("POST", "/account", {"userId": "unique()", "email": email.strip(), "password": password}, session=False)
    sign_in(email, password)
    send_verification()
    return True


def sign_in(email, password):
    """Entra con email e password. Se c'e' la verifica in due passaggi solleva MfaRequired:
    la sessione e' salvata ma resta bloccata finche' non si chiama complete_mfa()."""
    res = _call("POST", "/account/sessions/email", {"email": email.strip(), "password": password}, session=False)
    _remember(res, email)
    return status()


def email_code_send(email):
    """Accesso senza password: manda un codice di 6 cifre via email. Restituisce l'ID utente."""
    res = _call("POST", "/account/tokens/email", {"userId": "unique()", "email": email.strip()}, session=False)
    return res.get("userId", "")


def email_code_login(email, user_id, code):
    code = re.sub(r"\D", "", code or "")
    if len(code) != 6:
        raise CloudError("Il codice ha 6 cifre.")
    res = _call("POST", "/account/sessions/token", {"userId": user_id, "secret": code}, session=False)
    _remember(res, email)
    return status()


def complete_mfa(code):
    """Secondo passaggio: codice dell'app (6 cifre) oppure un codice di recupero."""
    code = (code or "").strip().replace(" ", "")
    factor = "totp" if re.fullmatch(r"\d{6}", code) else "recoveryCode"
    ch = _call("POST", "/account/mfa/challenge", {"factor": factor})
    _call("PUT", "/account/mfa/challenge", {"challengeId": ch["$id"], "otp": code})
    return status()


def _when(iso):
    """'2026-11-12T17:40:35.345+00:00' -> '12/11/2026 alle 18:40' (ora del PC)."""
    if not iso:
        return ""
    try:
        from datetime import datetime
        return datetime.fromisoformat(iso.replace("Z", "+00:00")).astimezone().strftime("%d/%m/%Y alle %H:%M")
    except ValueError:
        return ""


def status():
    """Dati dell'account collegato, None se non c'e'. MfaRequired se manca il secondo passaggio."""
    st = load()
    if not st.get("session"):
        return None
    u = _call("GET", "/account")
    st.update({"email": u.get("email", st.get("email", "")), "uid": u.get("$id", ""),
               "verified": bool(u.get("emailVerification")), "name": u.get("name", ""), "mfa": bool(u.get("mfa"))})
    save(st)
    _sync_license(u.get("prefs") or {})
    return {"email": st["email"], "verified": st["verified"], "name": st["name"], "mfa": st["mfa"], "uid": st["uid"],
            "created": _when(u.get("registration") or u.get("$createdAt")),
            "last_login": _when(u.get("accessedAt"))}


# --------------------------------------- chiave PRO/STUDY nell'account (27.20)
# La chiave sta nelle preferenze PRIVATE dell'account (le legge solo il proprietario).
# Cosi' su un PC nuovo o dopo una reinstallazione basta entrare con l'Account EMAGIAKU.
PREF_LICENSE = "eg_licenza"


def _sync_license(prefs):
    try:
        import common
        want = common.sync_license_with_account(prefs.get(PREF_LICENSE, ""))
        if want:
            _set_pref(prefs, PREF_LICENSE, want)
    except Exception:
        pass


def _set_pref(prefs, key, value):
    new = dict(prefs)
    new[key] = value or ""        # vuota (non tolta): Appwrite ignora un elenco di preferenze vuoto
    _call("PATCH", "/account/prefs", {"prefs": new})


def save_license(key):
    """Salva (o con '' toglie) la chiave nell'account collegato. Nessun account: non fa niente."""
    if not load().get("session"):
        return False
    prefs = _call("GET", "/account/prefs") or {}
    _set_pref(prefs, PREF_LICENSE, key)
    return True


def logout():
    try:
        _call("DELETE", "/account/sessions/current")
    except CloudError:
        pass
    forget()


# ------------------------------------------------------------ email
def send_verification():
    """Manda alla tua email un codice di 6 cifre (valido 15 minuti) per verificarla."""
    r = _call("POST", "/account/verifications/email/otp", {})
    st = load()
    if st and r.get("userId"):
        st["uid"] = r["userId"]
        save(st)


def confirm_email(code_or_link):
    """Verifica l'email con il codice di 6 cifre della mail (o con il link delle mail vecchie)."""
    code = re.sub(r"\s", "", code_or_link or "")
    if re.fullmatch(r"\d{6}", code):
        uid = load().get("uid") or (status() or {}).get("uid", "")
        _call("PUT", "/account/verifications/email/otp", {"userId": uid, "secret": code})
    else:
        uid, sec = link_params(code_or_link)
        _call("PUT", "/account/verification", {"userId": uid, "secret": sec})
    st = load()
    if st:
        st["verified"] = True
        save(st)
    return True


def reset_password(email):
    """Manda un codice di 6 cifre per scegliere la nuova password. Restituisce l'ID utente."""
    r = _call("POST", "/account/recovery/otp", {"email": email.strip()}, session=False)
    return r.get("userId", "")


def confirm_password_reset(code_or_link, new_password, user_id=""):
    bad = password_problem(new_password)
    if bad:
        raise CloudError(bad)
    code = re.sub(r"\s", "", code_or_link or "")
    if re.fullmatch(r"\d{6}", code):
        if not user_id:
            raise CloudError("Prima premi \"Password dimenticata\" per ricevere il codice.")
        _call("PUT", "/account/recovery/otp", {"userId": user_id, "secret": code, "password": new_password},
              session=False)
    else:
        uid, sec = link_params(code_or_link)
        _call("PUT", "/account/recovery", {"userId": uid, "secret": sec, "password": new_password}, session=False)
    return True


# --------------------------------------------- modifica dell'account
def set_name(name):
    name = (name or "").strip()[:60]
    _call("PATCH", "/account/name", {"name": name})
    st = load()
    st["name"] = name
    save(st)
    return name


def change_password(current, new):
    st = load()
    bad = password_problem(new, st.get("email", ""))
    if bad:
        raise CloudError(bad)
    if new == current:
        raise CloudError("La nuova password deve essere diversa da quella attuale.")
    _call("PATCH", "/account/password", {"password": new, "oldPassword": current})
    # le altre sessioni (altri PC) vengono chiuse dal server; se ha chiuso anche questa, rientro
    try:
        status()
    except MfaRequired:
        raise
    except CloudError:
        sign_in(st.get("email", ""), new)
    return True


def change_email(current, new_email):
    """Cambia subito l'email (serve la password) e manda la mail di verifica al nuovo indirizzo."""
    new_email = (new_email or "").strip()
    if "@" not in new_email or "." not in new_email:
        raise CloudError("L'indirizzo email non e' valido.")
    if not current:
        raise CloudError("Scrivi la password attuale.")
    _call("PATCH", "/account/email", {"email": new_email, "password": current})
    st = load()
    st["email"], st["verified"] = new_email, False
    save(st)
    send_verification()
    return new_email


def delete_account():
    """Elimina DEFINITIVAMENTE l'account (diritto alla cancellazione) e lo scollega dal PC."""
    _call("DELETE", "/account")
    forget()


# ------------------------------------------ verifica in due passaggi
def mfa_start():
    """Primo passo: segreto per l'app di autenticazione. Restituisce (segreto, uri otpauth://)."""
    try:
        _call("DELETE", "/account/mfa/authenticators/totp")    # tentativo precedente non finito
    except CloudError:
        pass
    r = _call("POST", "/account/mfa/authenticators/totp")
    return r.get("secret", ""), r.get("uri", "")


def mfa_qr_png(uri, size=300):
    """Immagine PNG del codice QR (generata dal servizio, serve l'accesso)."""
    q = urllib.parse.urlencode({"text": uri, "size": size, "margin": 1})
    return _call("GET", "/avatars/qr?" + q, raw=True)


def mfa_confirm(code):
    """Secondo passo: codice dell'app -> app collegata, codici di recupero, verifica attiva.
    Restituisce i codici di recupero (vanno salvati: si vedono una volta sola)."""
    code = re.sub(r"\D", "", code or "")
    if len(code) != 6:
        raise CloudError("Il codice dell'app ha 6 cifre.")
    _call("PUT", "/account/mfa/authenticators/totp", {"otp": code})
    try:
        codes = _call("POST", "/account/mfa/recovery-codes").get("recoveryCodes", [])
    except CloudError:
        codes = _call("PATCH", "/account/mfa/recovery-codes").get("recoveryCodes", [])   # nuovi codici
    _call("PATCH", "/account/mfa", {"mfa": True})
    st = load()
    st["mfa"] = True
    save(st)
    return codes


def mfa_disable(code):
    """Spegne la verifica in due passaggi (chiede un codice per sicurezza)."""
    complete_mfa(code)
    _call("PATCH", "/account/mfa", {"mfa": False})
    try:
        _call("DELETE", "/account/mfa/authenticators/totp")
    except CloudError:
        pass
    st = load()
    st["mfa"] = False
    save(st)
    return True


# ------------------------------------------- accesso con il telefono (passkey + QR)
def qr_start():
    """Prepara l'accesso con il telefono: (codice, chiave, indirizzo per il QR).
    Il telefono sblocca la passkey e mette nella "casella" `codice` il gettone di accesso cifrato con
    AES-GCM usando `chiave`. La chiave sta solo nel QR (dopo '#', non arriva a nessun server)."""
    import base64
    import secrets
    row = secrets.token_hex(16)
    key = base64.urlsafe_b64encode(secrets.token_bytes(32)).rstrip(b"=").decode()
    return row, key, "%s#r=%s&k=%s" % (PHONE_PAGE, row, key)


def qr_check(row, key):
    """Il telefono ha consegnato? Se si' entra (salva la sessione) e restituisce lo stato, altrimenti None."""
    import base64
    try:
        res = _call("GET", "%s/%s" % (QR_TABLE, row), session=False)
    except CloudError:
        return None                         # ancora niente (o rete assente: si riprova)
    try:
        _call("DELETE", "%s/%s" % (QR_TABLE, row), session=False)    # casella usata una volta sola
    except CloudError:
        pass
    try:
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        blob = base64.urlsafe_b64decode(res["data"] + "=" * (-len(res["data"]) % 4))
        k = base64.urlsafe_b64decode(key + "=" * (-len(key) % 4))
        tok = json.loads(AESGCM(k).decrypt(blob[:12], blob[12:], None).decode())
    except Exception:
        raise CloudError("Risposta del telefono non valida: riprova con un QR nuovo.")
    s = _call("POST", "/account/sessions/token", {"userId": tok["u"], "secret": tok["s"]}, session=False)
    _remember(s, "")
    return status()


def qr_png(url, size=320):
    q = urllib.parse.urlencode({"text": url, "size": size, "margin": 1})
    return _call("GET", "/avatars/qr?" + q, session=False, raw=True)


def passkeys():
    """Passkey del tuo account: [(id, nome, ultimo uso)]."""
    r = _call("GET", "/account/passkeys")
    return [(p.get("$id"), p.get("name") or "Passkey", _when(p.get("accessedAt"))) for p in r.get("passkeys", [])]


def passkey_delete(pid):
    if not re.fullmatch(r"[A-Za-z0-9._-]{1,64}", pid or ""):
        raise CloudError("Passkey non valida.")
    _call("DELETE", "/account/passkeys/%s" % pid)
