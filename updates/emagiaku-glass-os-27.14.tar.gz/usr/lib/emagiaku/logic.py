#!/usr/bin/env python3
"""EMAGIAKU GLASS OS - logica senza interfaccia (testabile senza Qt).

Usata da: installer, EG Store, EG Search, EGPT.
"""
import ast
import configparser
import glob
import json
import operator
import os
import re
import shlex
import shutil
import subprocess
import sys
import urllib.error
import urllib.parse
import urllib.request

HOME = os.path.expanduser("~")
CONF_DIR = os.path.join(HOME, ".config", "emagiaku")
CATALOG = "/usr/share/emagiaku/store/catalog.json"

GLASS_STYLE = """
QWidget { background: #120c1c; color: #ebe4fa; font-size: 14px; }
QLabel#h { font-size: 24px; font-weight: 700; color: #c9a4ff; }
QLabel#s { color: #968caa; }
QPushButton { background: #8a4fff; border: none; border-radius: 12px; padding: 9px 18px; color: white; }
QPushButton:hover { background: #a070ff; }
QPushButton:disabled { background: #3a2a60; color: #7a6c96; }
QPushButton#alt { background: #261840; }
QLineEdit, QComboBox, QListWidget, QPlainTextEdit, QTextBrowser {
  background: #1b1230; border: 1px solid #3a2a60; border-radius: 10px; padding: 6px 10px; }
QListWidget::item:selected { background: #8a4fff; }
QProgressBar { background: #1b1230; border: 1px solid #3a2a60; border-radius: 8px; text-align: center; }
QProgressBar::chunk { background: #8a4fff; border-radius: 8px; }
"""


# ----------------------------------------------------------- utilita'
def sh(cmd, timeout=30):
    """Esegue un comando, restituisce (codice, stdout)."""
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return r.returncode, r.stdout
    except (OSError, subprocess.SubprocessError):
        return 127, ""


def is_live():
    return os.path.isdir("/run/archiso")


def can_sudo():
    return sh(["sudo", "-n", "true"])[0] == 0


def root_prefix():
    """Prefisso per comandi da root: sudo senza password (live) oppure pkexec."""
    return ["sudo", "-n"] if can_sudo() else ["pkexec"]


# ------------------------------------------------------------- dischi
def live_medium_disk():
    """Disco che contiene la chiavetta/ISO da cui e' partito il live."""
    code, out = sh(["findmnt", "-no", "SOURCE", "/run/archiso/bootmnt"])
    src = out.strip()
    if code != 0 or not src:
        return None
    code, out = sh(["lsblk", "-no", "PKNAME", src])
    pk = out.strip().splitlines()
    return "/dev/" + pk[0].strip() if pk and pk[0].strip() else src


def list_disks():
    """Dischi interi con info utili. Ogni voce: dict con path,size,model,tran,live,mounted."""
    code, out = sh(["lsblk", "-J", "-b", "-o", "PATH,SIZE,TYPE,MODEL,TRAN,RM,MOUNTPOINTS,FSTYPE,LABEL,PARTLABEL"])
    if code != 0:
        return []
    try:
        data = json.loads(out)
    except ValueError:
        return []
    live = live_medium_disk()
    res = []
    for d in data.get("blockdevices", []):
        if d.get("type") != "disk":
            continue
        if d["path"].startswith(("/dev/loop", "/dev/ram", "/dev/zram", "/dev/sr")):
            continue
        mps = []

        def walk(n):
            mps.extend([m for m in (n.get("mountpoints") or []) if m])
            for c in n.get("children", []) or []:
                walk(c)
        walk(d)
        contents = [partition_desc(p) for p in d.get("children", []) or []]
        res.append({
            "contents": contents,
            "has_windows": any("Windows" in c for c in contents),
            "path": d["path"],
            "size": int(d.get("size") or 0),
            "model": (d.get("model") or "").strip(),
            "tran": d.get("tran") or "",
            "removable": bool(d.get("rm")),
            "live": d["path"] == live,
            "mounted": mps,
        })
    return res


def partition_desc(p):
    """Descrizione leggibile di una partizione: 'nvme0n1p3  237.5 GB  Windows (NTFS) "Acer"'."""
    fs = (p.get("fstype") or "").lower()
    name = " ".join(x for x in ((p.get("label") or "").strip(), (p.get("partlabel") or "").strip()) if x)
    if fs == "ntfs":
        kind = "Windows (NTFS)"
    elif "microsoft" in name.lower() or "windows" in name.lower():
        kind = "Windows (riservata)"
    elif fs == "vfat":
        kind = "avvio EFI (FAT)" if "efi" in name.lower() or (p.get("size") or 0) < 1100 * 1000 * 1000 else "FAT"
    elif fs:
        kind = fs
    else:
        kind = "senza file system"
    return "%s  %s  %s %s" % (p.get("path", "?").replace("/dev/", ""), human_size(int(p.get("size") or 0)),
                             kind, ('"%s"' % name) if name else "")


def human_size(n):
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1000 or unit == "TB":
            return "%.0f %s" % (n, unit) if unit == "B" else "%.1f %s" % (n, unit)
        n /= 1000.0
    return str(n)


def disk_label(d):
    extra = []
    if d["live"]:
        extra.append("MEDIA DI AVVIO - NON USABILE")
    elif d["mounted"]:
        extra.append("in uso")
    elif d.get("has_windows"):
        extra.append("contiene WINDOWS")
    return "%s  -  %s  %s %s" % (d["path"], human_size(d["size"]), d["model"],
                                 "(" + ", ".join(extra) + ")" if extra else "")


# --------------------------------------------------- validazioni utente
USER_RE = re.compile(r"^[a-z_][a-z0-9_-]{0,31}$")
HOST_RE = re.compile(r"^[a-zA-Z0-9]([a-zA-Z0-9-]{0,30}[a-zA-Z0-9])?$")
RESERVED = {"root", "glass", "daemon", "bin", "sys", "nobody", "sddm"}


def validate_account(username, hostname, pw1, pw2):
    """Restituisce una lista di errori (vuota se tutto ok)."""
    errs = []
    if not USER_RE.match(username or "") or username in RESERVED:
        errs.append("username")
    if not HOST_RE.match(hostname or ""):
        errs.append("hostname")
    if len(pw1 or "") < 4:
        errs.append("password_short")
    if pw1 != pw2:
        errs.append("password_mismatch")
    return errs


PRESET_FILE = {
    "windows": {"layout": "windows", "window_buttons": "windows"},
    "macos": {"layout": "macos", "window_buttons": "macos"},
    "linux": {"layout": "linux", "window_buttons": "linux"},
    "glass": {"layout": "glass", "window_buttons": "macos"},
}


def locale_for(lang):
    if lang == "it":
        return {"locale": "it_IT.UTF-8", "keymap": "it", "tz": "Europe/Rome"}
    return {"locale": "en_US.UTF-8", "keymap": "us", "tz": "UTC"}


# ------------------------------------------------------------- store
def load_catalog():
    try:
        with open(CATALOG, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return []


def installed_packages():
    code, out = sh(["pacman", "-Qq"])
    return set(out.split()) if code == 0 else set()


def filter_catalog(items, query="", category=""):
    q = (query or "").lower().strip()
    res = []
    for it in items:
        if category and it.get("category") != category:
            continue
        hay = (it.get("name", "") + " " + it.get("desc", "") + " " + it.get("pkg", "")).lower()
        if q and q not in hay:
            continue
        res.append(it)
    return res


def store_command(action, pkg):
    """Comando pacman da eseguire come root. pkg deve essere un nome valido."""
    if not re.match(r"^[a-z0-9@._+-]+$", pkg):
        raise ValueError("nome pacchetto non valido")
    if action == "install":
        # nel live basta aggiornare l'elenco; nel sistema installato si aggiorna tutto (Arch non
        # supporta aggiornamenti parziali)
        flags = ["-Sy" if is_live() else "-Syu", "--noconfirm", "--needed", "--noprogressbar"]
        return root_prefix() + ["pacman"] + flags + [pkg]
    if action == "remove":
        return root_prefix() + ["pacman", "-Rns", "--noconfirm", "--noprogressbar", pkg]
    raise ValueError("azione sconosciuta")


def desktop_entry_for(pkg):
    """Exec della prima app grafica installata dal pacchetto (per il pulsante Apri)."""
    code, out = sh(["pacman", "-Qlq", pkg])
    if code != 0:
        return None
    for path in out.split():
        if path.startswith("/usr/share/applications/") and path.endswith(".desktop"):
            cp = configparser.RawConfigParser(strict=False, interpolation=None)
            try:
                cp.read(path, encoding="utf-8")
                e = cp["Desktop Entry"]
            except (configparser.Error, KeyError, UnicodeDecodeError, OSError):
                continue
            if e.get("NoDisplay", "").lower() != "true" and e.get("Exec"):
                return e.get("Exec")
    return None


def free_space_mb(path="/"):
    try:
        st = os.statvfs(path)
        return st.f_bavail * st.f_frsize // (1024 * 1024)
    except OSError:
        return -1


# ------------------------------------------------------------ ricerca
APP_DIRS = ["/usr/share/applications", os.path.join(HOME, ".local/share/applications")]
_lang = os.environ.get("LANG", "en")[:2]


def scan_apps():
    apps = []
    for d in APP_DIRS:
        for f in glob.glob(os.path.join(d, "*.desktop")):
            cp = configparser.RawConfigParser(strict=False, interpolation=None)
            try:
                cp.read(f, encoding="utf-8")
                e = cp["Desktop Entry"]
            except (configparser.Error, KeyError, UnicodeDecodeError, OSError):
                continue
            if e.get("Type") != "Application" or e.get("NoDisplay", "").lower() == "true" \
                    or e.get("Hidden", "").lower() == "true":
                continue
            name = e.get("Name[%s]" % _lang) or e.get("Name")
            ex = e.get("Exec")
            if name and ex:
                apps.append({"name": name, "exec": ex, "comment": e.get("Comment", "")})
    return apps


def exec_args(exec_line):
    """Toglie i codici %f %u ecc. e restituisce la lista argomenti."""
    clean = re.sub(r"%[a-zA-Z]", "", exec_line)
    return shlex.split(clean)


_OPS = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul,
        ast.Div: operator.truediv, ast.Pow: operator.pow, ast.Mod: operator.mod,
        ast.USub: operator.neg, ast.UAdd: operator.pos}


def calc(expr):
    """Calcolatrice sicura (solo numeri e operatori). None se non e' un calcolo."""
    expr = expr.replace(",", ".").replace("x", "*").replace("^", "**").strip()
    if not expr or not re.search(r"\d", expr) or not re.search(r"[-+*/%]", expr):
        return None

    def ev(n):
        if isinstance(n, ast.Expression):
            return ev(n.body)
        if isinstance(n, ast.Constant) and isinstance(n.value, (int, float)):
            return n.value
        if isinstance(n, ast.BinOp) and type(n.op) in _OPS:
            a, b = ev(n.left), ev(n.right)
            if isinstance(n.op, ast.Pow) and abs(b) > 100:
                raise ValueError("esponente troppo grande")
            return _OPS[type(n.op)](a, b)
        if isinstance(n, ast.UnaryOp) and type(n.op) in _OPS:
            return _OPS[type(n.op)](ev(n.operand))
        raise ValueError("non consentito")
    try:
        v = ev(ast.parse(expr, mode="eval"))
    except (ValueError, SyntaxError, ZeroDivisionError, OverflowError, RecursionError):
        return None
    return ("%.10g" % v)


def scicalc(expr, degrees=True, ans=0.0):
    """Calcolatrice scientifica sicura per EG Calculator.
    Restituisce (valore, None) oppure (None, messaggio d'errore in italiano)."""
    import math
    e = expr.strip()
    if not e:
        return None, None
    for a, b in (("×", "*"), ("÷", "/"), ("−", "-"), ("^", "**"), ("π", "pi"),
                 ("√", "sqrt"), (",", ".")):
        e = e.replace(a, b)
    e = re.sub(r"(\d+(?:\.\d+)?)\s*%", r"(\1/100)", e)          # 50% -> 0.5
    e = re.sub(r"(\d+|\))\s*!", r"fact(\1)", e)                    # 5! -> fact(5)
    # 2pi -> 2*pi, 3(4+1) -> 3*(4+1); non tocca i nomi con numeri come log2(
    e = re.sub(r"(?<![A-Za-z_\d.])(\d+(?:\.\d+)?)\s*(?=(?:pi|e\b|sqrt|a?sin|a?cos|a?tan|log|ln|abs|\())", r"\1*", e)
    to_rad = (lambda x: math.radians(x)) if degrees else (lambda x: x)
    from_rad = (lambda x: math.degrees(x)) if degrees else (lambda x: x)

    def fact(x):
        if x != int(x) or x < 0 or x > 170:
            raise ValueError("il fattoriale vale solo per interi da 0 a 170")
        return float(math.factorial(int(x)))

    funcs = {
        "sin": lambda x: math.sin(to_rad(x)), "cos": lambda x: math.cos(to_rad(x)),
        "tan": lambda x: math.tan(to_rad(x)),
        "asin": lambda x: from_rad(math.asin(x)), "acos": lambda x: from_rad(math.acos(x)),
        "atan": lambda x: from_rad(math.atan(x)),
        "sqrt": math.sqrt, "cbrt": lambda x: math.copysign(abs(x) ** (1 / 3), x),
        "log": math.log10, "ln": math.log, "log2": math.log2, "exp": math.exp,
        "abs": abs, "round": round, "floor": math.floor, "ceil": math.ceil, "fact": fact,
    }
    consts = {"pi": math.pi, "e": math.e, "tau": math.tau, "ans": ans}

    def ev(n):
        if isinstance(n, ast.Expression):
            return ev(n.body)
        if isinstance(n, ast.Constant) and isinstance(n.value, (int, float)):
            return n.value
        if isinstance(n, ast.Name) and n.id in consts:
            return consts[n.id]
        if isinstance(n, ast.BinOp):
            ops = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul,
                   ast.Div: operator.truediv, ast.Pow: operator.pow, ast.Mod: operator.mod,
                   ast.FloorDiv: operator.floordiv}
            if type(n.op) not in ops:
                raise ValueError("operazione non permessa")
            a, b = ev(n.left), ev(n.right)
            if isinstance(n.op, ast.Pow) and abs(b) > 1000:
                raise ValueError("esponente troppo grande")
            return ops[type(n.op)](a, b)
        if isinstance(n, ast.UnaryOp) and isinstance(n.op, (ast.USub, ast.UAdd)):
            v = ev(n.operand)
            return -v if isinstance(n.op, ast.USub) else v
        if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id in funcs \
                and len(n.args) == 1 and not n.keywords:
            return funcs[n.func.id](ev(n.args[0]))
        raise ValueError("espressione non valida")

    try:
        v = ev(ast.parse(e, mode="eval"))
    except ZeroDivisionError:
        return None, "Divisione per zero"
    except (ValueError, TypeError) as ex:
        msg = str(ex)
        ours = ("il fattoriale", "esponente", "espressione", "operazione")
        return None, (msg if msg.startswith(ours) else
                      "Fuori dal dominio (es. radice o logaritmo di un numero negativo)")
    except (SyntaxError, OverflowError, RecursionError):
        return None, "Espressione non valida"
    if isinstance(v, complex):
        return None, "Risultato complesso"
    if isinstance(v, float) and abs(v - round(v)) < 1e-12 and abs(v) < 1e15:
        v = float(round(v))
    return v, None


def fmt_number(v):
    if v is None:
        return ""
    if float(v).is_integer() and abs(v) < 1e15:
        return str(int(v))
    return ("%.12g" % v).replace("e+", "e")


def find_files(query, root=HOME, limit=15, max_scan=20000):
    q = query.lower()
    found, scanned = [], 0
    for dp, dn, fn in os.walk(root):
        dn[:] = [d for d in dn if not d.startswith(".")]
        for name in fn + dn:
            scanned += 1
            if q in name.lower():
                found.append(os.path.join(dp, name))
                if len(found) >= limit:
                    return found
        if scanned > max_scan:
            break
    return found


def search(query, apps=None, files=True):
    """Risultati: lista di (etichetta, tipo, destinazione). tipo: calc|app|file|web."""
    query = query.strip()
    res = []
    if not query:
        return res
    c = calc(query)
    if c is not None:
        res.append(("= " + c, "calc", c))
    apps = apps if apps is not None else scan_apps()
    q = query.lower()
    scored = []
    for a in apps:
        n = a["name"].lower()
        if q in n:
            scored.append((0 if n.startswith(q) else 1, a))
    for _, a in sorted(scored, key=lambda t: (t[0], t[1]["name"]))[:8]:
        res.append((a["name"], "app", a["exec"]))
    if files and len(query) >= 3:
        for p in find_files(query):
            res.append((os.path.basename(p) + "   " + os.path.dirname(p), "file", p))
    res.append(('Cerca sul web: "%s"' % query, "web",
                "https://duckduckgo.com/?q=" + urllib.parse.quote(query)))
    return res


def to_url(text):
    """Barra indirizzi del browser: URL oppure ricerca."""
    t = text.strip()
    if not t:
        return "about:blank"
    if re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*://", t):
        return t
    if " " not in t and "." in t:
        return "https://" + t
    return "https://duckduckgo.com/?q=" + urllib.parse.quote(t)


# -------------------------------------------------------------- EGPT
EGPT_CONF = os.path.join(CONF_DIR, "egpt.json")
OLLAMA_DEFAULT_MODEL = "llama3.2:1b"       # ~1.3 GB, gira anche su PC modesti
ANTHROPIC_DEFAULT_MODEL = "claude-haiku-5-5"
EGPT_DEFAULT = {"backend": "ollama", "url": "http://localhost:11434", "api_key": "",
                "ollama_model": OLLAMA_DEFAULT_MODEL, "anthropic_model": ANTHROPIC_DEFAULT_MODEL}


def egpt_load():
    conf = dict(EGPT_DEFAULT)
    try:
        with open(EGPT_CONF, encoding="utf-8") as f:
            conf.update(json.load(f))
    except (OSError, ValueError):
        pass
    # vecchio formato (un solo campo "model")
    old = conf.pop("model", "")
    if old:
        conf[conf["backend"] + "_model"] = old
    # la vecchia versione poteva salvare l'URL di Ollama al posto della chiave
    if conf.get("api_key", "").startswith("http"):
        conf["api_key"] = ""
    if conf["backend"] not in ("ollama", "anthropic"):
        conf["backend"] = "ollama"
    conf["model"] = conf[conf["backend"] + "_model"]
    return conf


def egpt_save(conf):
    os.makedirs(CONF_DIR, exist_ok=True)
    data = {k: conf.get(k, v) for k, v in EGPT_DEFAULT.items()}
    fd = os.open(EGPT_CONF, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    os.chmod(EGPT_CONF, 0o600)


def egpt_request(conf, messages):
    """Costruisce (url, headers, body) per il backend scelto. Nessuna chiave inclusa nell'ISO."""
    msgs = [{"role": m["role"], "content": m["content"]} for m in messages
            if m["role"] in ("user", "assistant")]
    if conf["backend"] == "anthropic":
        return ("https://api.anthropic.com/v1/messages",
                {"x-api-key": conf["api_key"], "anthropic-version": "2023-06-01",
                 "content-type": "application/json"},
                {"model": conf["model"], "max_tokens": 1024, "messages": msgs})
    return (conf["url"].rstrip("/") + "/api/chat",
            {"content-type": "application/json"},
            {"model": conf["model"], "messages": msgs, "stream": False})


def egpt_parse(conf, data):
    if conf["backend"] == "anthropic":
        return "".join(b.get("text", "") for b in data.get("content", []) if b.get("type") == "text")
    return (data.get("message") or {}).get("content", "")


def _http_error_text(e):
    """Messaggio leggibile da un errore HTTP di Ollama o Anthropic."""
    try:
        data = json.loads(e.read().decode(errors="replace"))
        err = data.get("error")
        if isinstance(err, dict):
            return err.get("message") or str(err)
        if err:
            return str(err)
    except (ValueError, OSError, AttributeError):
        pass
    return ""


def egpt_chat(conf, messages, timeout=300):
    """Restituisce (ok, testo). Gli errori diventano messaggi leggibili."""
    if not conf.get("model"):
        return False, "Scegli prima il modello."
    if conf["backend"] == "anthropic" and not conf.get("api_key"):
        return False, "Per Anthropic serve la tua chiave API (console.anthropic.com)."
    url, headers, body = egpt_request(conf, messages)
    req = urllib.request.Request(url, data=json.dumps(body).encode(), headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            text = egpt_parse(conf, json.loads(r.read().decode()))
            return (True, text) if text else (False, "Risposta vuota dal servizio.")
    except urllib.error.HTTPError as e:
        detail = _http_error_text(e)
        if conf["backend"] == "anthropic" and e.code == 401:
            return False, "Chiave API Anthropic non valida."
        if conf["backend"] == "ollama" and e.code == 404:
            return False, "Il modello '%s' non e' scaricato: premi 'Scarica modello'." % conf["model"]
        return False, "Errore %s dal servizio. %s" % (e.code, detail)
    except (urllib.error.URLError, OSError, ValueError) as e:
        if conf["backend"] == "ollama":
            return False, "Ollama non risponde: installalo e avvialo con i pulsanti qui sopra."
        return False, "Servizio non raggiungibile: controlla la connessione (%s)." % getattr(e, "reason", e)


# ---------------------------------------------------------- Ollama
def ollama_installed():
    return shutil.which("ollama") is not None


def ollama_models(url="http://localhost:11434", timeout=3):
    """Lista dei modelli scaricati, oppure None se Ollama non risponde."""
    try:
        with urllib.request.urlopen(url.rstrip("/") + "/api/tags", timeout=timeout) as r:
            data = json.loads(r.read().decode())
        return [m.get("name", "") for m in data.get("models", []) if m.get("name")]
    except (urllib.error.URLError, OSError, ValueError):
        return None


def ollama_start_command():
    return root_prefix() + ["systemctl", "enable", "--now", "ollama.service"]


# ------------------------------------------------------------- schermi
INTERNAL_PREFIXES = ("eDP", "LVDS", "DSI")


def parse_xrandr(text):
    """Dall'output di 'xrandr --query' restituisce la lista dei nomi degli schermi collegati."""
    outs = []
    for line in text.splitlines():
        m = re.match(r"^([A-Za-z0-9_.-]+) connected", line)
        if m:
            outs.append(m.group(1))
    return outs


def split_outputs(outs):
    """(schermo interno, [schermi esterni]). Se non c'e' un interno, il primo fa da principale."""
    internal = next((o for o in outs if o.startswith(INTERNAL_PREFIXES)), None)
    if internal is None and outs:
        internal = outs[0]
    return internal, [o for o in outs if o != internal]


def screen_commands(mode, outs):
    """Comandi xrandr per la modalita': single | mirror | extend | external_only."""
    internal, ext = split_outputs(outs)
    if not internal:
        return None
    if mode == "single":
        cmds = [["xrandr", "--output", internal, "--auto", "--primary"]]
        cmds += [["xrandr", "--output", e, "--off"] for e in ext]
        return cmds
    if not ext:
        return None
    if mode == "mirror":
        cmds = [["xrandr", "--output", internal, "--auto", "--primary"]]
        cmds += [["xrandr", "--output", e, "--auto", "--same-as", internal] for e in ext]
        return cmds
    if mode == "extend":
        cmds = [["xrandr", "--output", internal, "--auto", "--primary"]]
        prev = internal
        for e in ext:
            cmds.append(["xrandr", "--output", e, "--auto", "--right-of", prev])
            prev = e
        return cmds
    if mode == "external_only":
        cmds = [["xrandr", "--output", ext[0], "--auto", "--primary"],
                ["xrandr", "--output", internal, "--off"]]
        cmds += [["xrandr", "--output", e, "--off"] for e in ext[1:]]
        return cmds
    return None


def connected_outputs():
    code, out = sh(["xrandr", "--query"])
    return parse_xrandr(out) if code == 0 else []


#   KDE (kscreen-doctor): stesso strumento delle impostazioni di KDE, cosi' la configurazione resta salvata
#   e non litiga con xrandr. Dopo OGNI cambio le posizioni vengono ricalcolate: schermi uno accanto
#   all'altro, senza sovrapporsi (prima: cambiando la risoluzione il secondo schermo finiva sotto al primo).
def kscreen_outputs():
    """Schermi collegati secondo KDE: lista di dict (nome, attivo, modi, posizione...). [] se non disponibile."""
    if not shutil.which("kscreen-doctor"):
        return []
    code, txt = sh(["kscreen-doctor", "-j"], timeout=15)
    try:
        data = json.loads(txt[txt.find("{"):]) if code == 0 and "{" in txt else {}
    except ValueError:
        return []
    return parse_kscreen(data)


def parse_kscreen(data):
    outs = []
    for o in data.get("outputs", []):
        if not o.get("connected"):
            continue
        modes = {}
        for m in o.get("modes", []):
            try:
                modes[str(m["id"])] = (int(m["size"]["width"]), int(m["size"]["height"]), float(m.get("refreshRate", 0)))
            except (KeyError, TypeError, ValueError):
                continue
        pref = [str(p) for p in (o.get("preferredModes") or [])]
        pos = o.get("pos") or {}
        outs.append({"name": o.get("name", ""), "enabled": bool(o.get("enabled")), "modes": modes,
                     "current": str(o.get("currentModeId", "")), "preferred": pref[0] if pref else "",
                     "x": int(pos.get("x", 0)), "y": int(pos.get("y", 0)), "scale": float(o.get("scale") or 1),
                     "rotation": int(o.get("rotation") or 1), "priority": int(o.get("priority") or 0)})
    return outs


def _logical_size(out, mode_id, scale, wayland):
    w, h, _hz = out["modes"].get(str(mode_id), (1920, 1080, 60))
    if out.get("rotation") in (2, 8):          # ruotato di 90 gradi: larghezza e altezza si scambiano
        w, h = h, w
    if wayland and scale:
        w, h = int(round(w / scale)), int(round(h / scale))
    return w, h


def is_wayland():
    return os.environ.get("XDG_SESSION_TYPE", "").lower() == "wayland"


def side_by_side(outs, modes=None, scales=None, wayland=None):
    """Posizioni (x, y) degli schermi attivi uno accanto all'altro, nell'ordine attuale da sinistra."""
    modes, scales = modes or {}, scales or {}
    wayland = is_wayland() if wayland is None else wayland
    active = sorted([o for o in outs if o["enabled"]], key=lambda o: (o["x"], o["y"], o["name"]))
    pos, x = {}, 0
    for o in active:
        pos[o["name"]] = (x, 0)
        w, _h = _logical_size(o, modes.get(o["name"], o["current"]), scales.get(o["name"], o["scale"]), wayland)
        x += w
    return pos


def kscreen_args(outs, modes=None, scales=None, enabled=None, positions=None, primary=None):
    """Argomenti di kscreen-doctor: modo, dimensione e posizione per ogni schermo, cosi' niente si sovrappone."""
    modes, scales = modes or {}, scales or {}
    args = []
    for o in outs:
        n = o["name"]
        on = enabled.get(n, o["enabled"]) if enabled else o["enabled"]
        if not on:
            args.append("output.%s.disable" % n)
            continue
        args.append("output.%s.enable" % n)
        if n in modes:
            args.append("output.%s.mode.%s" % (n, modes[n]))
        # su X11 la dimensione per schermo non esiste (si usa quella globale): mando solo 1 per ripulire
        if n in scales and (is_wayland() or float(scales[n]) == 1.0):
            args.append("output.%s.scale.%s" % (n, ("%g" % scales[n])))
        if positions and n in positions:
            args.append("output.%s.position.%d,%d" % ((n,) + tuple(positions[n])))
    if primary:
        args.append("output.%s.priority.1" % primary)    # schermo principale (Plasma 6)
    return args


def apply_global_scale(factor):
    """X11: dimensione di testi e finestre su tutti gli schermi (KDE la applica dal prossimo accesso)."""
    factor = max(1.0, min(3.0, float(factor)))
    names = [o["name"] for o in kscreen_outputs() if o["enabled"]]
    for cmd in (["kwriteconfig6", "--file", "kdeglobals", "--group", "KScreen", "--key", "ScaleFactor", "%g" % factor],
                ["kwriteconfig6", "--file", "kdeglobals", "--group", "KScreen", "--key", "ScreenScaleFactors",
                 ";".join("%s=%g" % (n, factor) for n in names) + (";" if names else "")],
                ["kwriteconfig6", "--file", "kcmfonts", "--group", "General", "--key", "forceFontDPI",
                 "0" if factor == 1.0 else str(int(round(96 * factor)))]):
        if sh(cmd)[0] != 0:
            return False
    return True


def global_scale():
    code, out = sh(["kreadconfig6", "--file", "kdeglobals", "--group", "KScreen", "--key", "ScaleFactor"])
    try:
        return float(out.strip()) if code == 0 and out.strip() else 1.0
    except ValueError:
        return 1.0


def kscreen_layout(mode, outs):
    """Argomenti per: extend | mirror | single | external_only | reset. None se non si puo'."""
    if not outs:
        return None
    names = [o["name"] for o in outs]
    internal, ext = split_outputs(names)
    byname = {o["name"]: o for o in outs}
    if mode in ("extend", "reset"):
        modes = {}
        scales = {}
        for o in outs:
            mid = o["current"] if (o["enabled"] and o["current"] in o["modes"] and mode == "extend") else \
                (o["preferred"] or o["current"] or (sorted(o["modes"], key=lambda k: -o["modes"][k][0] * o["modes"][k][1])
                                                    or [""])[0])
            modes[o["name"]] = mid
            if mode == "reset":
                scales[o["name"]] = 1.0
        # interno a sinistra, poi gli esterni nell'ordine attuale
        order = [internal] + [e for e in sorted(ext, key=lambda n: (byname[n]["x"], n))]
        laid = []
        for i, n in enumerate(order):
            o = dict(byname[n], enabled=True, x=i * 100000, y=0)
            laid.append(o)
        pos = side_by_side(laid, modes, scales)
        return kscreen_args(outs, modes, scales, {n: True for n in names}, pos, internal)
    if mode == "mirror":
        if not ext:
            return None
        sizes = None
        for o in outs:
            s = {(w, h) for (w, h, _r) in o["modes"].values()}
            sizes = s if sizes is None else sizes & s
        modes = {}
        if sizes:
            best = max(sizes, key=lambda wh: wh[0] * wh[1])
            for o in outs:
                cands = [k for k, (w, h, r) in o["modes"].items() if (w, h) == best]
                modes[o["name"]] = max(cands, key=lambda k: o["modes"][k][2])
        pos = {n: (0, 0) for n in names}
        return kscreen_args(outs, modes, None, {n: True for n in names}, pos, internal)
    if mode == "single":
        o = byname[internal]
        mid = o["current"] if o["current"] in o["modes"] else o["preferred"]
        return kscreen_args(outs, {internal: mid} if mid else None, None,
                            {n: n == internal for n in names}, {internal: (0, 0)}, internal)
    if mode == "external_only":
        if not ext:
            return None
        e = ext[0]
        o = byname[e]
        mid = o["current"] if (o["enabled"] and o["current"] in o["modes"]) else (o["preferred"] or o["current"])
        return kscreen_args(outs, {e: mid} if mid else None, None, {n: n == e for n in names}, {e: (0, 0)}, e)
    return None


def apply_screen_mode(mode):
    """Applica la modalita' (extend, mirror, single, external_only, reset). Restituisce (ok, messaggio)."""
    kouts = kscreen_outputs()
    if kouts:
        args = kscreen_layout(mode, kouts)
        if args is None:
            return False, "Collega prima un secondo schermo o una TV."
        code, _o = sh(["kscreen-doctor"] + args, timeout=30)
        return code == 0, "Fatto." if code == 0 else "Non riuscito."
    outs = connected_outputs()
    if not outs:
        return False, "Nessuno schermo rilevato (serve la sessione grafica)."
    cmds = screen_commands("extend" if mode == "reset" else mode, outs)
    if cmds is None:
        return False, "Collega prima un secondo schermo o una TV."
    ok = all(sh(c)[0] == 0 for c in cmds)
    return ok, "Fatto." if ok else "Non riuscito."


# ------------------------------------------------------ spazio del live
def free_mb(path="/"):
    m = free_space_mb(path)
    return m if m >= 0 else 0


def low_space_warning(path="/", needed_mb=800):
    """Testo di avviso se siamo nel live e lo spazio libero e' poco, altrimenti None."""
    if is_live() and free_mb(path) < needed_mb:
        return ("Poco spazio nel sistema live (%d MB liberi). L'installazione di app grandi potrebbe "
                "fallire: chiudi altre app oppure installa EMAGIAKU sul disco." % free_mb(path))
    return None


# ------------------------------------------------- glass delle app EMAGIAKU
def glass_window(w):
    """Sfondo della finestra in glass (se attivo in Glass Engine); il resto resta pieno."""
    try:
        import common
        w.setObjectName("glassroot")
        w.setStyleSheet(common.glass_stylesheet(w.styleSheet()))
    except Exception:
        pass


# ---------------------------------------------------- errori delle app
def install_crash_guard(name):
    """Se un'app va in errore, scrive il dettaglio in ~/.cache/emagiaku/errors.log
    e mostra un messaggio invece di chiudersi in silenzio."""
    def hook(etype, value, tb):
        import traceback
        text = "".join(traceback.format_exception(etype, value, tb))
        try:
            d = os.path.join(HOME, ".cache", "emagiaku")
            os.makedirs(d, exist_ok=True)
            with open(os.path.join(d, "errors.log"), "a", encoding="utf-8") as f:
                f.write("== %s ==\n%s\n" % (name, text))
        except OSError:
            pass
        sys.stderr.write(text)
        try:
            from PyQt6.QtWidgets import QApplication, QMessageBox
            if QApplication.instance() is not None:
                QMessageBox.critical(None, name, "Si e' verificato un errore:\n%s\n\n"
                                     "Dettagli in ~/.cache/emagiaku/errors.log" % value)
        except Exception:
            pass
    sys.excepthook = hook
