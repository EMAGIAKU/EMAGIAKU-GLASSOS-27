"""EMAGIAKU GLASS OS PRO - finestre condivise (promo, attivazione chiave, pannello amministratore)."""
import common as c
import logic as L
from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QLineEdit,
                             QComboBox, QSpinBox, QFormLayout, QCheckBox, QFrame)

PRO_STYLE = L.GLASS_STYLE + """
QFrame#hero { border-radius: 26px; background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #8a4fff, stop:1 #2b0f5e); }
QLabel#big { font-size: 30px; font-weight: 900; color: white; background: transparent; }
QLabel#tag { font-size: 17px; color: #f1e8ff; background: transparent; }
QLabel#price { font-size: 40px; font-weight: 900; color: white; background: transparent; }
QPushButton#buy { background: white; color: #4b1fb0; font-weight: 800; font-size: 15px; padding: 11px 18px; }
QPushButton#buy:hover { background: #efe6ff; }
QPushButton#key { background: white; color: #4b1fb0; font-weight: 800; }
"""


def buy(parent, edition):
    """Apre il pagamento PayPal nel browser e spiega come arriva la chiave."""
    import subprocess
    from PyQt6.QtWidgets import QMessageBox
    name = {"pro": "PRO", "study": "STUDY", "play": "EG PLAY"}[edition]
    prefix = {"pro": "EGPRO-...", "study": "EGSTD-...", "play": "EGPLY-..."}[edition]
    title = "EG PLAY OS" if edition == "play" else "EMAGIAKU GLASS OS 27 %s" % name
    extra = {"pro": "<br>Incluso: <b>EG PLAY OS</b> e <b>2 mesi di EG PLAY CLOUD PRO</b> "
                    "(dall'apertura del servizio).<br>",
             "play": "<br>Con la chiave arriva anche il <b>link privato per scaricare la ISO</b> di EG PLAY OS "
                     "(lo trovi anche qui dopo aver attivato la chiave).<br>"}.get(edition, "")
    link = c.BUY_LINKS[edition]
    box = QMessageBox(parent)
    box.setWindowTitle("Acquista %s" % title)
    box.setTextFormat(Qt.TextFormat.RichText)
    box.setText(
        "<b>%s - %s</b><br>%s<br>"
        "1. Si apre la pagina di pagamento <b>PayPal</b> di EMAGIAKU (serve internet).<br>"
        "2. Paga <b>%s</b>. Nella nota del pagamento scrivi <b>&quot;%s&quot;</b> e, se vuoi, l'email "
        "dove ricevere la chiave.<br>"
        "3. Riceverai la tua chiave <b>%s</b> da EMAGIAKU.TEAM all'email del tuo conto PayPal.<br>"
        "4. Inseriscila con <b>Attiva chiave</b>.<br><br>"
        "<span style='color:#968caa'>Il pagamento avviene sul sito di PayPal: EMAGIAKU GLASS OS non vede "
        "e non salva i tuoi dati di pagamento.</span>"
        % (title, c.BUY_PRICES[edition], extra, c.BUY_PRICES[edition], name, prefix))
    box.setStandardButtons(QMessageBox.StandardButton.Ok | QMessageBox.StandardButton.Cancel)
    box.button(QMessageBox.StandardButton.Ok).setText("Vai a PayPal")
    box.button(QMessageBox.StandardButton.Cancel).setText("Annulla")
    if box.exec() == QMessageBox.StandardButton.Ok:
        try:
            subprocess.Popen(["xdg-open", link], start_new_session=True)
        except OSError:
            QMessageBox.information(parent, "PayPal", "Apri questo indirizzo nel browser:\n" + link)


def scan_text(s):
    lines = ["<b>CPU:</b> %s (%d thread)" % (s["cpu"], s["threads"]),
             "<b>RAM:</b> %.1f GB" % s["ram_gb"],
             "<b>Grafica:</b> %s" % "<br>".join(s["gpu"])]
    if s["old"]:
        lines.append("<br><b style='color:#ffd36e'>PC datato</b> (%s): la Modalita' Gioco PRO "
                     "chiudera' le altre app quando avvii un gioco." % ", ".join(s["reasons"]))
    else:
        lines.append("<br><b style='color:#8affc1'>PC recente</b>: la Modalita' Gioco resta in automatico "
                     "e non chiude le app (puoi forzarla dal pannello amministratore).")
    return "<br>".join(lines)


def run_scan_and_save():
    conf = c.load_pro()
    conf["scan"] = c.scan_hardware(conf)
    c.save_pro(conf)
    return conf["scan"]


class ActivateDialog(QDialog):
    """Chiede la chiave. Dopo l'attivazione scansiona il PC."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.role = None
        self.setWindowTitle("Attiva EMAGIAKU GLASS OS 27 PRO / STUDY")
        self.setStyleSheet(PRO_STYLE)
        self.setMinimumWidth(480)
        lay = QVBoxLayout(self)
        h = QLabel("Attiva chiave")
        h.setObjectName("h")
        lay.addWidget(h)
        self.key = QLineEdit()
        self.key.setPlaceholderText("EGPRO-XXXX-...  EGSTD-XXXX-...  EGPLY-XXXX-...")
        self.key.setStyleSheet("font-size: 17px; padding: 10px; letter-spacing: 1px;")
        self.key.returnPressed.connect(self.try_key)
        lay.addWidget(self.key)
        self.msg = QLabel("")
        self.msg.setWordWrap(True)
        lay.addWidget(self.msg)
        row = QHBoxLayout()
        self.cancel = QPushButton("Annulla")
        self.cancel.setObjectName("alt")
        self.cancel.clicked.connect(self.reject)
        self.ok = QPushButton("Attiva")
        self.ok.clicked.connect(self.try_key)
        row.addStretch(1)
        row.addWidget(self.cancel)
        row.addWidget(self.ok)
        lay.addLayout(row)

    def try_key(self):
        if self.role:
            self.accept()
            return
        role = c.activate_key(self.key.text())
        if not role:
            self.msg.setText("<span style='color:#ff8aa0'>Chiave non valida.</span>")
            return
        self.role = role
        self.key.setEnabled(False)
        study_txt = ("Le app STUDY sono nel menu (categoria Istruzione): EG Study Hub, EG Notes, EG Focus, "
                     "EG Calculator, EG Library, EG AI Study.")
        if role == "study":
            self.msg.setText("<b style='color:#8affc1'>EMAGIAKU GLASS OS 27 STUDY attivato.</b><br><br>%s<br><br>"
                             "<i>Studia meglio. Rimani concentrato.</i>" % study_txt)
        elif role == "play":
            self.msg.setText("<b style='color:#8affc1'>EG PLAY attivato.</b><br><br>Apri <b>EG PLAY</b> dal menu "
                             "(Giochi). Per la ISO di EG PLAY OS: Impostazioni › Edizione › Scarica la ISO.")
        else:
            self.msg.setText("Attivata! Scansiono il tuo PC...")
            self.repaint()
            s = run_scan_and_save()
            who = {"admin": "PRO + STUDY (AMMINISTRATORE)", "test": "PRO + STUDY (CHIAVE DI PROVA)",
                   "prize": "PRO + STUDY (PREMIO)"}.get(role, "PRO")
            extra = ("<br><br>" + study_txt) if role in c.FULL_ROLES else ""
            self.msg.setText("<b style='color:#8affc1'>EMAGIAKU GLASS OS 27 %s attivato.</b><br><br>%s%s"
                             % (who, scan_text(s), extra))
        self.cancel.hide()
        self.ok.setText("Fatto")


class PromoDialog(QDialog):
    """ACQUISTA EGGLASS OS PRO - gaming anche su PC scarsi."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("EMAGIAKU GLASS OS 27 - Edizioni")
        self.setStyleSheet(PRO_STYLE)
        self.setMinimumWidth(760)
        lay = QVBoxLayout(self)
        intro = QLabel("Stai usando <b>EMAGIAKU GLASS OS 27 STANDARD</b>. Passa a un'altra edizione:")
        intro.setWordWrap(True)
        lay.addWidget(intro)
        cards = QHBoxLayout()
        for edition, title, tag, grad in (
                ("pro", "ACQUISTA EGGLASS OS PRO",
                 "Gaming anche su PC scarsi: quando avvii un gioco, PRO chiude tutto il resto e lascia "
                 "scheda grafica e processore solo al gioco. Incluso EG PLAY OS e 2 mesi di "
                 "EG PLAY CLOUD PRO (dall'apertura del servizio).",
                 "stop:0 #8a4fff, stop:1 #2b0f5e"),
                ("study", "EMAGIAKU GLASS OS 27 STUDY",
                 "Per studenti e scuole: Study Hub, Notes, Focus (Pomodoro), Calculator scientifica, "
                 "Library e AI Study. Studia meglio. Rimani concentrato.",
                 "stop:0 #5b3fd9, stop:1 #12082a")):
            price = c.BUY_PRICES[edition]
            hero = QFrame()
            hero.setObjectName("hero")
            hero.setStyleSheet("QFrame#hero { border-radius: 26px; background: qlineargradient(x1:0, y1:0, "
                               "x2:1, y2:1, %s); }" % grad)
            hl = QVBoxLayout(hero)
            hl.setContentsMargins(24, 22, 24, 22)
            a = QLabel(title)
            a.setObjectName("big")
            a.setStyleSheet("font-size: 22px;")
            a.setWordWrap(True)
            b = QLabel(tag)
            b.setObjectName("tag")
            b.setStyleSheet("font-size: 14px;")
            b.setWordWrap(True)
            p = QLabel(price)
            p.setObjectName("price")
            btn = QPushButton("Acquista con PayPal - %s" % price)
            btn.setObjectName("buy")
            btn.setCursor(Qt.CursorShape.PointingHandCursor)
            btn.clicked.connect(lambda _c, e=edition: buy(self, e))
            hl.addWidget(a)
            hl.addWidget(b, 1)
            hl.addWidget(p)
            hl.addWidget(btn)
            cards.addWidget(hero, 1)
        lay.addLayout(cards)
        row = QHBoxLayout()
        key = QPushButton("Attiva chiave (PRO o STUDY)")
        key.setObjectName("key")
        key.clicked.connect(self.activate)
        row.addStretch(1)
        row.addWidget(key, 1)
        row.addStretch(1)
        lay.addLayout(row)
        bottom = QHBoxLayout()
        self.hide_cb = QCheckBox("Non mostrare piu'")
        later = QPushButton("Piu' tardi")
        later.setObjectName("alt")
        later.clicked.connect(self.close_promo)
        bottom.addWidget(self.hide_cb)
        bottom.addStretch(1)
        bottom.addWidget(later)
        lay.addLayout(bottom)

    def close_promo(self):
        if self.hide_cb.isChecked():
            conf = c.load_pro()
            conf["promo_hidden"] = True
            c.save_pro(conf)
        self.reject()

    def activate(self):
        d = ActivateDialog(self)
        if d.exec() and d.role:
            self.accept()


def open_iso_link(parent):
    """Apre il Drive privato con la ISO di EG PLAY OS (serve una chiave PRO / EG PLAY attiva)."""
    import subprocess
    from PyQt6.QtWidgets import QMessageBox
    import playiso
    url = playiso.link()
    if not url:
        msg = ("Il link della ISO arriva con il prossimo aggiornamento." if not playiso.available()
               else "Serve una chiave PRO o EG PLAY attiva su questo PC.")
        QMessageBox.information(parent, "EG PLAY OS", msg)
        return False
    subprocess.Popen(["xdg-open", url], start_new_session=True)
    return True


class PlayPromoDialog(QDialog):
    """27.22 - una volta sola dopo l'aggiornamento: EG PLAY OS per ridare vita a una vecchia console/PC."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.result_state = "dopo"          # chiudere con la X = "ricordamelo piu' tardi"
        self.setWindowTitle("EG PLAY OS")
        self.setStyleSheet(PRO_STYLE)
        self.setMinimumWidth(640)
        lay = QVBoxLayout(self)
        hero = QFrame()
        hero.setObjectName("hero")
        hero.setStyleSheet("QFrame#hero { border-radius: 26px; background: qlineargradient(x1:0, y1:0, x2:1, y2:1, "
                           "stop:0 #0b0814, stop:0.55 #3b1d6e, stop:1 #8a4fff); }")
        hl = QVBoxLayout(hero)
        hl.setContentsMargins(28, 26, 28, 26)
        a = QLabel("EI, HAI UNA CONSOLE VECCHIA?<br>RIDALLE VITA CON EG PLAY OS")
        a.setObjectName("big")
        a.setWordWrap(True)
        b = QLabel("Un vecchio PC o una console portatile PC (Steam Deck, ROG Ally, Legion Go) diventa una console "
                   "EMAGIAKU: si accende direttamente nei giochi, senza desktop, e si usa con il controller "
                   "PlayStation, Xbox o Nintendo.")
        b.setObjectName("tag")
        b.setWordWrap(True)
        n = QLabel("Non si installa su PlayStation, Xbox e Nintendo Switch: le blocca chi le produce.")
        n.setStyleSheet("color: #d9ccff; background: transparent; font-size: 12px;")
        n.setWordWrap(True)
        p = QLabel(c.BUY_PRICES["play"])
        p.setObjectName("price")
        hl.addWidget(a)
        hl.addWidget(b)
        hl.addWidget(n)
        hl.addWidget(p)
        lay.addWidget(hero)
        steps = QLabel("1. Paga con PayPal  ›  2. Ricevi la chiave EG PLAY e il link privato della ISO  ›  "
                       "3. Mettila su una chiavetta USB e avvia la console.<br>"
                       "<span style='color:#968caa'>EG PLAY e' gia' incluso in EG GLASS OS PRO.</span>")
        steps.setWordWrap(True)
        steps.setTextFormat(Qt.TextFormat.RichText)
        lay.addWidget(steps)
        row = QHBoxLayout()
        pay = QPushButton("Paga con PayPal - %s" % c.BUY_PRICES["play"])
        pay.setObjectName("buy")
        pay.clicked.connect(self.pay)
        key = QPushButton("Ho gia' una chiave")
        key.setObjectName("key")
        key.clicked.connect(self.activate)
        row.addWidget(pay, 2)
        row.addWidget(key, 1)
        lay.addLayout(row)
        bottom = QHBoxLayout()
        no = QPushButton("No, grazie")
        no.setObjectName("alt")
        no.clicked.connect(lambda: self.finish("fatto"))
        later = QPushButton("Ricordamelo piu' tardi")
        later.setObjectName("alt")
        later.clicked.connect(lambda: self.finish("dopo"))
        bottom.addWidget(no)
        bottom.addStretch(1)
        bottom.addWidget(later)
        lay.addLayout(bottom)

    def finish(self, state):
        self.result_state = state
        self.accept()

    def pay(self):
        buy(self, "play")
        self.finish("fatto")

    def activate(self):
        d = ActivateDialog(self)
        if d.exec() and d.role:
            if c.has_play():
                open_iso_link(self)
            self.finish("fatto")


class AdminPanel(QDialog):
    """Solo con la chiave amministratore: regola la Modalita' Gioco PRO e la licenza."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("EGGLASS OS PRO - Amministratore")
        self.setStyleSheet(PRO_STYLE)
        self.setMinimumWidth(560)
        self.conf = c.load_pro()
        lay = QVBoxLayout(self)
        h = QLabel("Pannello amministratore")
        h.setObjectName("h")
        lay.addWidget(h)
        self.scan_lbl = QLabel(scan_text(self.conf["scan"] or run_scan_and_save()))
        self.scan_lbl.setWordWrap(True)
        self.scan_lbl.setTextFormat(Qt.TextFormat.RichText)
        lay.addWidget(self.scan_lbl)
        form = QFormLayout()
        self.mode = QComboBox()
        for label, v in (("Automatica (solo se il PC e' datato)", "auto"),
                         ("Sempre attiva", "on"), ("Spenta", "off")):
            self.mode.addItem(label, v)
        self.mode.setCurrentIndex(max(0, self.mode.findData(self.conf["game_mode"])))
        form.addRow("Modalita' Gioco:", self.mode)
        self.cd = QSpinBox()
        self.cd.setRange(0, 60)
        self.cd.setSuffix(" s")
        self.cd.setValue(int(self.conf["countdown"]))
        form.addRow("Avviso prima di chiudere:", self.cd)
        self.ram = QSpinBox()
        self.ram.setRange(1, 64)
        self.ram.setSuffix(" GB")
        self.ram.setValue(int(self.conf["min_ram_gb"]))
        form.addRow("Datato se RAM sotto:", self.ram)
        self.thr = QSpinBox()
        self.thr.setRange(1, 64)
        self.thr.setValue(int(self.conf["min_threads"]))
        form.addRow("Datato se thread CPU sotto:", self.thr)
        self.keep = QLineEdit(", ".join(self.conf["keep"]))
        self.keep.setPlaceholderText("es. discord, obs")
        form.addRow("Non chiudere mai:", self.keep)
        lay.addLayout(form)
        self.msg = QLabel("")
        self.msg.setObjectName("s")
        lay.addWidget(self.msg)
        row = QHBoxLayout()
        rescan = QPushButton("Riscansiona PC")
        rescan.setObjectName("alt")
        rescan.clicked.connect(self.rescan)
        deact = QPushButton("Disattiva PRO")
        deact.setObjectName("alt")
        deact.clicked.connect(self.deactivate)
        save = QPushButton("Salva")
        save.clicked.connect(self.save)
        row.addWidget(rescan)
        row.addWidget(deact)
        row.addStretch(1)
        row.addWidget(save)
        lay.addLayout(row)

    def collect(self):
        self.conf["game_mode"] = self.mode.currentData()
        self.conf["countdown"] = self.cd.value()
        self.conf["min_ram_gb"] = self.ram.value()
        self.conf["min_threads"] = self.thr.value()
        self.conf["keep"] = [k.strip().lower() for k in self.keep.text().split(",") if k.strip()]

    def rescan(self):
        self.collect()
        self.conf["scan"] = c.scan_hardware(self.conf)
        c.save_pro(self.conf)
        self.scan_lbl.setText(scan_text(self.conf["scan"]))
        self.msg.setText("Scansione aggiornata.")

    def save(self):
        self.collect()
        self.conf["scan"] = c.scan_hardware(self.conf)
        c.save_pro(self.conf)
        self.scan_lbl.setText(scan_text(self.conf["scan"]))
        self.msg.setText("Salvato. Vale dal prossimo gioco avviato.")

    def deactivate(self):
        c.deactivate()
        self.msg.setText("PRO disattivato su questo PC.")
