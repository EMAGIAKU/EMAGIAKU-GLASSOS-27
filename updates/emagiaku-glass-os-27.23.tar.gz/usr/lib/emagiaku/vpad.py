"""EG Remoto "Gioca" (27.22) - controller virtuale sul PC.

Il telefono (web app EG Remoto) manda lo stato del suo controller (vero o disegnato sullo schermo); qui diventa un
controller "Xbox 360" vero per Linux (uinput), uguale a quello del driver xpad: lo vedono Steam, i giochi ed EG PLAY.
Solo libreria standard di Python. Serve il permesso su /dev/uinput (regola 71-emagiaku-controller.rules,
messa da "Prepara EG PLAY OS" o gia' presente nella ISO).
"""
import fcntl
import os
import struct
import time

UI_SET_EVBIT, UI_SET_KEYBIT, UI_SET_ABSBIT = 0x40045564, 0x40045565, 0x40045567
UI_DEV_CREATE, UI_DEV_DESTROY = 0x5501, 0x5502
EV_SYN, EV_KEY, EV_ABS = 0, 1, 3
# pulsanti nell'ordine "standard" dei browser -> codici Linux del driver xpad
# 0 A, 1 B, 2 X, 3 Y, 4 LB, 5 RB, (6 LT, 7 RT = assi), 8 Back, 9 Start, 10 L3, 11 R3, (12-15 croce = hat), 16 Guida
BTN = {0: 0x130, 1: 0x131, 2: 0x133, 3: 0x134, 4: 0x136, 5: 0x137, 8: 0x13a, 9: 0x13b, 10: 0x13d, 11: 0x13e, 16: 0x13c}
ABS_X, ABS_Y, ABS_Z, ABS_RX, ABS_RY, ABS_RZ, ABS_HAT0X, ABS_HAT0Y = 0, 1, 2, 3, 4, 5, 0x10, 0x11
STICK = 32767


class VirtualPad:
    def __init__(self, name="EG PLAY Controller"):
        self.fd = os.open("/dev/uinput", os.O_WRONLY | os.O_NONBLOCK)
        try:
            fcntl.ioctl(self.fd, UI_SET_EVBIT, EV_KEY)
            fcntl.ioctl(self.fd, UI_SET_EVBIT, EV_ABS)
            for code in BTN.values():
                fcntl.ioctl(self.fd, UI_SET_KEYBIT, code)
            absmin, absmax, fuzz, flat = [0] * 64, [0] * 64, [0] * 64, [0] * 64
            for a in (ABS_X, ABS_Y, ABS_RX, ABS_RY):
                absmin[a], absmax[a], fuzz[a], flat[a] = -32768, STICK, 16, 128
            for a in (ABS_Z, ABS_RZ):
                absmin[a], absmax[a] = 0, 255
            for a in (ABS_HAT0X, ABS_HAT0Y):
                absmin[a], absmax[a] = -1, 1
            for a in (ABS_X, ABS_Y, ABS_Z, ABS_RX, ABS_RY, ABS_RZ, ABS_HAT0X, ABS_HAT0Y):
                fcntl.ioctl(self.fd, UI_SET_ABSBIT, a)
            # struct uinput_user_dev: nome, bus USB, Microsoft Xbox 360 (045e:028e), come il driver xpad
            dev = struct.pack("80sHHHHi", name.encode()[:79], 0x03, 0x045E, 0x028E, 0x0110, 0)
            dev += struct.pack("64i", *absmax) + struct.pack("64i", *absmin)
            dev += struct.pack("64i", *fuzz) + struct.pack("64i", *flat)
            os.write(self.fd, dev)
            fcntl.ioctl(self.fd, UI_DEV_CREATE)
        except OSError:
            os.close(self.fd)
            raise
        self.state = {}
        self.last = time.time()

    def _ev(self, typ, code, value):
        t = time.time()
        os.write(self.fd, struct.pack("llHHi", int(t), int((t % 1) * 1e6), typ, code, value))

    def _set(self, key, typ, code, value):
        if self.state.get(key) != value:
            self.state[key] = value
            self._ev(typ, code, value)

    def update(self, buttons, axes, lt=0.0, rt=0.0):
        """buttons: numero con un bit per pulsante (ordine standard); axes: [lx, ly, rx, ry] tra -1 e 1."""
        self.last = time.time()
        b = int(buttons) & 0x1FFFF
        for i, code in BTN.items():
            self._set("b%d" % i, EV_KEY, code, 1 if b >> i & 1 else 0)
        ax = (list(axes) + [0, 0, 0, 0])[:4]
        clamp = lambda v: max(-1.0, min(1.0, float(v)))
        for i, code in enumerate((ABS_X, ABS_Y, ABS_RX, ABS_RY)):
            self._set("a%d" % i, EV_ABS, code, int(clamp(ax[i]) * STICK))
        self._set("lt", EV_ABS, ABS_Z, int(max(0.0, min(1.0, float(lt or (b >> 6 & 1)))) * 255))
        self._set("rt", EV_ABS, ABS_RZ, int(max(0.0, min(1.0, float(rt or (b >> 7 & 1)))) * 255))
        self._set("hx", EV_ABS, ABS_HAT0X, (b >> 15 & 1) - (b >> 14 & 1))
        self._set("hy", EV_ABS, ABS_HAT0Y, (b >> 13 & 1) - (b >> 12 & 1))
        self._ev(EV_SYN, 0, 0)

    def release(self):
        """Tutto lasciato (telefono scollegato o fermo)."""
        try:
            self.update(0, [0, 0, 0, 0], 0, 0)
        except OSError:
            pass

    def close(self):
        try:
            self.release()
            fcntl.ioctl(self.fd, UI_DEV_DESTROY)
        except OSError:
            pass
        try:
            os.close(self.fd)
        except OSError:
            pass
