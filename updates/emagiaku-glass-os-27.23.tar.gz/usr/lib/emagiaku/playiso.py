"""EG PLAY OS (27.22) - link privato per scaricare la ISO.

Il link (Drive privato di EMAGIAKU) NON e' scritto in chiaro nel sistema: per ogni chiave PRO / EG PLAY
c'e' una copia cifrata che si apre solo con quella chiave (scrypt + flusso SHAKE-256 + HMAC, solo libreria
standard di Python). Chi non ha una chiave valida non puo' leggerlo.
Il file si crea sul PC di EMAGIAKU.TEAM con  cifra-link-iso.py  (legge CHIAVI-PRO-SEGRETE.txt).
"""
import base64
import hashlib
import hmac
import json
import os

FILE = "/usr/share/emagiaku/play/iso-link.json"
AAD = b"eg-play-iso-v1"


def _k(key, salt):
    return hashlib.scrypt(key.strip().upper().encode(), salt=salt, n=2 ** 14, r=8, p=1, dklen=64)


def _id(key):
    return hashlib.sha256(b"eg-play-iso-id:" + key.strip().upper().encode()).hexdigest()


def encrypt(key, link):
    salt, nonce = os.urandom(16), os.urandom(16)
    k = _k(key, salt)
    data = link.encode()
    stream = hashlib.shake_256(k[:32] + nonce).digest(len(data))
    ct = bytes(a ^ b for a, b in zip(data, stream))
    tag = hmac.new(k[32:], AAD + nonce + ct, hashlib.sha256).digest()
    b = lambda x: base64.b64encode(x).decode()
    return _id(key), {"salt": b(salt), "nonce": b(nonce), "ct": b(ct), "tag": b(tag)}


def decrypt(key, entry):
    d = {n: base64.b64decode(entry[n]) for n in ("salt", "nonce", "ct", "tag")}
    k = _k(key, d["salt"])
    if not hmac.compare_digest(hmac.new(k[32:], AAD + d["nonce"] + d["ct"], hashlib.sha256).digest(), d["tag"]):
        return None
    stream = hashlib.shake_256(k[:32] + d["nonce"]).digest(len(d["ct"]))
    link = bytes(a ^ b for a, b in zip(d["ct"], stream)).decode("utf-8", "replace")
    return link if link.startswith("https://") else None


def available():
    """C'e' il file dei link (cioe' la ISO e' gia' stata caricata)."""
    return os.path.isfile(FILE)


def link():
    """Link della ISO per la chiave attiva su questo PC, oppure None."""
    try:
        import common as c
        key = c.local_license_key()
        if not key or not c.has_play():
            return None
        with open(FILE, encoding="utf-8") as f:
            entry = json.load(f).get("voci", {}).get(_id(key))
        return decrypt(key, entry) if entry else None
    except Exception:
        return None
