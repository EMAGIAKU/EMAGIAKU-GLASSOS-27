// EG PLAY OS (27.25, Beta) - interfaccia da console. Tutto col controller (Gamepad API) o con frecce/Invio/Esc.
// Sezioni: Giochi, Media, Libreria, EG Store, Impostazioni (da console, senza finestre da PC).
"use strict";
(() => {
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const SEZ = ["home", "media", "libreria", "store", "cloud", "impostazioni"];
  const S = { sez: "home", giochi: [], extra: [], filtro: "Tutti", stato: {}, scelto: null, fuoco: null, finestra: null, ritorno: null };
  const esc = (t) => String(t == null ? "" : t).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

  async function api(path, body) {
    const opt = body ? { method: "POST", headers: { "Content-Type": "application/json", "X-EG-Play": "1" }, body: JSON.stringify(body) } : {};
    const r = await fetch(path, opt);
    return r.json();
  }
  async function azione(path, body, okMsg) {
    try {
      const r = await api(path, body || {});
      avviso(r.ok ? (r.messaggio || okMsg || "Fatto") : (r.errore || "Non riuscito"), 5000);
      return r;
    } catch (e) { avviso("Il servizio EG PLAY non risponde", 4000); return { ok: false }; }
  }

  // ------------------------------------------------------------------ copertine
  function tinta(nome) { let h = 0; for (const ch of String(nome)) h = (h * 31 + ch.charCodeAt(0)) % 360; return h; }
  function colore(nome) { const h = tinta(nome); return `linear-gradient(150deg, hsl(${h} 70% 45%), hsl(${(h + 50) % 360} 65% 22%))`; }
  function immagine(g, tipo) {
    const u = (x) => `url("${x.replace(/["\\]/g, "")}")`;
    if (g.immagine && typeof g.immagine === "string" && /^https:\/\//.test(g.immagine))
      return u(g.immagine) + (g.immagine2 && /^https:\/\//.test(g.immagine2) ? " center/cover, " + u(g.immagine2) : "");
    return g.immagine === true ? `url("/api/immagine?id=${encodeURIComponent(g.id)}&tipo=${tipo}")` : null;
  }

  function tessera(g, onClick, onFocus, etichetta) {
    const b = document.createElement("button");
    b.className = "gioco f";
    const img = immagine(g, "cover");
    b.style.background = img ? `${img} center/cover, ${colore(g.nome)}` : colore(g.nome);
    if (img) b.classList.add("con-img");
    const et = etichetta || (g.demo ? "DEMO" : "");
    b.innerHTML = `<span class="lettera"></span>${et ? '<span class="etich"></span>' : ""}<span class="nome"></span>`;
    b.querySelector(".lettera").textContent = String(g.nome).trim().charAt(0).toUpperCase();
    b.querySelector(".nome").textContent = g.nome;
    if (et) b.querySelector(".etich").textContent = et;
    b.addEventListener("click", onClick);
    if (onFocus) b.addEventListener("focus", onFocus);
    return b;
  }

  function quando(ts) {
    if (!ts) return "";
    const g = Math.floor((Date.now() / 1000 - ts) / 86400);
    return g <= 0 ? "Giocato oggi" : g === 1 ? "Giocato ieri" : `Giocato ${g} giorni fa`;
  }
  function peso(b) { return b ? (b / 1024 ** 3).toFixed(1).replace(".", ",") + " GB" : ""; }

  function scegli(g) {
    S.scelto = g;
    if (S.sez === "home") ["#b-gioca", "#b-dettagli"].forEach((s) => $(s).classList.remove("nascosta"));
    $("#h-nome").textContent = g.nome;
    $("#h-fonte").textContent = g.fonte;
    $("#h-info").textContent = [quando(g.ultimo), peso(g.dimensione)].filter(Boolean).join(" · ");
    const img = immagine(g, "hero");
    $("#sfondo").style.background = img ? `${img} center/cover, ${colore(g.nome)}` : `radial-gradient(1200px 700px at 75% 20%, hsl(${tinta(g.nome)} 60% 30%), transparent 65%), #07060c`;
  }

  // ------------------------------------------------------------------ GIOCHI (home)
  // 27.26: in Home SOLO i giochi installati o in download (+ EG Hub)
  function tesseraHub() {
    const b = document.createElement("button");
    b.className = "gioco f hub-tessera";
    b.innerHTML = '<span class="lettera">◉</span><span class="etich">EG HUB</span><span class="nome">Controller, amici, download e aggiornamenti</span>';
    b.addEventListener("click", apriHub);
    b.addEventListener("focus", () => {
      $("#h-fonte").textContent = "EG HUB";
      $("#h-nome").textContent = "Il tuo centro di controllo";
      $("#h-info").textContent = "Batteria dei controller, amici online, download e aggiornamenti dei giochi";
      ["#b-gioca", "#b-dettagli"].forEach((s) => $(s).classList.add("nascosta"));
    });
    return b;
  }
  function disegnaHome() {
    const rec = $("#recenti");
    const fuocoId = S.fuoco && rec.contains(S.fuoco) ? [...rec.children].indexOf(S.fuoco) : -1;
    rec.textContent = "";
    rec.appendChild(tesseraHub());
    if (!S.giochi.length) {
      const v = document.createElement("div");
      v.className = "vuoto";
      v.textContent = "Nessun gioco installato. In Libreria trovi i giochi dei tuoi account: premi Installa e qui vedi il download.";
      rec.appendChild(v);
      $("#h-fonte").textContent = "";
      $("#h-nome").textContent = "Benvenuto in EG PLAY";
      $("#h-info").textContent = "I tuoi giochi installati compariranno qui.";
      ["#b-gioca", "#b-dettagli"].forEach((s) => $(s).classList.add("nascosta"));
      return;
    }
    S.giochi.slice(0, 15).forEach((g) => {
      const giu = g.pronto === false && g.scarica != null;
      rec.appendChild(tessera(g, () => gioca(g), () => scegli(g), giu ? "DOWNLOAD " + (g.scarica || 0) + "%" : ""));
    });
    ["#b-gioca", "#b-dettagli"].forEach((s) => $(s).classList.remove("nascosta"));
    if (fuocoId >= 0 && rec.children[fuocoId]) metti(rec.children[fuocoId]);
    else if (!S.scelto) scegli(S.giochi[0]);
  }
  function disegnaTuttaHome() { disegnaHome(); }
  // mentre qualcosa si scarica la Home si aggiorna da sola (percentuale)
  setInterval(async () => {
    if (S.sez !== "home" || S.finestra) return;
    if (!S.giochi.some((g) => g.pronto === false) && Date.now() - (S.ultimoGiochi || 0) < 60000) return;
    try { S.giochi = await api("/api/giochi"); S.ultimoGiochi = Date.now(); disegnaHome(); } catch (e) { /* niente */ }
  }, 5000);

  let occupato = false;
  async function gioca(g) {
    if (!g || occupato) return;
    if (!S.stato.licenza) return apri("blocco");
    occupato = true;
    avviso(`Avvio di ${g.nome}…`);
    try {
      const r = await api("/api/avvia", { id: g.id });
      avviso(r.ok ? `${r.nome} si sta avviando` : r.errore || "Avvio non riuscito", 4000);
    } catch (e) { avviso("Il servizio EG PLAY non risponde", 4000); }
    occupato = false;
  }

  // ------------------------------------------------------------------ MEDIA
  async function disegnaMedia() {
    const box = $("#media");
    let list = [];
    try { list = await api("/api/media"); } catch (e) { /* niente */ }
    box.textContent = "";
    list.forEach((m) => {
      const b = document.createElement("button");
      b.className = "app-media f";
      b.style.background = `linear-gradient(150deg, ${m.colore}, #120d1e 85%)`;
      b.innerHTML = '<b></b><span></span>';
      b.querySelector("b").textContent = m.nome;
      b.querySelector("span").textContent = m.tipo + (m.pronto ? "" : " · da installare");
      b.addEventListener("click", () => azione("/api/media_apri", { id: m.id }));
      box.appendChild(b);
    });
  }

  // ------------------------------------------------------------------ LIBRERIA (installati + posseduti negli account)
  const FONTI = ["Tutti", "Installati", "Steam", "Epic Games", "GOG", "Ubisoft", "EA", "Rockstar", "Battle.net", "Amazon", "Flatpak"];
  const daFonte = (g, f) => f === "Tutti" || g.fonte === f || g.editore === f;
  function disegnaFiltri() {
    const box = $("#filtri");
    box.textContent = "";
    FONTI.forEach((f) => {
      const c = document.createElement("button");
      c.className = "chip f" + (f === S.filtro ? " sel" : "");
      c.textContent = f;
      c.addEventListener("click", () => { S.filtro = f; disegnaLibreria(); metti($$("#filtri .chip").find((x) => x.textContent === f)); });
      box.appendChild(c);
    });
    // 27.25: SINCRONIZZA importa tutti i giochi dei tuoi account (Steam, Epic, GOG, Amazon)
    const s = document.createElement("button");
    s.className = "chip f sinc" + (S.sincronizzato ? "" : " primo");
    s.textContent = S.sincronizzando ? "⟳ Sincronizzo…" : S.sincronizzato ? "⟳ Sincronizza di nuovo" : "⟳ SINCRONIZZA i tuoi giochi";
    s.addEventListener("click", sincronizza);
    box.appendChild(s);
  }
  async function sincronizza() {
    if (S.sincronizzando) return;
    S.sincronizzando = true;
    if (S.sez === "libreria") { disegnaFiltri(); metti($(".chip.sinc")); }
    avviso("Sincronizzo i giochi di Steam, Epic Games, GOG e Amazon…", 60000);
    let r;
    try { r = await api("/api/sincronizza", {}); } catch (e) { r = { ok: false, errore: "Il servizio EG PLAY non risponde" }; }
    S.sincronizzando = false;
    if (r.ok) {
      const per = Object.entries(r.per_negozio || {}).map(([k, v]) => k + " " + v).join(" · ");
      avviso((r.messaggio || "Fatto") + (per ? " (" + per + ")" : "") + ((r.avvisi || []).length ? ". " + r.avvisi.join(". ") : ""), 9000);
      await caricaExtra();
    } else avviso(r.errore || "Sincronizzazione non riuscita", 5000);
    if (S.sez === "libreria") { disegnaLibreria(); metti($(".chip.sinc")); }
  }
  async function caricaExtra() {
    try {
      const r = await api("/api/libreria_extra");
      S.extra = (r && r.giochi) || [];
      S.sincronizzato = (r && r.sincronizzato) || 0;
    } catch (e) { /* niente */ }
    if (S.sez === "libreria") disegnaLibreria();
  }
  function disegnaLibreria() {
    disegnaFiltri();
    const gr = $("#griglia");
    gr.textContent = "";
    const f = S.filtro;
    const inst = S.giochi.filter((g) => f === "Installati" || daFonte(g, f));
    const altri = f === "Installati" ? [] : S.extra.filter((g) => daFonte(g, f));
    inst.forEach((g) => gr.appendChild(tessera(g, () => gioca(g), null, g.pronto === false ? "DOWNLOAD " + (g.scarica || 0) + "%" : "")));
    altri.forEach((g) => gr.appendChild(tessera(g, () => dettagliLib(g), null, "DA INSTALLARE")));
    if (!inst.length && !altri.length) {
      gr.innerHTML = '<div class="vuoto">Niente qui. Collega i tuoi account (Impostazioni › Account di gioco) ed entra nei loro programmi: i tuoi giochi compaiono da soli.</div>';
    }
  }
  function dettagliLib(g) {
    finestraDettagli(g.nome, g, [["Negozio", g.fonte], ["Stato", "Nel tuo account, non installato"]],
      [["Installa", () => { chiudi(); azione("/api/lib_azione", { id: g.id }); }, true]]);
  }

  // ------------------------------------------------------------------ EG STORE
  // 27.25: se all'accensione la rete non c'è ancora (o Steam non risponde) il negozio riprova da solo
  let storeTimer = null, storeTentativi = 0;
  function barraCerca(box, testo) {
    const b = document.createElement("button");
    b.className = "cerca f";
    b.innerHTML = '<span class="lente">🔍</span><span class="c-testo"></span>';
    b.querySelector(".c-testo").textContent = testo || "Cerca in tutti i negozi: Steam, GOG, Epic Games, Battle.net…";
    b.addEventListener("click", cercaNegozi);
    box.appendChild(b);
    return b;
  }
  function righeStore(box, sezioni) {
    sezioni.forEach((sz) => {
      const t = document.createElement("div");
      t.className = "riga-titolo";
      t.textContent = sz.titolo;
      const row = document.createElement("div");
      row.className = "riga store-riga";
      sz.giochi.forEach((g) => {
        const b = document.createElement("button");
        b.className = "offerta f";
        const img = immagine(g, "cover");
        b.style.background = img ? `${img} center/cover, ${colore(g.nome)}` : colore(g.nome);
        b.innerHTML = '<span class="o-nome"></span><span class="o-prezzo"></span>' + (g.sconto && g.sconto < 100 ? '<span class="o-sconto"></span>' : "");
        b.querySelector(".o-nome").textContent = g.nome;
        b.querySelector(".o-prezzo").textContent = g.prezzo;
        if (g.sconto && g.sconto < 100) b.querySelector(".o-sconto").textContent = "-" + g.sconto + "%";
        b.addEventListener("click", () => dettagliStore(g));
        row.appendChild(b);
      });
      box.append(t, row);
    });
  }
  async function disegnaStore() {
    const box = $("#store");
    clearTimeout(storeTimer);
    let r;
    try { r = await api("/api/store"); } catch (e) { r = { sezioni: [], rete: false }; }
    if (S.sez === "store" && S.cercando) return;           // nel frattempo si sta guardando una ricerca
    const fuocoPrima = S.fuoco && box.contains(S.fuoco);
    box.textContent = "";
    barraCerca(box);
    const sezioni = r.sezioni || [];
    const manca = !sezioni.length || (r.mancanti || []).includes("Steam");
    if (manca) {
      const v = document.createElement("div");
      v.className = "vuoto";
      v.textContent = r.rete === false ? "Non sei connesso a Internet: collegati in Impostazioni › Rete. Il negozio si carica da solo appena c'è la rete."
        : sezioni.length ? "Steam non risponde ancora: riprovo tra poco…" : "Carico i negozi…";
      box.appendChild(v);
    }
    righeStore(box, sezioni);
    if (manca && storeTentativi++ < 60) storeTimer = setTimeout(() => { if (S.sez === "store" && !S.finestra) disegnaStore(); else S.storeFatto = false; }, 8000);
    if (!manca) storeTentativi = 0;
    if (fuocoPrima && S.sez === "store") metti($(".f", box));
    const nota = document.createElement("p");
    nota.className = "nota-sez";
    nota.textContent = "Gli acquisti si fanno nel negozio del gioco (Steam, Epic Games…) con il tuo account collegato: EMAGIAKU non vede i tuoi pagamenti.";
    box.appendChild(nota);
  }
  function dettagliStore(g) {
    const gratis = /^Gratis/.test(g.prezzo);
    const etichetta = g.id.startsWith("flathub:") ? "Installa gratis" : g.id.startsWith("epic:") ? "Riscatta su Epic Games" :
      g.id.startsWith("gog:") ? "Apri su GOG" : g.id.startsWith("web:") ? "Apri " + g.negozio : gratis ? "Ottieni su Steam" : "Compra su Steam";
    const info = [["Negozio", g.negozio], ["Prezzo", g.prezzo + (g.prima ? " (prima " + g.prima + ")" : "")]];
    if (g.descrizione) info.push(["Info", g.descrizione]);
    if (g.id.startsWith("web:")) info.push(["Comandi", "Levetta sinistra = cursore, A = clic, levetta destra = scorri, tasto EG = torna"]);
    finestraDettagli(g.nome, g, info, [[etichetta, () => { chiudi(); azione("/api/store_azione", { id: g.id }); }, true]]);
  }

  // ricerca in tutti i negozi (27.25)
  async function cercaNegozi() {
    const q = await tastiera("Cerca un gioco in tutti i negozi", S.ultimaRicerca || "", false);
    if (!q) return;
    if (q.length < 2) { avviso("Scrivi almeno 2 lettere", 3000); return; }
    S.ultimaRicerca = q;
    S.cercando = true;
    clearTimeout(storeTimer);
    const box = $("#store");
    box.textContent = "";
    const indietro = document.createElement("button");
    indietro.className = "pulsante f";
    indietro.textContent = "← Torna al negozio";
    indietro.addEventListener("click", () => { S.cercando = false; disegnaStore().then(() => metti($(".f", box))); });
    const barra = barraCerca(box, "Cerca: " + q);
    box.insertBefore(indietro, barra);
    const v = document.createElement("div");
    v.className = "vuoto";
    v.textContent = "Cerco “" + q + "” su Steam, GOG, Flathub, Battle.net…";
    box.appendChild(v);
    metti(barra);
    let r;
    try { r = await api("/api/cerca?q=" + encodeURIComponent(q)); } catch (e) { r = { ok: false, errore: "Il servizio EG PLAY non risponde" }; }
    if (!S.cercando || S.ultimaRicerca !== q) return;
    if (!r.ok) { v.textContent = r.errore || "Ricerca non riuscita"; return; }
    const trovati = (r.sezioni || []).filter((s) => s.titolo !== "Negli altri negozi").reduce((n, s) => n + s.giochi.length, 0);
    v.textContent = trovati ? trovati + " risultati" + (r.non_raggiunti && r.non_raggiunti.length ? " (non raggiunti: " + r.non_raggiunti.join(", ") + ")" : "")
      : "Nessun gioco trovato su Steam, GOG e Flathub" + (r.non_raggiunti && r.non_raggiunti.length ? " (non raggiunti: " + r.non_raggiunti.join(", ") + ": controlla la rete)" : "") + ". Prova negli altri negozi qui sotto.";
    righeStore(box, r.sezioni || []);
    metti($(".offerta", box) || barra);
  }

  // ------------------------------------------------------------------ finestra dettagli (giochi, store, libreria)
  function finestraDettagli(nome, g, righe, azioni) {
    $("#d-nome").textContent = nome;
    const img = immagine(g, "hero");
    $("#d-img").style.background = img ? `${img} center/cover` : colore(nome);
    const dl = $("#d-info");
    dl.textContent = "";
    righe.forEach(([k, v]) => { const dt = document.createElement("dt"); dt.textContent = k; const dd = document.createElement("dd"); dd.textContent = v; dl.append(dt, dd); });
    const box = $("#d-azioni");
    box.textContent = "";
    azioni.concat([["Chiudi", chiudi, false]]).forEach(([t, fn, prim]) => {
      const b = document.createElement("button");
      b.className = "pulsante f" + (prim ? " primario" : "");
      b.textContent = t;
      b.addEventListener("click", fn);
      box.appendChild(b);
    });
    apri("dettagli");
  }
  function dettagliGioco(g) {
    if (!g) return;
    finestraDettagli(g.nome, g, [["Fonte", g.fonte], ["Ultima partita", quando(g.ultimo) || "—"], ["Spazio", peso(g.dimensione) || "—"],
      ["Stato", g.demo ? "Gioco di esempio (demo)" : g.pronto ? "Installato" : "Download non finito"]],
    [["▶ Gioca", () => { chiudi(); gioca(g); }, true]]);
  }

  // ------------------------------------------------------------------ IMPOSTAZIONI (da console)
  const IMP = {};
  function pannello(html) { const p = $("#imp-pannello"); p.innerHTML = html; return p; }
  function bottone(testo, fn, prim) {
    const b = document.createElement("button");
    b.className = "pulsante f" + (prim ? " primario" : "");
    b.textContent = testo;
    b.addEventListener("click", fn);
    return b;
  }

  IMP.account = async () => {
    const p = pannello('<h2>Account EMAGIAKU</h2><p class="imp-testo">Carico…</p><div class="imp-azioni"></div><div id="qr" class="qr"></div>');
    const a = await api("/api/account").catch(() => ({}));
    const az = $(".imp-azioni", p);
    if (a.entrato) {
      $(".imp-testo", p).textContent = "Sei entrato come " + (a.nome ? a.nome + " · " : "") + a.email + ". Licenze e account di gioco arrivano da qui.";
      az.appendChild(bottone("Esci dall'account", async () => { await azione("/api/esci_account", {}, "Sei uscito"); IMP.account(); }));
    } else {
      $(".imp-testo", p).textContent = "Entra con l'Account EMAGIAKU: ritrovi la licenza e i tuoi account di gioco.";
      az.appendChild(bottone("Entra con il telefono (QR)", accessoQR, true));
      az.appendChild(bottone("Entra con email e password", accessoEmail));
    }
  };
  let qrTimer = null;
  async function accessoQR() {
    const r = await api("/api/qr_inizia", {}).catch(() => ({}));
    if (!r.ok) { avviso(r.errore || "Non riuscito", 4000); return; }
    $("#qr").innerHTML = '<img alt="QR"><p>Inquadra il QR con il telefono e sblocca la passkey del tuo Account EMAGIAKU.</p>';
    $("#qr img").src = r.qr;
    clearInterval(qrTimer);
    let n = 0;
    qrTimer = setInterval(async () => {
      if (++n > 100 || S.sez !== "impostazioni") { clearInterval(qrTimer); return; }
      const c = await api("/api/qr_controlla", {}).catch(() => ({}));
      if (c.fatto) { clearInterval(qrTimer); avviso("Entrato come " + c.email, 4000); IMP.account(); caricaStato(); }
    }, 3000);
  }
  async function accessoEmail() {
    const email = await tastiera("Email dell'Account EMAGIAKU", "", false);
    if (!email) return;
    const pw = await tastiera("Password", "", true);
    if (!pw) return;
    const r = await azione("/api/accedi", { email, password: pw }, "Entrato");
    if (r.ok) { IMP.account(); caricaStato(); }
  }

  // 27.26: si collegano QUI, direttamente (pagina di accesso del negozio + tastiera a schermo), senza aprire altre app
  IMP.giochi = async () => {
    const p = pannello('<h2>Account di gioco</h2><p class="imp-testo">Controllo gli account…</p><div class="imp-lista negozi"></div>');
    const r = await api("/api/negozi").catch(() => ({}));
    const box = $(".imp-lista", p);
    if (!r.ok) { $(".imp-testo", p).textContent = "Non disponibile adesso."; return; }
    $(".imp-testo", p).textContent = "Premi su un negozio per collegarlo: si apre la sua pagina di accesso ufficiale (la password la vede solo il negozio). Poi i giochi arrivano in Libreria.";
    r.negozi.forEach((n) => {
      const st = n.collegato === true ? "✓ collegato" : n.collegato === false ? "collega" : "info";
      const b = bottone(n.nome + " · " + st, async () => {
        if (n.collegato === null) { avviso(n.nota, 6000); return; }
        if (n.collegato && !confirmNegozio(n)) return;
        const x = await azione("/api/collega", { id: n.id });
        if (x.ok) setTimeout(() => { if (S.sez === "impostazioni") IMP.giochi(); }, 20000);
      }, n.collegato === false);
      b.classList.add("inst-scelta");
      if (n.nota) { const s = document.createElement("small"); s.textContent = n.nota; b.appendChild(s); }
      box.appendChild(b);
    });
    box.appendChild(bottone("⟳ Sincronizza i giochi in Libreria", sincronizza));
  };
  function confirmNegozio(n) { avviso(n.nome + " è già collegato: lo ricollego (puoi cambiare account)", 4000); return true; }

  IMP.rete = async () => {
    const p = pannello('<h2>Rete</h2><p class="imp-testo">Cerco le reti Wi-Fi…</p><div class="imp-lista"></div>');
    const r = await api("/api/wifi").catch(() => ({}));
    if (!r.ok) { $(".imp-testo", p).textContent = r.errore || "Non disponibile"; return; }
    $(".imp-testo", p).textContent = r.stato && r.stato.startsWith("connected") ? "Connesso a Internet." : "Non connesso: scegli una rete.";
    const box = $(".imp-lista", p);
    r.reti.forEach((w) => {
      box.appendChild(bottone((w.attiva ? "✓ " : "") + w.ssid + " · " + w.segnale + "%" + (w.protetta ? " 🔒" : ""), async () => {
        if (w.attiva) return;
        const pw = w.protetta ? await tastiera("Password di " + w.ssid, "", true) : "";
        if (w.protetta && !pw) return;
        avviso("Mi collego a " + w.ssid + "…", 20000);
        const x = await azione("/api/wifi_connetti", { ssid: w.ssid, password: pw }, "Connesso a " + w.ssid);
        if (x.ok) IMP.rete();
      }));
    });
    box.appendChild(bottone("Cerca di nuovo", IMP.rete));
  };

  IMP.audio = async () => {
    const p = pannello('<h2>Audio</h2><p class="imp-testo"></p><div class="imp-azioni"></div>');
    const r = await api("/api/volume").catch(() => ({}));
    let v = r.volume || 0;
    const t = $(".imp-testo", p);
    const show = () => { t.innerHTML = 'Volume: <b>' + v + '%</b><div class="barra-vol"><i style="width:' + v + '%"></i></div>'; };
    show();
    const set = async (nv) => { v = Math.max(0, Math.min(100, nv)); show(); await api("/api/volume", { v }).catch(() => {}); };
    const az = $(".imp-azioni", p);
    az.append(bottone("− Abbassa", () => set(v - 10)), bottone("+ Alza", () => set(v + 10)), bottone("Muto", () => set(0)));
  };

  IMP.controller = () => {
    const p = pannello(`<h2>Controller</h2>
      <p class="imp-testo">PlayStation, Xbox e Nintendo: con il cavo funzionano subito. Senza fili: mettilo in abbinamento e premi Cerca.</p>
      <ul id="pad-lista" class="pad-lista"></ul><div class="imp-azioni"></div><div id="bt-lista" class="imp-lista"></div>
      <p class="nota-sez"><b>PlayStation</b>: tieni premuti PS e Share/Create finché la luce lampeggia. <b>Xbox</b>: tasto di associazione in alto finché il logo lampeggia veloce. <b>Nintendo</b>: tasto di sincronizzazione finché le luci scorrono.</p>`);
    $(".imp-azioni", p).appendChild(bottone("Cerca controller Bluetooth", cercaBT, true));
    aggiornaPad();
  };

  IMP.sistema = async () => {
    const p = pannello('<h2>Sistema e aggiornamenti</h2><dl class="imp-dl"></dl><p class="imp-testo">Controllo gli aggiornamenti…</p><div class="imp-azioni"></div>');
    const s = await api("/api/sistema").catch(() => ({}));
    const dl = $(".imp-dl", p);
    [["Sistema", S.stato.variante === "play" ? "EG PLAY OS Beta" : "EMAGIAKU GLASS OS " + (s.versione || "")],["Spazio", s.spazio || "—"],
     ["Edizione", S.stato.edizione || "—"]].forEach(([k, v]) => { const dt = document.createElement("dt"); dt.textContent = k; const dd = document.createElement("dd"); dd.textContent = v; dl.append(dt, dd); });
    const u = await api("/api/update").catch(() => ({}));
    const t = $(".imp-testo", p);
    if (!u.ok) { t.textContent = u.errore || "Aggiornamenti non raggiungibili"; return; }
    if (!u.nuovo) { t.textContent = "Il sistema è aggiornato."; return; }
    t.textContent = S.stato.variante === "play" ? "C'è un aggiornamento di EG PLAY OS Beta." : "C'è la versione " + u.versione + ".";
    $(".imp-azioni", p).appendChild(bottone("Aggiorna ora", async () => {
      await azione("/api/update_installa", {});
      const timer = setInterval(async () => {
        const st = await api("/api/update_stato").catch(() => ({}));
        t.textContent = "Aggiornamento: " + (st.stato || "") + (st.pct ? " (" + st.pct + "%)" : "");
        if (st.stato && st.stato !== "in corso") clearInterval(timer);
      }, 2000);
    }, true));
  };

  IMP.licenza = () => {
    const p = pannello('<h2>Licenza</h2><p class="imp-testo"></p><div class="imp-azioni"></div>');
    $(".imp-testo", p).textContent = S.stato.licenza ? "EG PLAY è attivo (" + (S.stato.edizione || "") + ")." :
      "Serve EG GLASS OS PRO oppure una chiave EG PLAY (15 €). Se la chiave è già nel tuo Account EMAGIAKU, arriva da sola.";
    $(".imp-azioni", p).appendChild(bottone("Attiva una chiave", attivaChiave, !S.stato.licenza));
  };
  async function attivaChiave() {
    const k = await tastiera("Chiave (EGPLY-…, EGPRO-…, EGPLS-…)", "", false, true);
    if (!k) return;
    const r = await azione("/api/chiave", { chiave: k });
    if (r.ok) { await caricaStato(); if (S.sez === "impostazioni") IMP.licenza(); }
  }

  IMP.console = () => {
    const p = pannello('<h2>Accensione</h2><p class="imp-testo"></p><div class="imp-azioni"></div>');
    const st = S.stato;
    $(".imp-testo", p).textContent = st.live ? "Stai provando EG PLAY OS dalla chiavetta. Installalo sul disco: all'accensione partirà direttamente qui." :
      st.sessione ? "EG PLAY OS è acceso." : "EG PLAY è aperto sul desktop di EMAGIAKU GLASS OS.";
    const az = $(".imp-azioni", p);
    if (st.live || st.demo) az.appendChild(bottone("Installa sul disco", () => (st.installatore || st.demo ? apriInstallazione() : apriCosa("installa")), true));
    if (st.sessione) {
      az.append(bottone("Riavvia", () => azione("/api/riavvia", {})), bottone("Spegni", () => azione("/api/spegni", {})));
      if (st.variante !== "play") az.appendChild(bottone("Passa al desktop", () => apriCosa("desktop")));
    } else {
      if (!st.pronto) az.appendChild(bottone("Prepara EG PLAY OS su questo PC", () => apriCosa("prepara"), true));
      az.appendChild(bottone(st.avvio_console ? "All'accensione: torna al desktop" : "All'accensione: entra in EG PLAY",
        () => apriCosa(st.avvio_console ? "avvio-desktop" : "avvio-console")));
      az.appendChild(bottone("Esci da EG PLAY", () => apriCosa("esci")));
    }
  };

  function apriImp(nome) {
    $$("#imp-menu .voce").forEach((v) => v.classList.toggle("sel", v.dataset.imp === nome));
    (IMP[nome] || IMP.account)();
  }
  $$("#imp-menu .voce").forEach((v) => {
    v.addEventListener("click", () => { apriImp(v.dataset.imp); setTimeout(() => metti($(".f", $("#imp-pannello")) || v), 400); });
    v.addEventListener("focus", () => apriImp(v.dataset.imp));
  });

  const MSG = { esci: "Chiusura di EG PLAY…", desktop: "Torno alla schermata di accesso…", installa: "Apertura dell'installazione (serve mouse o tastiera)…",
    prepara: "EG PLAY OS pronto", "avvio-console": "All'accensione entrerai in EG PLAY", "avvio-desktop": "All'accensione: schermata di accesso" };
  async function apriCosa(cosa) {
    if (["prepara", "avvio-console", "avvio-desktop"].includes(cosa)) avviso("Serve la password di amministratore…", 6000);
    try {
      const r = await api("/api/apri", { cosa });
      avviso(r.ok ? (MSG[cosa] || "Fatto") : (r.errore || "Non riuscito"), 4000);
      if (r.ok) await caricaStato();
      if (S.sez === "impostazioni") IMP.console();
    } catch (e) { avviso("Il servizio EG PLAY non risponde", 3000); }
  }

  // ------------------------------------------------------------------ INSTALLAZIONE SUL DISCO col controller (27.25)
  const GB = 1024 ** 3;
  const I = { passo: "dischi", dati: null, disco: null, modo: "", spazio: null, part: null, gb: 64, utente: "", password: "",
    predefinito: "play", timer: null, conferma: false };
  const gb = (b) => (b / GB >= 100 ? Math.round(b / GB) : (b / GB).toFixed(1).replace(".", ",")) + " GB";
  function instPannello(titolo, testo) {
    const p = $("#inst-corpo");
    p.textContent = "";
    $("#inst-titolo").textContent = titolo;
    const t = document.createElement("p");
    t.textContent = testo || "";
    p.appendChild(t);
    return p;
  }
  function instBottone(p, testo, fn, prim, info) {
    const b = bottone(testo, fn, prim);
    b.classList.add("inst-scelta");
    if (info) { const s = document.createElement("small"); s.textContent = info; b.appendChild(s); }
    p.appendChild(b);
    return b;
  }
  function barraDisco(d) {
    // disegno del disco: partizioni e spazio libero in proporzione
    const bar = document.createElement("div");
    bar.className = "barra-disco";
    const pezzi = d.partizioni.map((x) => ({ t: x.os || x.fstype || "partizione", b: x.size, cls: x.esp ? "esp" : x.os ? "os" : "" }))
      .concat(d.liberi.map((l) => ({ t: "libero", b: l.byte, cls: "libero" })));
    pezzi.forEach((x) => {
      const i = document.createElement("i");
      i.className = x.cls;
      i.style.flex = String(Math.max(x.b / d.size, 0.03));
      i.textContent = x.b / d.size > 0.08 ? x.t + " · " + gb(x.b) : "";
      bar.appendChild(i);
    });
    return bar;
  }
  async function apriInstallazione() {
    I.passo = "dischi"; I.dati = null; I.conferma = false;
    instPannello("Installa EG PLAY OS", "Leggo i dischi e i sistemi che ci sono…");
    apri("inst");
    const r = await api("/api/installa/elenco").catch(() => ({ ok: false, errore: "Il servizio EG PLAY non risponde" }));
    I.dati = r;
    instDisegna();
  }
  function instDisegna() {
    clearInterval(I.timer);
    const r = I.dati || {};
    if (I.passo === "dischi") {
      if (!r.ok) {
        const p = instPannello("Installa EG PLAY OS", r.errore || "Non disponibile");
        instBottone(p, "Chiudi", chiudi);
        return metti($("#inst .f"));
      }
      const dischi = r.dischi.filter((d) => !d.live);
      const p = instPannello("Dove installo EG PLAY OS?", dischi.length ? "Scegli il disco. Al passo dopo vedi le partizioni: puoi metterlo ACCANTO a EMAGIAKU GLASS OS 27 o a Windows."
        : "Nessun disco trovato (a parte la chiavetta).");
      if (!r.uefi) p.appendChild(Object.assign(document.createElement("p"), { className: "attenzione", textContent: "Questo PC è partito in modalità BIOS vecchia: per installare riavvia la chiavetta in modalità UEFI." }));
      dischi.forEach((d) => {
        const sist = d.partizioni.map((x) => x.os).filter((o) => o && !/^Avvio/.test(o));
        instBottone(p, (d.rimovibile ? "🔌 " : "💽 ") + d.modello + " · " + gb(d.size), () => { I.disco = d; I.passo = "modo"; instDisegna(); }, false,
          d.path + (sist.length ? " · c'è: " + [...new Set(sist)].join(", ") : d.partizioni.length ? "" : " · vuoto"));
      });
      instBottone(p, "Annulla", chiudi);
      return metti($("#inst .f"));
    }
    const d = I.disco;
    if (I.passo === "modo") {
      const p = instPannello(d.modello + " · " + gb(d.size), "Partizioni del disco " + d.path + ":");
      p.appendChild(barraDisco(d));
      const ul = document.createElement("ul");
      ul.className = "lista-part";
      d.partizioni.forEach((x) => { const li = document.createElement("li"); li.textContent = x.path + " · " + gb(x.size) + " · " + (x.os || x.fstype || "sconosciuta") + (x.label ? " (" + x.label + ")" : "") + (x.usato != null ? " · usati " + gb(x.usato) : ""); ul.appendChild(li); });
      d.liberi.forEach((l) => { const li = document.createElement("li"); li.textContent = "Spazio libero · " + gb(l.byte); ul.appendChild(li); });
      p.appendChild(ul);
      const gpt = d.tabella === "gpt";
      d.liberi.filter((l) => l.byte >= 20 * GB).forEach((l) => instBottone(p, "Nello spazio libero (" + gb(l.byte) + ")", () => {
        I.modo = "libero"; I.spazio = l.inizio; I.gbScelti = l.byte; I.passo = "utente"; instDisegna(); }, true, gpt ? "Gli altri sistemi restano: scegli all'accensione" : "Serve un disco GPT"));
      d.partizioni.filter((x) => x.restringibile).forEach((x) => instBottone(p, "Accanto a " + (x.os || "Linux") + " (" + x.path + ")", () => {
        I.modo = "accanto"; I.part = x; I.gb = Math.min(Math.max(64, 20), Math.floor(x.max_libera / GB)); I.passo = "spazio"; instDisegna(); }, true,
        "Restringo " + x.path + " (usati " + gb(x.usato) + ") e uso lo spazio liberato: " + (x.os || "l'altro sistema") + " resta"));
      d.partizioni.filter((x) => x.fstype === "ntfs" && !x.esp).slice(0, 1).forEach(() => {
        const n = document.createElement("p");
        n.className = "nota-sez";
        n.textContent = "Windows: prima fai spazio da Windows (Gestione disco › Riduci volume), poi qui scegli «Nello spazio libero».";
        p.appendChild(n);
      });
      instBottone(p, "Usa tutto il disco", () => { I.modo = "intero"; I.passo = "utente"; I.gbScelti = d.size; instDisegna(); }, false, "⚠ CANCELLA tutto quello che c'è su " + d.path);
      instBottone(p, "← Indietro", () => { I.passo = "dischi"; instDisegna(); });
      return metti($("#inst .inst-scelta"));
    }
    if (I.passo === "spazio") {
      const x = I.part, max = Math.floor(x.max_libera / GB);
      const p = instPannello("Quanto spazio a EG PLAY OS?", "Il resto rimane a " + (x.os || "l'altro sistema") + ". EG PLAY OS occupa circa 10 GB, il resto è per i giochi.");
      const v = document.createElement("div");
      v.className = "inst-gb";
      const mostra = () => { v.innerHTML = "<b>" + I.gb + " GB</b> a EG PLAY OS · <b>" + gb(x.size - I.gb * GB) + "</b> restano a " + esc(x.os || x.path); };
      mostra();
      p.appendChild(v);
      const az = document.createElement("div");
      az.className = "imp-azioni";
      [["− 10 GB", -10], ["+ 10 GB", 10], ["+ 50 GB", 50]].forEach(([t, n]) => az.appendChild(bottone(t, () => { I.gb = Math.max(20, Math.min(max, I.gb + n)); mostra(); })));
      p.appendChild(az);
      instBottone(p, "Avanti", () => { I.gbScelti = I.gb * GB; I.passo = "utente"; instDisegna(); }, true, "Da 20 a " + max + " GB");
      instBottone(p, "← Indietro", () => { I.passo = "modo"; instDisegna(); });
      return metti($("#inst .f"));
    }
    if (I.passo === "utente") {
      const p = instPannello("Il giocatore", "Nome e password del giocatore della console (la password serve per gli aggiornamenti).");
      instBottone(p, "Nome: " + (I.utente || "scegli…"), async () => {
        const n = await tastiera("Nome del giocatore (minuscole, senza spazi)", I.utente, false);
        if (n) I.utente = n.toLowerCase().replace(/[^a-z0-9_-]/g, "").replace(/^[^a-z_]+/, "").slice(0, 32);
        apri("inst"); instDisegna();
      }, !I.utente);
      instBottone(p, "Password: " + (I.password ? "•".repeat(I.password.length) : "scegli…"), async () => {
        const a = await tastiera("Password (almeno 4 caratteri)", "", true);
        if (a) {
          const b = await tastiera("Scrivi di nuovo la password", "", true);
          if (a !== b) avviso("Le due password non sono uguali", 4000);
          else if (a.length < 4) avviso("Almeno 4 caratteri", 4000);
          else I.password = a;
        }
        apri("inst"); instDisegna();
      }, !!I.utente && !I.password);
      if (I.modo !== "intero") instBottone(p, "All'accensione parte: " + (I.predefinito === "play" ? "EG PLAY OS" : "l'altro sistema"), () => {
        I.predefinito = I.predefinito === "play" ? "altro" : "play"; instDisegna(); }, false, "Nel menu di avvio puoi sempre scegliere l'altro (5 secondi)");
      if (I.utente && I.password) instBottone(p, "Avanti", () => { I.passo = "riepilogo"; I.conferma = false; instDisegna(); }, true);
      instBottone(p, "← Indietro", () => { I.passo = I.modo === "accanto" ? "spazio" : "modo"; instDisegna(); });
      if (I.utente && I.password) return metti($$("#inst .inst-scelta").find((b) => b.textContent.startsWith("Avanti")));
      return metti($("#inst .pulsante.primario") || $("#inst .f"));
    }
    if (I.passo === "riepilogo") {
      const cosa = I.modo === "intero" ? "Cancello TUTTO il disco " + d.path + " e installo EG PLAY OS." :
        I.modo === "accanto" ? "Restringo " + I.part.path + " (" + (I.part.os || "Linux") + ") di " + I.gb + " GB e ci metto EG PLAY OS. " + (I.part.os || "L'altro sistema") + " resta com'è." :
        "Installo EG PLAY OS nello spazio libero di " + d.path + " (" + gb(I.gbScelti) + "). Gli altri sistemi restano.";
      const p = instPannello(I.conferma ? "Sicuro?" : "Riepilogo", cosa);
      const dl = document.createElement("dl");
      [["Disco", d.modello + " (" + d.path + ")"], ["Spazio a EG PLAY OS", gb(I.gbScelti || 0)], ["Giocatore", I.utente],
       ["All'accensione", I.modo === "intero" || I.predefinito === "play" ? "EG PLAY OS" : "l'altro sistema (EG PLAY OS nel menu)"]]
        .forEach(([k, v]) => { const dt = document.createElement("dt"); dt.textContent = k; const dd = document.createElement("dd"); dd.textContent = v; dl.append(dt, dd); });
      p.appendChild(dl);
      if (I.modo !== "intero") p.appendChild(Object.assign(document.createElement("p"), { className: "nota-sez", textContent: "Consiglio: se sull'altro sistema hai file importanti, fanne una copia prima. Il PC deve restare acceso e collegato alla corrente." }));
      if (!I.conferma) instBottone(p, "Installa", () => { I.conferma = true; instDisegna(); }, true);
      else instBottone(p, I.modo === "intero" ? "Sì, cancella e installa" : "Sì, installa", () => instAvvia(false), true);
      instBottone(p, "Prova (simulazione, non scrive niente)", () => instAvvia(true));
      instBottone(p, "← Indietro", () => { I.passo = "utente"; I.conferma = false; instDisegna(); });
      return metti($("#inst .f"));
    }
    if (I.passo === "lavoro") {
      const p = instPannello("Installazione di EG PLAY OS", "Non spegnere la console e non togliere la chiavetta.");
      const bar = document.createElement("div");
      bar.className = "barra-vol";
      bar.innerHTML = "<i></i>";
      const t = document.createElement("p");
      const log = document.createElement("pre");
      log.className = "inst-log";
      p.append(bar, t, log);
      const az = document.createElement("div");
      az.className = "imp-azioni";
      p.appendChild(az);
      const giro = async () => {
        const s = await api("/api/installa/stato").catch(() => null);
        if (!s) return;
        $("i", bar).style.width = (s.pct || 0) + "%";
        t.textContent = (s.pct || 0) + "% · " + (s.passo || "");
        log.textContent = (s.righe || []).slice(-6).join("\n");
        if (s.stato === "fatto" || s.stato === "errore") {
          clearInterval(I.timer);
          az.textContent = "";
          if (s.stato === "fatto" && !I.prova) {
            t.textContent = "Fatto! Togli la chiavetta e riavvia: EG PLAY OS parte dal disco.";
            az.appendChild(bottone("Riavvia ora", () => azione("/api/riavvia", {}), true));
          } else if (s.stato === "fatto") {
            t.textContent = "Simulazione riuscita: non è stato scritto niente. Ora puoi installare davvero.";
            az.appendChild(bottone("← Torna al riepilogo", () => { I.passo = "riepilogo"; I.conferma = false; instDisegna(); }, true));
          } else {
            t.textContent = "Non riuscita: " + (s.passo || "errore");
            az.appendChild(bottone("← Torna ai dischi", () => apriInstallazione(), true));
          }
          az.appendChild(bottone("Chiudi", chiudi));
          metti($(".f", az));
        }
      };
      giro();
      I.timer = setInterval(giro, 1500);
    }
  }
  async function instAvvia(prova) {
    const d = I.disco;
    const corpo = { modo: I.modo, disco: d.path, conferma: d.path, utente: I.utente, password: I.password, nome: "EG-PLAY",
      predefinito: I.predefinito, prova: !!prova };
    if (I.modo === "libero") corpo.spazio = I.spazio;
    if (I.modo === "accanto") { corpo.partizione = I.part.path; corpo.gb = I.gb; }
    const r = await azione("/api/installa/avvia", corpo, prova ? "Simulazione avviata" : "Installazione avviata");
    if (!r.ok) return;
    I.prova = !!prova;
    I.passo = "lavoro";
    instDisegna();
  }

  // ------------------------------------------------------------------ EG HUB (27.26): il centro di controllo della console
  let hubTimer = null;
  function scheda(titolo, righe, vuoto) {
    const c = document.createElement("div");
    c.className = "hub-scheda";
    const h = document.createElement("h3");
    h.textContent = titolo;
    c.appendChild(h);
    if (!righe.length) { const p = document.createElement("p"); p.className = "hub-vuoto"; p.textContent = vuoto; c.appendChild(p); }
    righe.forEach(([a, b, pct]) => {
      const r = document.createElement("div");
      r.className = "hub-riga";
      const s1 = document.createElement("span"); s1.textContent = a;
      const s2 = document.createElement("b"); s2.textContent = b || "";
      r.append(s1, s2);
      c.appendChild(r);
      if (pct != null) { const bar = document.createElement("div"); bar.className = "barra-vol"; bar.innerHTML = '<i style="width:' + Math.max(0, Math.min(100, pct)) + '%"></i>'; c.appendChild(bar); }
    });
    return c;
  }
  async function disegnaHub() {
    const box = $("#hub-corpo");
    const h = await api("/api/hub").catch(() => null);
    if (!h || !h.ok) { box.innerHTML = '<p class="hub-vuoto">EG Hub non risponde.</p>'; return; }
    box.textContent = "";
    const pads = (h.controller.batterie || []).map((b) => [b.nome, (b.carica != null ? b.carica + "%" : b.livello || "") + (b.stato ? " · " + b.stato : ""), b.carica]);
    (h.controller.collegati || []).forEach((n) => { if (!pads.some((p) => n.includes(p[0]) || p[0].includes(n))) pads.push([n, "collegato", null]); });
    box.appendChild(scheda("🎮 Controller", pads, "Nessun controller collegato"));
    const am = h.amici || {};
    box.appendChild(scheda("👥 Amici online" + (am.ok ? " (" + am.online.length + " su " + am.totale + ")" : ""),
      am.ok ? am.online.map((f) => [f.nome, f.gioca ? "gioca a " + f.gioca : f.stato]) : [], am.ok ? "Nessun amico online adesso" : am.errore));
    box.appendChild(scheda("⬇ Download", (h.download || []).map((d) => [d.nome, d.pct + "%", d.pct]), "Nessun download in corso"));
    const agg = (h.aggiornamenti || []).map((n) => [n, "aggiornamento"]);
    if (h.sistema && h.sistema.nuovo) agg.unshift(["EG PLAY OS", "aggiornamento disponibile"]);
    box.appendChild(scheda("🔄 Aggiornamenti", agg, "Giochi e sistema aggiornati"));
    box.appendChild(scheda("💾 Console", [["Spazio", h.spazio || "—"], ["EG CLOUD", h.cloud ? "in lista d'attesa (" + h.cloud + ")" : "in arrivo"], ["Ora", new Date().toLocaleTimeString("it-IT", { hour: "2-digit", minute: "2-digit" })]], ""));
  }
  function apriHub() {
    $("#hub-corpo").innerHTML = '<p class="hub-vuoto">Carico…</p>';
    apri("hub");
    disegnaHub();
    clearInterval(hubTimer);
    hubTimer = setInterval(() => { if (S.finestra === "hub") disegnaHub(); else clearInterval(hubTimer); }, 5000);
  }

  // ------------------------------------------------------------------ EG CLOUD (27.27): i piani di EG PLAY CLOUD
  async function disegnaCloud() {
    const box = $("#cloud");
    const r = await api("/api/cloud").catch(() => null);
    box.textContent = "";
    if (!r || !r.ok) { box.innerHTML = '<div class="vuoto">EG CLOUD non risponde.</div>'; return; }
    const top = document.createElement("div");
    top.className = "plus-top";
    top.innerHTML = '<h1>EG <span>CLOUD</span></h1><p></p>';
    $("p", top).textContent = r.nota;
    box.appendChild(top);
    const row = document.createElement("div");
    row.className = "plus-piani";
    r.piani.forEach((p) => {
      const iscritto = r.attesa === p.id;
      const c = document.createElement("button");
      c.className = "plus-piano f" + (iscritto ? " attivo" : "");
      c.style.setProperty("--c", p.colore);
      c.innerHTML = '<b class="pn"></b><span class="pp"></span><ul></ul><span class="pg"></span><span class="pa"></span>';
      $(".pn", c).textContent = "EG PLAY CLOUD " + p.nome;
      $(".pp", c).textContent = p.prezzo;
      p.cose.forEach((v) => { const li = document.createElement("li"); li.textContent = v; $("ul", c).appendChild(li); });
      $(".pg", c).textContent = p.nota || "";
      $(".pa", c).textContent = iscritto ? "✓ Sei in lista d'attesa" : "In arrivo · Avvisami";
      c.addEventListener("click", async () => {
        if (!r.account) { avviso("Entra prima con l'Account EMAGIAKU: Impostazioni › Account EMAGIAKU", 5000); return; }
        const x = await azione("/api/cloud_attesa", { id: iscritto ? "" : p.id });
        if (x.ok) { await disegnaCloud(); metti($$(".plus-piano", box)[r.piani.indexOf(p)]); }
      });
      row.appendChild(c);
    });
    box.appendChild(row);
    const nota = document.createElement("p");
    nota.className = "nota-sez";
    nota.textContent = "Nel PC cloud entri con i tuoi account (Steam, EA app, Ubisoft Connect, Epic…) e giochi i giochi che possiedi o il tuo abbonamento (es. EA Play). EMAGIAKU non vede le tue password.";
    box.appendChild(nota);
  }
  // controller Bluetooth
  let cercando = false;
  async function cercaBT() {
    if (cercando) return;
    cercando = true;
    const box = $("#bt-lista");
    box.textContent = "Cerco per 10 secondi…";
    try {
      const r = await api("/api/bt/cerca", {});
      box.textContent = "";
      if (!r.ok) { box.textContent = r.errore; return; }
      if (!r.controller.length) { box.textContent = "Nessun controller trovato: mettilo in abbinamento e riprova."; return; }
      r.controller.forEach((c) => {
        const b = bottone(c.nome + (c.connesso ? " · collegato" : c.associato ? " · associato" : " · associa"), async () => {
          avviso("Associo " + c.nome + "…", 30000);
          const x = await api("/api/bt/associa", { mac: c.mac });
          avviso(x.ok ? c.nome + " collegato!" : x.errore, 5000);
          if (x.ok) b.textContent = c.nome + " · collegato";
        });
        box.appendChild(b);
      });
      metti($(".f", box));
    } catch (e) { box.textContent = "Il servizio EG PLAY non risponde"; }
    finally { cercando = false; }
  }

  // ------------------------------------------------------------------ TASTIERA SULLO SCHERMO (controller)
  const RIGHE = ["1234567890", "qwertyuiop", "asdfghjkl@", "zxcvbnm.-_"];
  let oskFine = null;
  function tastiera(titolo, iniziale, segreto, maiuscole) {
    return new Promise((ok) => {
      let testo = iniziale || "", maiu = !!maiuscole;
      $("#osk-titolo").textContent = titolo;
      const mostra = () => { $("#osk-testo").textContent = (segreto ? "•".repeat(testo.length) : testo) + "▏"; };
      const disegna = () => {
        const box = $("#osk-tasti");
        box.textContent = "";
        RIGHE.forEach((r) => {
          const row = document.createElement("div");
          row.className = "osk-riga";
          for (const ch of r) {
            const k = document.createElement("button");
            k.className = "tasto-osk f";
            k.textContent = maiu ? ch.toUpperCase() : ch;
            k.addEventListener("click", () => { testo += k.textContent; mostra(); });
            row.appendChild(k);
          }
          box.appendChild(row);
        });
        const ult = document.createElement("div");
        ult.className = "osk-riga";
        [["⇧ Maiuscole", () => { maiu = !maiu; const f = S.fuoco && S.fuoco.textContent; disegna(); metti($$(".tasto-osk").find((x) => x.textContent === f) || $(".tasto-osk")); }],
         ["Spazio", () => { testo += " "; mostra(); }], ["⌫", () => { testo = testo.slice(0, -1); mostra(); }],
         ["✓ Fatto", () => fine(testo)], ["Annulla", () => fine("")]].forEach(([t, fn]) => {
          const k = document.createElement("button");
          k.className = "tasto-osk largo f";
          k.textContent = t;
          k.addEventListener("click", fn);
          ult.appendChild(k);
        });
        box.appendChild(ult);
      };
      const fine = (v) => { oskFine = null; chiudi(); ok(v.trim ? v.trim() : v); };
      oskFine = fine;
      oskTasto = (e) => {          // tastiera vera (se c'è)
        if (e.key.length === 1) { testo += e.key; mostra(); return true; }
        if (e.key === "Backspace") { testo = testo.slice(0, -1); mostra(); return true; }
        if (e.key === "Enter" && S.fuoco && !S.fuoco.classList.contains("tasto-osk")) { fine(testo); return true; }
        return false;
      };
      disegna(); mostra();
      apri("osk");
    });
  }
  let oskTasto = null;

  // ------------------------------------------------------------------ finestre
  function apri(id) {
    if (S.finestra) chiudi(true);
    S.ritorno = S.fuoco;
    S.finestra = id;
    $("#" + id).classList.remove("nascosta");
    metti($(`#${id} .f`));
  }
  function chiudi(silenzioso) {
    if (!S.finestra) return;
    const id = S.finestra;
    $("#" + id).classList.add("nascosta");
    S.finestra = null;
    if (id === "osk") { oskTasto = null; if (oskFine && !silenzioso) { const f = oskFine; oskFine = null; f(""); } }
    metti(S.ritorno && document.contains(S.ritorno) ? S.ritorno : primo());
  }

  let tAvviso;
  function avviso(t, ms = 2500) {
    const a = $("#avviso");
    a.textContent = t;
    a.classList.remove("nascosta");
    clearTimeout(tAvviso);
    tAvviso = setTimeout(() => a.classList.add("nascosta"), ms);
  }

  // ------------------------------------------------------------------ sezioni e fuoco
  function vaiSez(nome, fuocoTab) {
    if (!SEZ.includes(nome)) return;
    S.sez = nome;
    $$(".sez").forEach((s) => s.classList.toggle("attiva", s.id === "sez-" + nome));
    $$(".tab").forEach((t) => t.classList.toggle("attiva", t.dataset.sez === nome));
    if (nome === "store" && !S.storeFatto) { S.storeFatto = true; disegnaStore(); }
    if (nome === "media") disegnaMedia();
    if (nome === "cloud") disegnaCloud();
    if (nome === "libreria") disegnaLibreria();
    if (nome === "impostazioni") apriImp(($("#imp-menu .voce.sel") || {}).dataset ? $("#imp-menu .voce.sel").dataset.imp : "account");
    if (fuocoTab) metti($(`.tab[data-sez="${nome}"]`));
    else metti(primo());
  }
  function primo() {
    const sez = $(".sez.attiva");
    return $(".gioco.f", sez) || $(".f:not(.nascosta)", sez) || $(".tab.attiva");
  }
  function metti(el) {
    if (!el) return;
    if (S.fuoco) S.fuoco.classList.remove("sel-f");
    S.fuoco = el;
    el.classList.add("sel-f");
    el.focus({ preventScroll: true });
    el.scrollIntoView({ block: "nearest", inline: "nearest", behavior: "smooth" });
  }
  function visibili() {
    const radice = S.finestra ? $("#" + S.finestra) : document;
    return $$(".f", radice).filter((e) => !e.closest(".nascosta") && e.offsetParent !== null && !e.classList.contains("nascosta") &&
      (S.finestra || !e.closest(".sez") || e.closest(".sez.attiva")));
  }
  function muovi(dir) {
    const cur = S.fuoco && document.contains(S.fuoco) && !S.fuoco.closest(".nascosta") ? S.fuoco : null;
    if (!cur) return metti(S.finestra ? $(`#${S.finestra} .f`) : primo());
    const a = cur.getBoundingClientRect();
    const ax = a.left + a.width / 2, ay = a.top + a.height / 2;
    let best = null, bestD = Infinity;
    for (const el of visibili()) {
      if (el === cur) continue;
      const b = el.getBoundingClientRect();
      const bx = b.left + b.width / 2, by = b.top + b.height / 2;
      const dx = bx - ax, dy = by - ay;
      let main, side;
      if (dir === "dx") { if (b.left < a.right - 4 && dx <= 4) continue; main = dx; side = Math.abs(dy); }
      else if (dir === "sx") { if (b.right > a.left + 4 && dx >= -4) continue; main = -dx; side = Math.abs(dy); }
      else if (dir === "giu") { if (b.top < a.bottom - 4 && dy <= 4) continue; main = dy; side = Math.abs(dx); }
      else { if (b.bottom > a.top + 4 && dy >= -4) continue; main = -dy; side = Math.abs(dx); }
      if (main <= 0) continue;
      const d = main + side * 2.5;
      if (d < bestD) { bestD = d; best = el; }
    }
    if (best) metti(best);
  }
  function conferma() {
    const el = S.fuoco;
    if (!el) return;
    if (el.classList.contains("tab")) return vaiSez(el.dataset.sez);
    el.click();
  }
  function indietro() {
    if (S.finestra) return chiudi();
    if (S.fuoco && S.fuoco.closest("#imp-pannello")) return metti($("#imp-menu .voce.sel") || $("#imp-menu .voce"));
    if (S.fuoco && S.fuoco.classList.contains("tab")) return vaiSez("home");
    metti($(`.tab[data-sez="${S.sez}"]`));
  }
  function sezVicina(passo) {
    const i = (SEZ.indexOf(S.sez) + passo + SEZ.length) % SEZ.length;
    if (S.finestra) chiudi();
    vaiSez(SEZ[i], true);
  }

  // ------------------------------------------------------------------ animazione di avvio (27.26)
  const intro = $("#intro");
  let introVia = false;
  function saltaIntro() {
    if (introVia || !intro) return;
    introVia = true;
    intro.classList.add("salta");
    setTimeout(() => intro.remove(), 400);
  }
  if (intro) setTimeout(() => { introVia = true; intro.remove(); }, 5400);
  const inIntro = () => intro && !introVia && document.contains(intro);

  // ------------------------------------------------------------------ tastiera vera
  document.addEventListener("keydown", (e) => {
    if (inIntro()) { e.preventDefault(); saltaIntro(); return; }
    if (S.finestra === "osk" && oskTasto && oskTasto(e)) { e.preventDefault(); return; }
    const k = e.key;
    const map = { ArrowRight: "dx", ArrowLeft: "sx", ArrowDown: "giu", ArrowUp: "su" };
    if (map[k]) { e.preventDefault(); return muovi(map[k]); }
    if (k === "Enter" || k === " ") { e.preventDefault(); return conferma(); }
    if (k === "Escape" || k === "Backspace") { e.preventDefault(); return indietro(); }
    if (k === "y" || k === "Y" || k === "i") return dettagliGioco(S.scelto);
    if (k === "m" || k === "M" || k === "ContextMenu") return S.finestra === "menu" ? chiudi() : apri("menu");
    if (k === "q" || k === "PageUp") return sezVicina(-1);
    if (k === "e" || k === "PageDown") return sezVicina(1);
    if (k === "Tab") { e.preventDefault(); return sezVicina(e.shiftKey ? -1 : 1); }
  });
  document.addEventListener("mouseover", (e) => { const f = e.target.closest(".f"); if (f && f !== S.fuoco && (!S.finestra || f.closest("#" + S.finestra))) metti(f); });

  // ------------------------------------------------------------------ controller PlayStation / Xbox / Nintendo
  function famiglia(p) {
    const id = (p.id || "").toLowerCase();
    if (/054c|sony|playstation|dualsense|dualshock|wireless controller/.test(id)) return "ps";
    if (/057e|nintendo|pro controller|joy-con/.test(id)) return "nintendo";
    if (/045e|xbox|x-box|microsoft/.test(id)) return "xbox";
    return "generico";
  }
  const GLIFI = {
    ps: { ok: ["✕", "ps-x"], no: ["○", "ps-o"], info: ["△", "ps-t"], menu: "Options", l: "L1", r: "R1", nome: "PlayStation" },
    xbox: { ok: ["A", "a"], no: ["B", "b"], info: ["Y", "y"], menu: "☰", l: "LB", r: "RB", nome: "Xbox" },
    nintendo: { ok: ["A", "n-a"], no: ["B", "n-b"], info: ["X", "n-x"], menu: "+", l: "L", r: "R", nome: "Nintendo" },
    generico: { ok: ["A", "a"], no: ["B", "b"], info: ["Y", "y"], menu: "☰", l: "LB", r: "RB", nome: "Controller" },
  };
  let ultimaFam = null;
  function glifi(fam) {
    if (fam === ultimaFam) return;
    ultimaFam = fam;
    const g = GLIFI[fam];
    const set = (id, [t, cls]) => { const e = $(id); e.textContent = t; e.className = "tasto " + cls; };
    set("#t-ok", g.ok); set("#t-no", g.no); set("#t-info", g.info);
    $("#t-menu").textContent = g.menu; $("#t-l").textContent = g.l; $("#t-r").textContent = g.r;
  }
  function tasti(p, fam) {
    if (p.mapping === "standard") return fam === "nintendo" ? { ok: 1, no: 0, info: 3 } : { ok: 0, no: 1, info: 3 };
    return { ok: 0, no: 1, info: 2 };
  }
  const prima = {};
  const ripeti = { dir: null, prossimo: 0 };
  function premuto(p, i) { const b = p.buttons[i]; return !!b && (b.pressed || b.value > 0.5); }
  function giro() {
    setTimeout(giro, 16);
    const pads = navigator.getGamepads ? [...navigator.getGamepads()].filter(Boolean) : [];
    const ora = performance.now();
    let dir = null;
    if (!document.hasFocus()) {               // mentre giochi i tasti NON arrivano qui
      pads.forEach((p) => p.buttons.forEach((_, i) => { prima[p.index + ":" + i] = premuto(p, i); }));
      ripeti.dir = "fermo";
      return;
    }
    if (inIntro()) {                          // un tasto del controller salta l'animazione di avvio
      if (pads.some((p) => p.buttons.some((_, i) => premuto(p, i) && !prima[p.index + ":" + i]))) saltaIntro();
      pads.forEach((p) => p.buttons.forEach((_, i) => { prima[p.index + ":" + i] = premuto(p, i); }));
      return;
    }
    for (const p of pads) {
      const fam = famiglia(p), k = tasti(p, fam);
      const giu = (i) => premuto(p, i) && !prima[p.index + ":" + i];
      let usato = false;
      if (giu(k.ok)) { conferma(); usato = true; }
      if (giu(k.no)) { indietro(); usato = true; }
      if (giu(k.info)) { if (S.sez === "home") dettagliGioco(S.scelto); usato = true; }
      if (giu(9) || giu(8)) { S.finestra === "menu" ? chiudi() : apri("menu"); usato = true; }
      if (giu(4)) { sezVicina(-1); usato = true; }
      if (giu(5)) { sezVicina(1); usato = true; }
      if (giu(16)) { if (S.finestra) chiudi(); vaiSez("home"); usato = true; }
      const ax = p.axes[0] || 0, ay = p.axes[1] || 0;
      const hx = p.mapping === "standard" ? 0 : (p.axes.length >= 8 ? p.axes[6] : 0);
      const hy = p.mapping === "standard" ? 0 : (p.axes.length >= 8 ? p.axes[7] : 0);
      if (premuto(p, 15) || ax > 0.55 || hx > 0.5) dir = "dx";
      else if (premuto(p, 14) || ax < -0.55 || hx < -0.5) dir = "sx";
      else if (premuto(p, 13) || ay > 0.55 || hy > 0.5) dir = "giu";
      else if (premuto(p, 12) || ay < -0.55 || hy < -0.5) dir = "su";
      if (usato || dir) glifi(fam);
      p.buttons.forEach((_, i) => { prima[p.index + ":" + i] = premuto(p, i); });
    }
    if (dir && dir !== ripeti.dir) { muovi(dir); ripeti.dir = dir; ripeti.prossimo = ora + 380; }
    else if (dir && ora >= ripeti.prossimo) { muovi(dir); ripeti.prossimo = ora + 120; }
    else if (!dir) ripeti.dir = null;
  }
  function nomePad(p) { return p.id.replace(/^[0-9a-f]{1,4}-[0-9a-f]{1,4}-/i, "").split("(")[0].trim() || "controller"; }
  function aggiornaPad() {
    const pads = navigator.getGamepads ? [...navigator.getGamepads()].filter(Boolean) : [];
    const el = $("#pad");
    el.textContent = pads.length ? "🎮 " + GLIFI[famiglia(pads[0])].nome : "⌨ Tastiera";
    el.classList.toggle("on", pads.length > 0);
    const ul = $("#pad-lista");
    if (ul) {
      ul.textContent = "";
      pads.forEach((p) => { const li = document.createElement("li"); li.textContent = `🎮 ${GLIFI[famiglia(p)].nome}: ${nomePad(p)}`; ul.appendChild(li); });
    }
    if (pads.length) glifi(famiglia(pads[0]));
  }
  window.addEventListener("gamepadconnected", (e) => { aggiornaPad(); avviso(GLIFI[famiglia(e.gamepad)].nome + " collegato: " + nomePad(e.gamepad), 3000); });
  window.addEventListener("gamepaddisconnected", aggiornaPad);

  // ------------------------------------------------------------------ pulsanti fissi
  $$(".tab").forEach((t) => t.addEventListener("click", () => vaiSez(t.dataset.sez, true)));
  $$("[data-apri]").forEach((b) => b.addEventListener("click", () => { if (S.finestra) chiudi(); apriCosa(b.dataset.apri); }));
  $$("[data-post]").forEach((b) => b.addEventListener("click", () => { if (S.finestra) chiudi(); azione(b.dataset.post, {}); }));
  $$("[data-vai]").forEach((b) => b.addEventListener("click", () => { chiudi(); vaiSez(b.dataset.vai); }));
  $("#b-gioca").addEventListener("click", () => gioca(S.scelto));
  $("#b-dettagli").addEventListener("click", () => dettagliGioco(S.scelto));
  $("#m-chiudi").addEventListener("click", () => chiudi());
  $("#hub-chiudi").addEventListener("click", () => chiudi());
  $("#bl-chiudi").addEventListener("click", () => chiudi());
  $("#bl-chiave").addEventListener("click", () => { chiudi(); attivaChiave(); });

  function orologio() { $("#ora").textContent = new Date().toLocaleTimeString("it-IT", { hour: "2-digit", minute: "2-digit" }); }

  // ------------------------------------------------------------------ avvio
  async function caricaStato() {
    try { S.stato = await api("/api/stato"); } catch (e) { S.stato = { licenza: false }; }
    const st = S.stato;
    $("#nome-os").textContent = st.variante === "play" || st.sessione ? "OS" : "";
    $("#beta").classList.toggle("nascosta", st.variante !== "play");      // EG PLAY OS e' in BETA: niente numero
    $("#utente").textContent = st.utente ? "● " + st.utente : "";
    $$(".solo-sessione").forEach((e) => e.classList.toggle("nascosta", !st.sessione));
    $$(".solo-desktop").forEach((e) => e.classList.toggle("nascosta", !!st.sessione));
  }
  async function carica() {
    await caricaStato();
    try { S.giochi = await api("/api/giochi"); } catch (e) { S.giochi = []; avviso("Il servizio EG PLAY non risponde", 5000); }
    if (S.stato.demo) avviso("Modalità demo: i giochi mostrati sono esempi", 4000);
    disegnaTuttaHome();
    metti(primo());
    caricaExtra();
    if (!S.stato.licenza) apri("blocco");
  }

  orologio();
  setInterval(orologio, 10000);
  aggiornaPad();
  giro();
  carica();
})();
